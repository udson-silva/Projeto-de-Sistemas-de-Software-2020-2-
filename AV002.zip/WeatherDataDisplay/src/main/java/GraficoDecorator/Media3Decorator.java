/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraficoDecorator;

import Dao.DadosGraficoDao;
import Model.WeatherDataModel;

/**
 *
 * @author udson
 */
public class Media3Decorator extends GraficoDecorator {

    public Media3Decorator(DadosTempo dadostempo) {
        super(dadostempo);
        // TODO Auto-generated constructor stub
    }

    @Override
    public WeatherDataModel RetornaDados(int mes, int ano) {
       

        WeatherDataModel weatherdata = new WeatherDataModel();

        DadosGraficoDao dao = new DadosGraficoDao();

        weatherdata.setMes(mes);
        weatherdata.setAno(ano);

        weatherdata = dao.PesquisaDadosMedios(weatherdata);

        return weatherdata;

    }

   
  
}
