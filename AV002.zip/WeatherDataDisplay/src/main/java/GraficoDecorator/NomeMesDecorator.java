/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraficoDecorator;

import Model.WeatherDataModel;

/**
 *
 * @author udson
 */
public class NomeMesDecorator  extends GraficoDecorator{

    public NomeMesDecorator(DadosTempo dados) {
        super(dados);
    }
    
    
    


    @Override
    public String NomeMes(int mes) {
        
      String nome_mes ="";
      
       switch (mes) {
                case 1:
                    nome_mes ="JANEIRO";
                    break;
                case 2:
                    nome_mes = "FEVEREIRO";
                    break;
                case 3:
                   nome_mes = "MARÇO";
                    break;
                case 4:
                   nome_mes = "ABRIL";
                    break;
                case 5:
                    nome_mes = "MAIO";
                    break;
                case 6:
                    nome_mes = "JUNHO";
                    break;
                case 7:
                    nome_mes = "JULHO";
                    break;
                case 8:
                    nome_mes = "AGOSTO";
                    break;
                case 9:
                    nome_mes = "SETEMBRO";
                    break;
                case 10:
                    nome_mes = "OUTUBRO";
                    break;
                case 11:
                   nome_mes = "NOVEMBRO";
                    break;
                case 12:
                   nome_mes = "DEZEMBRO";
                    break;
                default:
                    break;
            }
        return nome_mes;
        
       
    }
  
    
    
    
    
    
    
}
