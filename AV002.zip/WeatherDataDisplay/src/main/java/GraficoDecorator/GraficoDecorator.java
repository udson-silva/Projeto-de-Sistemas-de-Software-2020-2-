/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraficoDecorator;
import Model.WeatherDataModel;

/**
 *
 * @author udson
 */
public abstract class GraficoDecorator implements DadosTempo{
	private final DadosTempo graficoDecorador;
	
	public GraficoDecorator(DadosTempo dados) {
		this.graficoDecorador = dados;
	}
	
    public WeatherDataModel RetornaDados(int mes, int ano) { 
        return graficoDecorador.RetornaDados(mes, ano);
    }

    
    
     @Override
    public String TituloGrafico() {
        return graficoDecorador.TituloGrafico();
       
    }
    
    
     @Override
    public String NomeMes(int mes) {
        return graficoDecorador.NomeMes(mes);
        
    }
 

	
}
