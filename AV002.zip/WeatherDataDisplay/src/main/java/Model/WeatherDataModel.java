/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author udson
 */
public class WeatherDataModel {

    

   

    private String data;
    private float pressao;
    private float temperatura;
    private float umidade;
    private int id;
    private int contador;
    private String datainicio;
    private String datafim;
    private int ano;
    private int mes;
    private int dia;
    private int dia_inicio;
    private int dia_fim;
    private int mes_inicio;
    private int mes_fim;
    private int ano_inicio;
    private int ano_fim;
    private float mediatemperatura;
    private float mediaumidade;
    private float mediapressao;
    private float numeroregistros;
    private String tipo_registro;
    private String nome_mes;
    private String nome_mes1;
    private String nome_mes2;
    private String nome_mes3;
    private int ano1;
    private int mes1;
    private int ano2;
    private int mes2;
    private int ano3;
    private int mes3;
    private String escolha;
    private float media1;
    private float media2;
    private float media3;
    private String  titulohorizontal;
    private String titulovertical;

   
    
    
    
    
    /**
     * @return the titulovertical
     */
    public String getTitulovertical() {
        return titulovertical;
    }

    /**
     * @param titulovertical the titulovertical to set
     */
    public void setTitulovertical(String titulovertical) {
        this.titulovertical = titulovertical;
    }
    
     /**
     * @return the titulohorizontal
     */
    public String getTitulohorizontal() {
        return titulohorizontal;
    }

    /**
     * @param titulohorizontal the titulohorizontal to set
     */
    public void setTitulohorizontal(String titulohorizontal) {
        this.titulohorizontal = titulohorizontal;
    }
    
    /**
     * @return the nome_mes
     */
    public String getNome_mes() {
        return nome_mes;
    }

    /**
     * @param nome_mes the nome_mes to set
     */
    public void setNome_mes(String nome_mes) {
        this.nome_mes = nome_mes;
    }

    /**
     * @return the media1
     */
    public float getMedia1() {
        return media1;
    }

    /**
     * @param media1 the media1 to set
     */
    public void setMedia1(float media1) {
        this.media1 = media1;
    }

    /**
     * @return the media2
     */
    public float getMedia2() {
        return media2;
    }

    /**
     * @param media2 the media2 to set
     */
    public void setMedia2(float media2) {
        this.media2 = media2;
    }

    /**
     * @return the media3
     */
    public float getMedia3() {
        return media3;
    }

    /**
     * @param media3 the media3 to set
     */
    public void setMedia3(float media3) {
        this.media3 = media3;
    }

    /**
     * @return the nome_mes1
     */
    public String getNome_mes1() {
        return nome_mes1;
    }

    /**
     * @param nome_mes1 the nome_mes1 to set
     */
    public void setNome_mes1(String nome_mes1) {
        this.nome_mes1 = nome_mes1;
    }

    /**
     * @return the nome_mes2
     */
    public String getNome_mes2() {
        return nome_mes2;
    }

    /**
     * @param nome_mes2 the nome_mes2 to set
     */
    public void setNome_mes2(String nome_mes2) {
        this.nome_mes2 = nome_mes2;
    }

    /**
     * @return the nome_mes3
     */
    public String getNome_mes3() {
        return nome_mes3;
    }

    /**
     * @param nome_mes3 the nome_mes3 to set
     */
    public void setNome_mes3(String nome_mes3) {
        this.nome_mes3 = nome_mes3;
    }

    /**
     * @return the escolha
     */
    public String getEscolha() {
        return escolha;
    }

    /**
     * @param escolha the escolha to set
     */
    public void setEscolha(String escolha) {
        this.escolha = escolha;
    }

    /**
     * @return the ano1
     */
    public int getAno1() {
        return ano1;
    }

    /**
     * @param ano1 the ano1 to set
     */
    public void setAno1(int ano1) {
        this.ano1 = ano1;
    }

    /**
     * @return the mes1
     */
    public int getMes1() {
        return mes1;
    }

    /**
     * @param mes1 the mes1 to set
     */
    public void setMes1(int mes1) {
        this.mes1 = mes1;
    }

    /**
     * @return the ano2
     */
    public int getAno2() {
        return ano2;
    }

    /**
     * @param ano2 the ano2 to set
     */
    public void setAno2(int ano2) {
        this.ano2 = ano2;
    }

    /**
     * @return the mes2
     */
    public int getMes2() {
        return mes2;
    }

    /**
     * @param mes2 the mes2 to set
     */
    public void setMes2(int mes2) {
        this.mes2 = mes2;
    }

    /**
     * @return the ano3
     */
    public int getAno3() {
        return ano3;
    }

    /**
     * @param ano3 the ano3 to set
     */
    public void setAno3(int ano3) {
        this.ano3 = ano3;
    }

    /**
     * @return the mes3
     */
    public int getMes3() {
        return mes3;
    }

    /**
     * @param mes3 the mes3 to set
     */
    public void setMes3(int mes3) {
        this.mes3 = mes3;
    }

    /**
     * @return the tipo_registro
     */
    public String getTipo_registro() {
        return tipo_registro;
    }

    /**
     * @param tipo_registro the tipo_registro to set
     */
    public void setTipo_registro(String tipo_registro) {
        this.tipo_registro = tipo_registro;
    }

    /**
     * @return the mediatemperatura
     */
    public float getMediatemperatura() {
        return mediatemperatura;
    }

    /**
     * @param mediatemperatura the mediatemperatura to set
     */
    public void setMediatemperatura(float mediatemperatura) {
        this.mediatemperatura = mediatemperatura;
    }

    /**
     * @return the mediaumidade
     */
    public float getMediaumidade() {
        return mediaumidade;
    }

    /**
     * @param mediaumidade the mediaumidade to set
     */
    public void setMediaumidade(float mediaumidade) {
        this.mediaumidade = mediaumidade;
    }

    /**
     * @return the mediapressao
     */
    public float getMediapressao() {
        return mediapressao;
    }

    /**
     * @param mediapressao the mediapressao to set
     */
    public void setMediapressao(float mediapressao) {
        this.mediapressao = mediapressao;
    }

    /**
     * @return the numeroregistros
     */
    public float getNumeroregistros() {
        return numeroregistros;
    }

    /**
     * @param numeroregistros the numeroregistros to set
     */
    public void setNumeroregistros(float numeroregistros) {
        this.numeroregistros = numeroregistros;
    }

    /**
     * @return the dia_inicio
     */
    public int getDia_inicio() {
        return dia_inicio;
    }

    /**
     * @param dia_inicio the dia_inicio to set
     */
    public void setDia_inicio(int dia_inicio) {
        this.dia_inicio = dia_inicio;
    }

    /**
     * @return the dia_fim
     */
    public int getDia_fim() {
        return dia_fim;
    }

    /**
     * @param dia_fim the dia_fim to set
     */
    public void setDia_fim(int dia_fim) {
        this.dia_fim = dia_fim;
    }

    /**
     * @return the mes_inicio
     */
    public int getMes_inicio() {
        return mes_inicio;
    }

    /**
     * @param mes_inicio the mes_inicio to set
     */
    public void setMes_inicio(int mes_inicio) {
        this.mes_inicio = mes_inicio;
    }

    /**
     * @return the mes_fim
     */
    public int getMes_fim() {
        return mes_fim;
    }

    /**
     * @param mes_fim the mes_fim to set
     */
    public void setMes_fim(int mes_fim) {
        this.mes_fim = mes_fim;
    }

    /**
     * @return the ano_inicio
     */
    public int getAno_inicio() {
        return ano_inicio;
    }

    /**
     * @param ano_inicio the ano_inicio to set
     */
    public void setAno_inicio(int ano_inicio) {
        this.ano_inicio = ano_inicio;
    }

    /**
     * @return the ano_fim
     */
    public int getAno_fim() {
        return ano_fim;
    }

    /**
     * @param ano_fim the ano_fim to set
     */
    public void setAno_fim(int ano_fim) {
        this.ano_fim = ano_fim;
    }

    /**
     * @return the ano
     */
    public int getAno() {
        return ano;
    }

    /**
     * @param ano the ano to set
     */
    public void setAno(int ano) {
        this.ano = ano;
    }

    /**
     * @return the mes
     */
    public int getMes() {
        return mes;
    }

    /**
     * @param mes the mes to set
     */
    public void setMes(int mes) {
        this.mes = mes;
    }

    /**
     * @return the dia
     */
    public int getDia() {
        return dia;
    }

    /**
     * @param dia the dia to set
     */
    public void setDia(int dia) {
        this.dia = dia;
    }

    /**
     * @return the contador
     */
    public int getContador() {
        return contador;
    }

    /**
     * @param contador the contador to set
     */
    public void setContador(int contador) {
        this.contador = contador;
    }

    /**
     * @return the datainicio
     */
    public String getDatainicio() {
        return datainicio;
    }

    /**
     * @param datainicio the datainicio to set
     */
    public void setDatainicio(String datainicio) {
        this.datainicio = datainicio;
    }

    /**
     * @return the datafim
     */
    public String getDatafim() {
        return datafim;
    }

    /**
     * @param datafim the datafim to set
     */
    public void setDatafim(String datafim) {
        this.datafim = datafim;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the pressao
     */
    public float getPressao() {
        return pressao;
    }

    /**
     * @param pressao the pressao to set
     */
    public void setPressao(float pressao) {
        this.pressao = pressao;
    }

    /**
     * @return the temperatura
     */
    public float getTemperatura() {
        return temperatura;
    }

    /**
     * @param temperatura the temperatura to set
     */
    public void setTemperatura(float temperatura) {
        this.temperatura = temperatura;
    }

    /**
     * @return the umidade
     */
    public float getUmidade() {
        return umidade;
    }

    /**
     * @param umidade the umidade to set
     */
    public void setUmidade(float umidade) {
        this.umidade = umidade;
    }

    /**
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(String data) {
        this.data = data;
    }

}
