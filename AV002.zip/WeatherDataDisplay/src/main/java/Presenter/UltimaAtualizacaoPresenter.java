/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import Dao.WeatherDataDao;
import Model.WeatherDataModel;
import Observer.Observer;
import javax.swing.JDesktopPane;
import views.UltimaAtualizacaoView;

/**
 *
 * @author udson
 */
public class UltimaAtualizacaoPresenter implements Observer{
    
      UltimaAtualizacaoView view;

    public UltimaAtualizacaoPresenter(JDesktopPane desktop) {

        view = new UltimaAtualizacaoView();
        desktop.add(view);

        view.setVisible(true);
        
        WeatherDataModel weatherdatamodel = new WeatherDataModel();
        WeatherDataDao pesquisa = new WeatherDataDao();

        WeatherDataModel weatherdata = pesquisa.PesquisaUltimoDado(weatherdatamodel);
        
        view.getJLabelData().setText(weatherdata.getData());
        view.getjLabelPressao().setText(String.valueOf(weatherdata.getPressao()));
        view.getjLabelTemperatura().setText(String.valueOf(weatherdata.getTemperatura()));
        view.getjLabelUmidade().setText(String.valueOf(weatherdata.getUmidade()));
        
        

        

    }

    @Override
    public void update() {
        
         WeatherDataModel weatherdatamodel = new WeatherDataModel();
        WeatherDataDao pesquisa = new WeatherDataDao();

        WeatherDataModel weatherdata = pesquisa.PesquisaUltimoDado(weatherdatamodel);
        
        view.getJLabelData().setText(weatherdata.getData());
        view.getjLabelPressao().setText(String.valueOf(weatherdata.getPressao()));
        view.getjLabelTemperatura().setText(String.valueOf(weatherdata.getTemperatura()));
        view.getjLabelUmidade().setText(String.valueOf(weatherdata.getUmidade()));
        
    }
    
    
    
    
    
}
