/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import Dao.WeatherDataDao;
import Model.WeatherDataModel;
import Observer.Observer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import views.PrincipalView;
import GraficoBuilder.GraficoSimplesBuilder;

/**
 *
 * @author udson
 */
public class PrincipalPresenter implements Observer {

    String tipo_de_log;
    private final PrincipalView view;
    DadosTempoPresenter dadosdotempopresenter;
    RegistrosPresenter registrospresenter;
    PrincipalPresenter instancia;
    ConfiguracoesPresenter configuracoes;

    public PrincipalPresenter() {

        view = new PrincipalView();

        instancia = this;

        Atualizacontador();
        TipoLog();

        dadosdotempopresenter = new DadosTempoPresenter(view.getjDesktopPanePrincipal(), tipo_de_log);

        dadosdotempopresenter.registryObserver((Observer) instancia);

        registrospresenter = new RegistrosPresenter(view.getjDesktopPanePrincipal(), tipo_de_log);
        dadosdotempopresenter.registryObserver((Observer) registrospresenter);
        registrospresenter.registryObserver((Observer) instancia);

        DadosMediosPresenter dadosmedio = new DadosMediosPresenter(view.getjDesktopPanePrincipal());
        dadosdotempopresenter.registryObserver((Observer) dadosmedio);
        registrospresenter.registryObserver((Observer) dadosmedio);

        UltimaAtualizacaoPresenter ultimaatualizacao = new UltimaAtualizacaoPresenter(view.getjDesktopPanePrincipal());
        dadosdotempopresenter.registryObserver((Observer) ultimaatualizacao);
        registrospresenter.registryObserver((Observer) ultimaatualizacao);

        GraficoSimplesBuilder grafico = new GraficoSimplesBuilder(view.getjDesktopPanePrincipal());
        dadosdotempopresenter.registryObserver((Observer) grafico);
        registrospresenter.registryObserver((Observer) grafico);

        view.setVisible(true);

        view.getjMenuItemLog().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                configuracoes = new ConfiguracoesPresenter(view.getjDesktopPanePrincipal());
                configuracoes.registryObserver((Observer) instancia);
            }
        });

    }

    public final void Atualizacontador() {

        WeatherDataModel weatherdatamodel = new WeatherDataModel();
        WeatherDataDao pesquisa = new WeatherDataDao();

        WeatherDataModel WeatherData = pesquisa.ContaRegistros(weatherdatamodel);

        view.getjLabelNumeroRegistrosTempo().setText(String.valueOf(WeatherData.getContador()));

    }

    public final void TipoLog() {

        WeatherDataDao pesquisa = new WeatherDataDao();

        tipo_de_log = pesquisa.PesquisaLog();

    }

    @Override
    public void update() {
        Atualizacontador();
        TipoLog();
    }

}
