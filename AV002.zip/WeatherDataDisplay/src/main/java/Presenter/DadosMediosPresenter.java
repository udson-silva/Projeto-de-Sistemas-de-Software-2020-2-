/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import Dao.WeatherDataDao;
import Model.WeatherDataModel;
import Observer.Observer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import views.DadosMediosView;
import javax.swing.JDesktopPane;

/**
 *
 * @author udson
 */
public class DadosMediosPresenter implements Observer{

    String datainicio, datafim;
    DadosMediosView view;

    public DadosMediosPresenter(JDesktopPane desktop) {

        view = new DadosMediosView();
        desktop.add(view);

        view.setVisible(true);

        view.getbtnGerarDados().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                GeraDados();

            }
        });

       

    }

    public void GeraDados() {

        String data_inicial = "01/01/2021";
        String data_final = "30/03/2021";

        String convertediainicial = data_inicial.substring(0, 2);
        String convertemesinicial = data_inicial.substring(3, 5);
        String converteanoinicial = data_inicial.substring(6);

        int diainicio = Integer.parseInt(convertediainicial);
        int mesinicio = Integer.parseInt(convertemesinicial);
        int anoinicio = Integer.parseInt(converteanoinicial);

        String convertediafim = data_final.substring(0, 2);
        String convertemesdatafim = data_final.substring(3, 5);
        String converteanodatafim = data_final.substring(6);

        int diafim = Integer.parseInt(convertediafim);
        int mesfim = Integer.parseInt(convertemesdatafim);
        int anofim = Integer.parseInt(converteanodatafim);

        WeatherDataModel  weatherdatamodel = new WeatherDataModel();

        //data inicio encapsulada
        weatherdatamodel.setDia_inicio(diainicio);
        weatherdatamodel.setMes_inicio(mesinicio);
        weatherdatamodel.setAno_inicio(anoinicio);

        //data fim encapsulada
        weatherdatamodel.setDia_fim(diafim);
        weatherdatamodel.setMes_fim(mesfim);
        weatherdatamodel.setAno_fim(anofim);

        if (view.getJcomboboxPeriodo().getSelectedItem().equals("Diário")) {

            ContadoraDiasMesesPresenter contadora = new ContadoraDiasMesesPresenter();
            int dias = (int) contadora.DiferencaDatas(data_inicial, data_final);
            dias = dias+1;
            
            // 
            WeatherDataDao pesquisa = new WeatherDataDao();

            WeatherDataModel dadosdotempo = pesquisa.PesquisaDadosMedios(weatherdatamodel);
            
            float pressao =  dadosdotempo.getMediapressao();
            float temperatura = dadosdotempo.getMediatemperatura();
            float umidade = dadosdotempo.getMediaumidade();
            
            view.getJLabelTemperatura().setText(String.valueOf(temperatura/dias));
            view.getJLabelPressao().setText(String.valueOf(pressao/dias));
            view.getJLabelUmidade().setText(String.valueOf(umidade/dias));
            view.getJLabelNRegistros().setText(String.valueOf(dadosdotempo.getContador()));
            

        } else if (view.getJcomboboxPeriodo().getSelectedItem().equals("Semanal")) {

             ContadoraDiasMesesPresenter contadora = new ContadoraDiasMesesPresenter();
            int dias = (int) contadora.DiferencaDatas(data_inicial, data_final);
            dias = dias+1;
            float semanas = dias/7;
            System.out.println(semanas);
            
            // 
            WeatherDataDao pesquisa = new WeatherDataDao();

            WeatherDataModel pesquisadadostempo = pesquisa.PesquisaDadosMedios(weatherdatamodel);
            
            float pressao =  pesquisadadostempo.getMediapressao();
            float temperatura = pesquisadadostempo.getMediatemperatura();
            float umidade = pesquisadadostempo.getMediaumidade();
            
            view.getJLabelTemperatura().setText(String.valueOf(temperatura/semanas));
            view.getJLabelPressao().setText(String.valueOf(pressao/semanas));
            view.getJLabelUmidade().setText(String.valueOf(umidade/semanas));
            view.getJLabelNRegistros().setText(String.valueOf(pesquisadadostempo.getContador()));
            
          
            
            
        } else {
            
            
           int meses = mesfim - mesinicio;
           
           //quando o mes for 1
           if(meses==0){
               meses = meses+1;
           }
           
          
            
            // 
            WeatherDataDao pesquisa = new WeatherDataDao();

            WeatherDataModel weatherdata = pesquisa.PesquisaDadosMedios(weatherdatamodel);
            
            float pressao =  weatherdata.getMediapressao();
            float temperatura = weatherdata.getMediatemperatura();
            float umidade = weatherdata.getMediaumidade();
            
            view.getJLabelTemperatura().setText(String.valueOf(temperatura/meses));
            view.getJLabelPressao().setText(String.valueOf(pressao/meses));
            view.getJLabelUmidade().setText(String.valueOf(umidade/meses));
            view.getJLabelNRegistros().setText(String.valueOf(weatherdata.getContador()));
            
            

        }

    }
    
    
     public void GeraDadosObserver() {

        String data_inicial = "01/01/2021";
        String data_final = "30/03/2021";

        String convertediainicial = data_inicial.substring(0, 2);
        String convertemesinicial = data_inicial.substring(3, 5);
        String converteanoinicial = data_inicial.substring(6);

        int diainicio = Integer.parseInt(convertediainicial);
        int mesinicio = Integer.parseInt(convertemesinicial);
        int anoinicio = Integer.parseInt(converteanoinicial);

        String convertediafim = data_final.substring(0, 2);
        String convertemesdatafim = data_final.substring(3, 5);
        String converteanodatafim = data_final.substring(6);

        int diafim = Integer.parseInt(convertediafim);
        int mesfim = Integer.parseInt(convertemesdatafim);
        int anofim = Integer.parseInt(converteanodatafim);

        WeatherDataModel weatherdata = new WeatherDataModel();

        //data inicio encapsulada
        weatherdata.setDia_inicio(diainicio);
        weatherdata.setMes_inicio(mesinicio);
        weatherdata.setAno_inicio(anoinicio);

        //data fim encapsulada
        weatherdata.setDia_fim(diafim);
        weatherdata.setMes_fim(mesfim);
        weatherdata.setAno_fim(anofim);

        if (view.getJcomboboxPeriodo().getSelectedItem().equals("Diário")) {

            ContadoraDiasMesesPresenter contadora = new ContadoraDiasMesesPresenter();
            int dias = (int) contadora.DiferencaDatas(data_inicial, data_final);
            dias = dias+1;
            
            // 
            WeatherDataDao pesquisa = new WeatherDataDao();

            WeatherDataModel weatherdatamodel = pesquisa.PesquisaDadosMedios(weatherdata);
            
            float pressao =  weatherdatamodel.getMediapressao();
            float temperatura = weatherdatamodel.getMediatemperatura();
            float umidade = weatherdatamodel.getMediaumidade();
            
            view.getJLabelTemperatura().setText(String.valueOf(temperatura/dias));
            view.getJLabelPressao().setText(String.valueOf(pressao/dias));
            view.getJLabelUmidade().setText(String.valueOf(umidade/dias));
            view.getJLabelNRegistros().setText(String.valueOf(weatherdatamodel.getContador()));
            

        } else if (view.getJcomboboxPeriodo().getSelectedItem().equals("Semanal")) {

             ContadoraDiasMesesPresenter contadora = new ContadoraDiasMesesPresenter();
            int dias = (int) contadora.DiferencaDatas(data_inicial, data_final);
            dias = dias+1;
            float semanas = dias/7;
            //System.out.println(semanas);
            
            // 
            WeatherDataDao pesquisa = new WeatherDataDao();

            WeatherDataModel weatherdatamodel = pesquisa.PesquisaDadosMedios(weatherdata);
            
            float pressao =  weatherdatamodel.getMediapressao();
            float temperatura = weatherdatamodel.getMediatemperatura();
            float umidade = weatherdatamodel.getMediaumidade();
            
            view.getJLabelTemperatura().setText(String.valueOf(temperatura/semanas));
            view.getJLabelPressao().setText(String.valueOf(pressao/semanas));
            view.getJLabelUmidade().setText(String.valueOf(umidade/semanas));
            view.getJLabelNRegistros().setText(String.valueOf(weatherdatamodel.getContador()));
            
          
            
            
        } else {
            
            
           int meses = mesfim - mesinicio;
           
           //quando o mes for 1
           if(meses==0){
               meses = meses+1;
           }
           
          
            
            // 
            WeatherDataDao pesquisa = new WeatherDataDao();

            WeatherDataModel weatherdatamodel = pesquisa.PesquisaDadosMedios(weatherdata);
            
            float pressao =  weatherdatamodel.getMediapressao();
            float temperatura = weatherdatamodel.getMediatemperatura();
            float umidade = weatherdatamodel.getMediaumidade();
            
            view.getJLabelTemperatura().setText(String.valueOf(temperatura/meses));
            view.getJLabelPressao().setText(String.valueOf(pressao/meses));
            view.getJLabelUmidade().setText(String.valueOf(umidade/meses));
            view.getJLabelNRegistros().setText(String.valueOf(weatherdatamodel.getContador()));
            
            

        }

    }
    
    

    @Override
    public void update() {
        GeraDadosObserver();
    }

}
