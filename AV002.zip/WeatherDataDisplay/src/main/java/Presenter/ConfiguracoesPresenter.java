/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import Dao.WeatherDataDao;
import Observer.Observado;
import Observer.Observer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JDesktopPane;
import views.ConfiguracaoSistemaView;

/**
 *
 * @author udson
 */
public class ConfiguracoesPresenter implements Observado{
    
    ConfiguracaoSistemaView view;
    
    final ArrayList<Observer> observadores;
    
    public ConfiguracoesPresenter(JDesktopPane desktop){
         observadores = new ArrayList<Observer>(); 
        view = new ConfiguracaoSistemaView();
         desktop.add(view);
        view.setVisible(true);
        
        
        view.getbtnSalvar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
             
             
                String tipo_log = (String) view.getjComboBoxLog().getSelectedItem();
                
                WeatherDataDao alterar = new WeatherDataDao();
                
                alterar.AlterarConfiguracao(tipo_log);
                 notifyObservers();
                
                
                
            }
        });
        
        view.getBtnFechar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
           
                view.dispose();
            }
        });
        
        
    }

    @Override
    public void registryObserver(Observer observer) {
        if(!observadores.contains(observer)){
          this.observadores.add(observer);  
        }
        
    }

    @Override
    public void removeObserver(Observer observer) {
       this.observadores.remove(observer);
    }

    @Override
    public void notifyObservers() {
        
      for (Observer observer : observadores) {
          
            observer.update();
        }
    }
    
    
    
}
