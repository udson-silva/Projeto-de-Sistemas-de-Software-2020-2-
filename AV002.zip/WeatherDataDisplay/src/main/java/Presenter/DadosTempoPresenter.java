/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;


import Dao.WeatherDataDao;
import Model.WeatherDataModel;
import Observer.Observado;
import Observer.Observer;
import WeatherDataAdapter.IlogAdapter;
import WeatherDataAdapter.JSONAdapter;
import WeatherDataAdapter.XMLAdapter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JDesktopPane;
import views.DadosTempoView;

/**
 *
 * @author udson
 */
public class DadosTempoPresenter implements Observado{

    DadosTempoView view;
    WeatherDataDao controler = new WeatherDataDao();
    
     final ArrayList<Observer> observadores;
    public DadosTempoPresenter(JDesktopPane desktop, String tipo_de_log) {

        
        observadores = new ArrayList<Observer>();        
        view = new DadosTempoView();
        desktop.add(view);

        view.setVisible(true);

         
         
         view.getBtnIncluir().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
             
                String data = view.gettxtData().getText();
                String convertedia = data.substring(0,2);
                String convertemes = data.substring(3,5);
                String converteano = data.substring(6);
               
                int dia = Integer.parseInt(convertedia);
                int mes =  Integer.parseInt(convertemes);
                int ano = Integer.parseInt(converteano);
                
              
                WeatherDataModel weatherdatamodel = new WeatherDataModel();
                
                
               weatherdatamodel.setDia(dia);
               weatherdatamodel.setMes(mes);
               weatherdatamodel.setAno(ano);
               weatherdatamodel.setData(view.gettxtData().getText());
               weatherdatamodel.setPressao(Float.parseFloat(view.gettxtPressao().getText()));
               weatherdatamodel.setTemperatura(Float.parseFloat(view.gettxtTemperatura().getText()));
               weatherdatamodel.setUmidade(Float.parseFloat(view.gettxtUmidade().getText())); 
              
               controler.inserirDados(weatherdatamodel);
               
               if(tipo_de_log.equals("XML")){
                   
                     WeatherDataModel weather = new WeatherDataModel();
                     WeatherDataDao pesquisa = new WeatherDataDao();
                     WeatherDataModel pesquisadados = pesquisa.PesquisaUltimoDado(weather);
                      
                     weatherdatamodel.setId(pesquisadados.getId());
                     weatherdatamodel.setTipo_registro("INCLUSÃO");
                    IlogAdapter xml = new XMLAdapter();
                     xml.Escrever(weatherdatamodel);
               }else{
                   
                    WeatherDataModel weather = new WeatherDataModel();
                     WeatherDataDao pesquisa = new WeatherDataDao();
                     WeatherDataModel pesquisadados = pesquisa.PesquisaUltimoDado(weather);
                      
                    weatherdatamodel.setId(pesquisadados.getId());
                    weatherdatamodel.setTipo_registro("INCLUSÃO");
                    IlogAdapter json = new JSONAdapter();
                     json.Escrever(weatherdatamodel); 
                   
                   
                   
               }
               
               
               notifyObservers();
               
             
            }
         });

    }

    @Override
    public void registryObserver(Observer observer) {
        if(!observadores.contains(observer)){
          this.observadores.add(observer);  
        }
        
    }

    @Override
    public void removeObserver(Observer observer) {
       this.observadores.remove(observer);
    }

    @Override
    public void notifyObservers() {
        
      for (Observer observer : observadores) {
          
            observer.update();
        }
    }

  

}
