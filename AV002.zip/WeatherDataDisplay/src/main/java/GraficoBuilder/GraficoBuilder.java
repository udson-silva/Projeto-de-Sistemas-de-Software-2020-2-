/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraficoBuilder;

import Model.WeatherDataModel;

/**
 *
 * @author udson
 */
public abstract class GraficoBuilder {
    WeatherDataModel weatherdata;
    
    
    public GraficoBuilder(){
        
        
       
        
    }
    
    
    
    
    public WeatherDataModel ConstroiGraficoColuna(WeatherDataModel weatherdata){
        return weatherdata;
        
    }
    
    
     public WeatherDataModel ConstroiGraficoBarra(WeatherDataModel weatherdata){
        return weatherdata;
    }
    
}
