/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraficoBuilder;

import Model.WeatherDataModel;
import GraficoDecorator.DadosTempo;
import GraficoDecorator.Media1Decorator;
import GraficoDecorator.Media2Decorator;
import GraficoDecorator.Media3Decorator;
import GraficoDecorator.TituloGraficoHorizontal;
import GraficoDecorator.TituloGraficoVertical;
import GraficoDecorator.NomeMesDecorator;

/**
 *
 * @author udson
 */
public class GraficoColunaBuilder extends GraficoBuilder {

    public GraficoColunaBuilder() {
       
    }


    

    @Override
    public WeatherDataModel ConstroiGraficoColuna(WeatherDataModel weatherdata) {

        float media1, media2, media3;
        int mes1, ano1, mes2, ano2, mes3, ano3;
       

        String escolha = weatherdata.getEscolha();

        mes1 = weatherdata.getMes1();
        ano1 = weatherdata.getAno1();
        mes2 = weatherdata.getMes2();
        ano2 = weatherdata.getAno2();
        mes3 = weatherdata.getMes3();
        ano3 = weatherdata.getAno3();

        DadosTempo dadostempo = new Media1Decorator();

        weatherdata = dadostempo.RetornaDados(mes1, ano1);

        switch (escolha) {
            case "MÉDIA TEMPERATURA":
                media1 = weatherdata.getMediatemperatura() / 30;
                break;
            case "MÉDIA UMIDADE":
                media1 = weatherdata.getMediaumidade() / 30;
                break;
            default:
                media1 = weatherdata.getMediapressao() / 30;
                break;
        }
       

        dadostempo = (DadosTempo) new Media2Decorator(dadostempo);

        weatherdata = dadostempo.RetornaDados(mes2, ano2);
        switch (escolha) {
            case "MÉDIA TEMPERATURA":
                media2 = weatherdata.getMediatemperatura() / 30;
                break;
            case "MÉDIA UMIDADE":
                media2 = weatherdata.getMediaumidade() / 30;
                break;
            default:
                media2 = weatherdata.getMediapressao() / 30;
                break;
        }

        

        dadostempo = (DadosTempo) new Media3Decorator(dadostempo);
        weatherdata = dadostempo.RetornaDados(mes3, ano3);

        switch (escolha) {
            case "MÉDIA TEMPERATURA":
                media3 = weatherdata.getMediatemperatura() / 30;
                break;
            case "MÉDIA UMIDADE":
                media3 = weatherdata.getMediaumidade() / 30;
                break;
            default:
                media3 = weatherdata.getMediapressao() / 30;
                break;
        }

       

        //pega o título horizontal do grafico
        dadostempo = new TituloGraficoHorizontal(dadostempo);
        String titulohorizontal = dadostempo.TituloGrafico();

          //pega o título vertical do grafico
        dadostempo = new TituloGraficoVertical(dadostempo);
        String titulovertical = dadostempo.TituloGrafico();
        
        //pega o nome referente aos meses escolhidos
        dadostempo = new NomeMesDecorator(dadostempo);
        String nomemes1 = dadostempo.NomeMes(mes1);
        String nomemes2 = dadostempo.NomeMes(mes2);
        String nomemes3 = dadostempo.NomeMes(mes3);
        
        
        weatherdata.setNome_mes1(nomemes1);
        weatherdata.setNome_mes2(nomemes2);
        weatherdata.setNome_mes3(nomemes3);
        weatherdata.setTitulovertical(titulovertical);
        weatherdata.setTitulohorizontal(titulohorizontal);
        weatherdata.setMedia1(media1);
        weatherdata.setMedia2(media2);
        weatherdata.setMedia3(media3);
        

        return weatherdata;

    }

}
