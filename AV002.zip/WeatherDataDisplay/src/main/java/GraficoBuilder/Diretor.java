/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraficoBuilder;

import Model.WeatherDataModel;

/**
 *
 * @author udson
 */
public class Diretor extends GraficoBuilder{
    
     
    
   public Diretor(){
        
    }
  
   
   
    @Override
    public WeatherDataModel ConstroiGraficoColuna(WeatherDataModel weatherdata){
        
        GraficoBarrasBuilder constroi = new GraficoBarrasBuilder();

         weatherdata = constroi.ConstroiGraficoBarra(weatherdata);
        
        
        return weatherdata;
        
    }
    
    
     public WeatherDataModel ConstroiGraficoBarra(WeatherDataModel weatherdata){
        GraficoBarrasBuilder constroi = new GraficoBarrasBuilder();

         weatherdata = constroi.ConstroiGraficoBarra(weatherdata);
        
        
        return weatherdata;
         
    }
    
    
    
}
