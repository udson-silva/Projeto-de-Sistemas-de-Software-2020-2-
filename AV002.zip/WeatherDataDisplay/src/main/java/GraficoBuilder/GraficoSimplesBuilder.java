/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraficoBuilder;

import Model.WeatherDataModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JDesktopPane;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import views.GraficoView;
import Observer.Observer;

/**
 *
 * @author udson
 */
public class GraficoSimplesBuilder implements Observer {

    GraficoSimplesBuilder grafico;
    GraficoView view;

    public GraficoSimplesBuilder(JDesktopPane desktop) {

        view = new GraficoView();
        desktop.add(view);

        view.getjCheckBoxMédiaTemp().setSelected(true);
        view.gettxtAno1().setText("2021");
        view.gettxtAno2().setText("2021");
        view.gettxtAno3().setText("2021");
        view.setVisible(true);

        view.getBtnBarras().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GraficoBarras();
            }
        });

        view.getBtnColunas().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GraficoColunas();
            }
        });

    }

    public void GraficoBarras() {

        String escolha;

        if (view.getjCheckBoxMédiaTemp().isSelected() == true) {
            escolha = "MÉDIA TEMPERATURA";
        } else if (view.getjCheckBoxMediaUmidade().isSelected() == true) {
            escolha = "MÉDIA UMIDADE";
        } else {
            escolha = "MÉDIA PRESSÃO";
        }

        WeatherDataModel weatherdata = new WeatherDataModel();
        // tira média referente ao mes 1
        int mes1 = Integer.parseInt((String) view.getjComboBoxMes1().getSelectedItem());
        int ano1 = Integer.parseInt(view.gettxtAno1().getText());
        // tira média referente ao mes 2
        int mes2 = Integer.parseInt((String) view.getjComboBoxMes2().getSelectedItem());
        int ano2 = Integer.parseInt(view.gettxtAno2().getText());
        // tira média referente ao mes 3
        int mes3 = Integer.parseInt((String) view.getjComboBoxMes3().getSelectedItem());
        int ano3 = Integer.parseInt(view.gettxtAno3().getText());

        weatherdata.setMes1(mes1);
        weatherdata.setAno1(ano1);
        weatherdata.setMes2(mes2);
        weatherdata.setAno2(ano2);
        weatherdata.setMes3(mes3);
        weatherdata.setAno3(ano3);
        weatherdata.setEscolha(escolha);

       
        Diretor diretor = new Diretor();
        
        weatherdata = diretor.ConstroiGraficoBarra(weatherdata);
        
        //GraficoBarrasBuilder constroi = new GraficoBarrasBuilder();

        // weatherdata = constroi.ConstroiGraficoBarra(weatherdata);

        DefaultCategoryDataset barChartdata = new DefaultCategoryDataset();
        barChartdata.setValue(weatherdata.getMedia1(), "Valor Por Mês", weatherdata.getNome_mes1());
        barChartdata.setValue(weatherdata.getMedia2(), "Valor Por Mês", weatherdata.getNome_mes2());
        barChartdata.setValue(weatherdata.getMedia3(), "Valor Por Mês", weatherdata.getNome_mes3());

        JFreeChart barChart = ChartFactory.createBarChart(escolha, weatherdata.getTitulohorizontal(), weatherdata.getTitulovertical(), barChartdata, PlotOrientation.HORIZONTAL, false, true, false);
        CategoryPlot barchrt = barChart.getCategoryPlot();
        barchrt.setRangeGridlinePaint(Color.BLUE);
        ChartPanel barPanel = new ChartPanel(barChart);

        view.getjPanelGrafico().removeAll();
        view.getjPanelGrafico().add(barPanel, BorderLayout.CENTER);
        view.getjPanelGrafico().validate();

    }

    public void GraficoColunas() {

        String escolha;

        if (view.getjCheckBoxMédiaTemp().isSelected() == true) {
            escolha = "MÉDIA TEMPERATURA";
        } else if (view.getjCheckBoxMediaUmidade().isSelected() == true) {
            escolha = "MÉDIA UMIDADE";
        } else {
            escolha = "MÉDIA PRESSÃO";
        }

        WeatherDataModel weatherdata = new WeatherDataModel();
        // tira média referente ao mes 1
        int mes1 = Integer.parseInt((String) view.getjComboBoxMes1().getSelectedItem());
        int ano1 = Integer.parseInt(view.gettxtAno1().getText());
        // tira média referente ao mes 2
        int mes2 = Integer.parseInt((String) view.getjComboBoxMes2().getSelectedItem());
        int ano2 = Integer.parseInt(view.gettxtAno2().getText());
        // tira média referente ao mes 3
        int mes3 = Integer.parseInt((String) view.getjComboBoxMes3().getSelectedItem());
        int ano3 = Integer.parseInt(view.gettxtAno3().getText());

        weatherdata.setMes1(mes1);
        weatherdata.setAno1(ano1);
        weatherdata.setMes2(mes2);
        weatherdata.setAno2(ano2);
        weatherdata.setMes3(mes3);
        weatherdata.setAno3(ano3);
        weatherdata.setEscolha(escolha);

        GraficoColunaBuilder constroi = new GraficoColunaBuilder();

        weatherdata = constroi.ConstroiGraficoColuna(weatherdata);

        DefaultCategoryDataset barChartdata = new DefaultCategoryDataset();
        barChartdata.setValue(weatherdata.getMedia1(), "Valor Por Mês", weatherdata.getNome_mes1());
        barChartdata.setValue(weatherdata.getMedia2(), "Valor Por Mês", weatherdata.getNome_mes2());
        barChartdata.setValue(weatherdata.getMedia3(), "Valor Por Mês", weatherdata.getNome_mes3());

        JFreeChart barChart = ChartFactory.createBarChart(escolha, weatherdata.getTitulohorizontal(), weatherdata.getTitulovertical(), barChartdata, PlotOrientation.VERTICAL, false, true, false);
        CategoryPlot barchrt = barChart.getCategoryPlot();
        barchrt.setRangeGridlinePaint(Color.BLUE);
        ChartPanel barPanel = new ChartPanel(barChart);

        view.getjPanelGrafico().removeAll();
        view.getjPanelGrafico().add(barPanel, BorderLayout.CENTER);
        view.getjPanelGrafico().validate();

    }

    @Override
    public void update() {
        GraficoColunas();
    }

}
