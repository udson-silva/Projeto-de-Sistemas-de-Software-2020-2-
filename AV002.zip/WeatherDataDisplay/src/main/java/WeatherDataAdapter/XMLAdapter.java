/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WeatherDataAdapter;

import Model.WeatherDataModel;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author udson
 */
public class XMLAdapter implements IlogAdapter {

    @Override
    public void Escrever(WeatherDataModel mod) {

        try {
            DocumentBuilderFactory documentbuiderfactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentbuilder = documentbuiderfactory.newDocumentBuilder();

            Document documentoXML = documentbuilder.newDocument();

            Element root = documentoXML.createElement(mod.getTipo_registro());
            documentoXML.appendChild(root);

            Element dados = documentoXML.createElement("Dados");
            Attr id = documentoXML.createAttribute("id");
            
            
            String identificador = String.valueOf(mod.getId());
            
            id.setValue(identificador);

            dados.setAttributeNode(id);

            root.appendChild(dados);

            Element data = documentoXML.createElement("data");
            
            String dat = mod.getData();
            String converte_data = dat.replace("/","-");

            data.appendChild(documentoXML.createTextNode(mod.getData()));
            
            dados.appendChild(data);
            
            Element temperatura = documentoXML.createElement("temperatura");

            String temp = String.valueOf(mod.getTemperatura());
            temperatura.appendChild(documentoXML.createTextNode(temp));
            
            dados.appendChild(temperatura);
            
            Element umidade = documentoXML.createElement("umidade");

            String umi = String.valueOf(mod.getUmidade());
            umidade.appendChild(documentoXML.createTextNode(umi));
            
            dados.appendChild(umidade);
            
            
            Element pressao = documentoXML.createElement("pressao");

            String pres = String.valueOf(mod.getPressao());
            pressao.appendChild(documentoXML.createTextNode(pres));
            
            dados.appendChild(pressao);
            
            

            TransformerFactory transformerfactory = TransformerFactory.newInstance();
            Transformer transformer = transformerfactory.newTransformer();

            DOMSource documentofonte = new DOMSource(documentoXML);

            StreamResult documentofinal = new StreamResult(new File("logxml/"+mod.getTipo_registro()+converte_data+umi+pres+".xml"));

            transformer.transform(documentofonte, documentofinal);

        } catch (ParserConfigurationException ex) {
            Logger.getLogger(XMLAdapter.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerConfigurationException ex) {
            Logger.getLogger(XMLAdapter.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerException ex) {
            Logger.getLogger(XMLAdapter.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
