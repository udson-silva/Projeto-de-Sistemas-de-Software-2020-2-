/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.WeatherDataModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author udson
 */
public class DadosGraficoDao {

    public WeatherDataModel PesquisaDadosMedios(WeatherDataModel weatherdatamodel) {

        WeatherDataModel weatherdata = new WeatherDataModel();

        float temp = 0, umid = 0, press = 0;

        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:weatherdata.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();

            ResultSet rs = stmt.executeQuery("SELECT * FROM DADOS_TEMPO WHERE MES=" + weatherdatamodel.getMes() + " AND ANO =" + weatherdatamodel.getAno() + " ");

            while (rs.next()) {

                float temperatura = rs.getFloat("temperatura");
                float umidade = rs.getFloat("umidade");
                float pressao = rs.getFloat("pressao");
                temp = temp + temperatura;
                umid = umid + umidade;
                press = press + pressao;

            }
            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            //System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        weatherdata.setMediatemperatura(temp);
        weatherdata.setMediaumidade(umid);
        weatherdata.setMediapressao(press);

        return weatherdata;

    }

}
