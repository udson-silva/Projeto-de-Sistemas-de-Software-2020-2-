/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.WeatherDataModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author udson
 */
public class WeatherDataDao {

    WeatherDataModel weatherdatamodel = new WeatherDataModel();

    public void inserirDados(WeatherDataModel weatherdata) {

        // observadores = new ArrayList<>();
        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("insert into dados_tempo(temperatura, umidade, pressao, data, dia,mes,ano) values ('" + weatherdata.getTemperatura() + "','" + weatherdata.getUmidade() + "','" + weatherdata.getPressao() + "','" + weatherdata.getData() + "','" + weatherdata.getDia() + "','" + weatherdata.getMes() + "','" + weatherdata.getAno() + "')");
            sql.executeUpdate();
            JOptionPane.showMessageDialog(null, "Dados Cadastrados com Sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "erro ao inserir os dados ! \n ERRO" + ex);
        } finally {
            ConexaoBanco.closeConnection(conexao);

        }

    }

    public void AlterarConfiguracao(String tipo_log) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("Update configuracoes set tipo_log = '" + tipo_log + "'");
            sql.executeUpdate();
            JOptionPane.showMessageDialog(null, " Tipo de Log Alterado com Sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "erro ao alterar os dados ! \n ERRO" + ex);
        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }

    public String PesquisaLog() {
        String tipo_log = null;
        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:weatherdata.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("select *from configuracoes");

            tipo_log = rs.getString("tipo_log");

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return tipo_log;
    }

    public void DeletarDado(WeatherDataModel weatherdata) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("Delete from dados_tempo where id = '" + weatherdata.getId() + "'");
            sql.executeUpdate();
            JOptionPane.showMessageDialog(null, " Dado Excluido com Sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "erro ao Excluir dado ! \n ERRO" + ex);
        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }

    public WeatherDataModel PesquisaUltimoDado(WeatherDataModel weatherdata) {

        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:weatherdata.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM DADOS_TEMPO ORDER BY ID DESC ");

            int id = rs.getInt("id");
            String data = rs.getString("data");
            float temperatura = rs.getFloat("temperatura");
            float umidade = rs.getFloat("umidade");
            float pressao = rs.getFloat("pressao");

            weatherdatamodel.setId(id);
            weatherdatamodel.setData(data);
            weatherdatamodel.setTemperatura(temperatura);
            weatherdatamodel.setUmidade(umidade);
            weatherdatamodel.setPressao(pressao);

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            //System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return weatherdatamodel;
    }

    public WeatherDataModel ContaRegistros(WeatherDataModel weatherdata) {

        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:weatherdata.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT COUNT(ID) AS CONTADOR FROM DADOS_TEMPO ORDER BY ID DESC ");

            int contador = rs.getInt("contador");

            weatherdatamodel.setContador(contador);

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            //System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return weatherdatamodel;
    }

    public WeatherDataModel PesquisaDadosMedios(WeatherDataModel weatherdata) {

        float temp = 0, umid = 0, press = 0;
        int contadorregistos = 0;

        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:weatherdata.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();

            ResultSet rs = stmt.executeQuery("SELECT * FROM DADOS_TEMPO WHERE DIA>=" + weatherdata.getDia_inicio() + " AND DIA<=" + weatherdata.getDia_fim() + " AND MES>=" + weatherdata.getMes_inicio() + " AND MES<=" + weatherdata.getMes_fim() + " AND ANO >=" + weatherdata.getAno_inicio() + " AND ANO <=" + weatherdata.getAno_fim() + " ");

            while (rs.next()) {

                float temperatura = rs.getFloat("temperatura");
                float umidade = rs.getFloat("umidade");
                float pressao = rs.getFloat("pressao");
                temp = temp + temperatura;
                umid = umid + umidade;
                press = press + pressao;
                contadorregistos++;
            }
            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            //System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        weatherdatamodel.setMediatemperatura(temp);
        weatherdatamodel.setMediaumidade(umid);
        weatherdatamodel.setMediapressao(press);
        weatherdatamodel.setContador(contadorregistos);

        return weatherdatamodel;

    }

    public ArrayList Preencher_Tabela(String sql) {

        ArrayList dados = new ArrayList();
        Connection c = null;
        Statement stmt = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:weatherdata.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            String[] Colunas = new String[]{"id", "Data", "Temperatura", "Umidade", "Pressão"};
            while (rs.next()) {

                int id = rs.getInt("id");
                String data = rs.getString("data");
                float temperatura = rs.getFloat("temperatura");
                float umidade = rs.getFloat("umidade");
                float pressao = rs.getFloat("pressao");

                dados.add(new Object[]{id, data, temperatura, umidade, pressao});
            }

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {

            // System.err.println(e.getClass().getName() + ": " + e.getMessage());
            // System.exit(0);
        }
        return dados;

    }
}
