/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proxy;

/**
 *
 * @author udson
 */
public class ImagemReal implements Imagem {

    private final String fileName;

    public ImagemReal(String fileName) {
        this.fileName = fileName;
        CarregandoImagemDisco(fileName);
    }

    public void CarregandoImagemDisco(String fileName) {
       System.out.println("Exibindo a miniatura da imagem " + fileName); 
    }

    @Override
    public void Exibir() {
         
       
    }

  
   
    

}
