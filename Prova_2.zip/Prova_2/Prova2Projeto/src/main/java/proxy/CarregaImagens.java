/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proxy;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import util.ManipularImagem;
import view.VisualizaImagensView;

/**
 *
 * @author udson
 */
public class CarregaImagens extends DefaultListCellRenderer {

    VisualizaImagensView view;
    ArrayList<ImagemProxy> imagens = new ArrayList<>();

    public CarregaImagens() {
        DefaultListModel listaimagens = new DefaultListModel();
        view = new VisualizaImagensView();

        view.getlbltexto().setText("<html><body>Clique na miniatura para exibir a imagem em alta resolução <br&gtcom HTML!</body></html>");

        view.setVisible(true);

        imagens.add(new ImagemProxy("imagens/Imagem1.jpg"));
        imagens.add(new ImagemProxy("imagens/Imagem2.jpg"));
        imagens.add(new ImagemProxy("imagens/Imagem3.jpg"));
        imagens.add(new ImagemProxy("imagens/Imagem4.jpg"));
        imagens.add(new ImagemProxy("imagens/Imagem5.jpg"));

        imagens.get(0).Exibir();
        imagens.get(1).Exibir();
        imagens.get(2).Exibir();
        imagens.get(3).Exibir();
        imagens.get(4).Exibir();

        System.out.println("");
        System.out.println("");

        for (int i = 0; i <= 4; i++) {
            BufferedImage imagem = ManipularImagem.setImagemDimensao(imagens.get(i).getNomeImagem(), 140, 140);
            ImageIcon label = new ImageIcon(imagem);

            listaimagens.addElement(label);
        }

        view.getjListImagens().setModel(listaimagens);

        view.getjListImagens().addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int index = view.getjListImagens().getSelectedIndex();
                BufferedImage imagem = ManipularImagem.setImagemDimensao(imagens.get(index).getNomeImagem(), 318, 361);
                view.getlblImagens().setIcon(new ImageIcon(imagem));
                imagens.get(index).Exibir();
                

            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

    }

}
