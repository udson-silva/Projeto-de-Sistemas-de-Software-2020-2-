/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controler;

import Model.WeatherDataModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author udson
 */
public class WeatherDataControler {

    WeatherDataModel mod = new WeatherDataModel();

    public void inserirDados(WeatherDataModel mod) {

        // observadores = new ArrayList<>();
        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("insert into dados_tempo(temperatura, umidade, pressao, data, dia,mes,ano) values ('" + mod.getTemperatura() + "','" + mod.getUmidade() + "','" + mod.getPressao() + "','" + mod.getData() + "','" + mod.getDia() + "','" + mod.getMes() + "','" + mod.getAno() + "')");
            sql.executeUpdate();
            JOptionPane.showMessageDialog(null, "Dados Cadastrados com Sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "erro ao inserir os dados ! \n ERRO" + ex);
        } finally {
            ConexaoBanco.closeConnection(conexao);

        }

    }

    public void AlterarConfiguracao(String tipo_log) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("Update configuracoes set tipo_log = '" + tipo_log + "'");
            sql.executeUpdate();
            JOptionPane.showMessageDialog(null, " Tipo de Log Alterado com Sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "erro ao alterar os dados ! \n ERRO" + ex);
        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }
    
    
    public String PesquisaLog() {
       String tipo_log = null;
        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:weatherdata.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("select *from configuracoes");

            tipo_log = rs.getString("tipo_log");

           

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return tipo_log;
    }

    
    
    
    
    

    public void DeletarDado(WeatherDataModel mod) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("Delete from dados_tempo where id = '" + mod.getId() + "'");
            sql.executeUpdate();
            JOptionPane.showMessageDialog(null, " Dado Excluido com Sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "erro ao Excluir dado ! \n ERRO" + ex);
        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }

    public WeatherDataModel PesquisaUltimoDado(WeatherDataModel modelo) {

        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:weatherdata.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM DADOS_TEMPO ORDER BY ID DESC ");

            int id = rs.getInt("id");
            String data = rs.getString("data");
            float temperatura = rs.getFloat("temperatura");
            float umidade = rs.getFloat("umidade");
            float pressao = rs.getFloat("pressao");

            mod.setId(id);
            mod.setData(data);
            mod.setTemperatura(temperatura);
            mod.setUmidade(umidade);
            mod.setPressao(pressao);

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return mod;
    }

    public WeatherDataModel ContaRegistros(WeatherDataModel modelo) {

        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:weatherdata.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT COUNT(ID) AS CONTADOR FROM DADOS_TEMPO ORDER BY ID DESC ");

            int contador = rs.getInt("contador");

            mod.setContador(contador);

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return mod;
    }

    public WeatherDataModel PesquisaDadosMedios(WeatherDataModel modelo) {

        float temp = 0, umid = 0, press = 0;
        int contadorregistos = 0;

        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:weatherdata.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();

            ResultSet rs = stmt.executeQuery("SELECT * FROM DADOS_TEMPO WHERE DIA>=" + modelo.getDia_inicio() + " AND DIA<=" + modelo.getDia_fim() + " AND MES>=" + modelo.getMes_inicio() + " AND MES<=" + modelo.getMes_fim() + " AND ANO >=" + modelo.getAno_inicio() + " AND ANO <=" + modelo.getAno_fim() + " ");

            while (rs.next()) {

                float temperatura = rs.getFloat("temperatura");
                float umidade = rs.getFloat("umidade");
                float pressao = rs.getFloat("pressao");
                temp = temp + temperatura;
                umid = umid + umidade;
                press = press + pressao;
                contadorregistos++;
            }
            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        mod.setMediatemperatura(temp);
        mod.setMediaumidade(umid);
        mod.setMediapressao(press);
        mod.setContador(contadorregistos);

        return mod;

    }

}
