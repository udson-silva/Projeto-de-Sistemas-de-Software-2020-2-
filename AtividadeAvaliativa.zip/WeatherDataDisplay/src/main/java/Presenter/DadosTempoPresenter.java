/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;


import Controler.WeatherDataControler;
import Model.WeatherDataModel;
import Observer.Observado;
import Observer.Observer;
import WeatherDataAdapter.IlogAdapter;
import WeatherDataAdapter.JSONAdapter;
import WeatherDataAdapter.XMLAdapter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JDesktopPane;
import views.DadosTempoView;

/**
 *
 * @author udson
 */
public class DadosTempoPresenter implements Observado{

    DadosTempoView view;
    WeatherDataControler controler = new WeatherDataControler();
    
     final ArrayList<Observer> observadores;
    public DadosTempoPresenter(JDesktopPane desktop, String tipo_de_log) {

        
        observadores = new ArrayList<Observer>();        
        view = new DadosTempoView();
        desktop.add(view);

        view.setVisible(true);

         view.getBtnFechar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                view.dispose();
            }
        });
         
         view.getBtnIncluir().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
             
                String data = view.gettxtData().getText();
                String convertedia = data.substring(0,2);
                String convertemes = data.substring(3,5);
                String converteano = data.substring(6);
               
                int dia = Integer.parseInt(convertedia);
                int mes =  Integer.parseInt(convertemes);
                int ano = Integer.parseInt(converteano);
                
              
                WeatherDataModel model = new WeatherDataModel();
                
                
               model.setDia(dia);
               model.setMes(mes);
               model.setAno(ano);
               model.setData(view.gettxtData().getText());
               model.setPressao(Float.parseFloat(view.gettxtPressao().getText()));
               model.setTemperatura(Float.parseFloat(view.gettxtTemperatura().getText()));
               model.setUmidade(Float.parseFloat(view.gettxtUmidade().getText())); 
              
               controler.inserirDados(model);
               
               if(tipo_de_log.equals("XML")){
                   
                     WeatherDataModel mod = new WeatherDataModel();
                     WeatherDataControler pesquisa = new WeatherDataControler();
                     WeatherDataModel modelo = pesquisa.PesquisaUltimoDado(mod);
                      
                     model.setId(modelo.getId());
                    model.setTipo_registro("INCLUSÃO");
                    IlogAdapter xml = new XMLAdapter();
                     xml.Escrever(model);
               }else{
                   
                    WeatherDataModel mod = new WeatherDataModel();
                     WeatherDataControler pesquisa = new WeatherDataControler();
                     WeatherDataModel modelo = pesquisa.PesquisaUltimoDado(mod);
                      
                    model.setId(modelo.getId());
                    model.setTipo_registro("INCLUSÃO");
                    IlogAdapter json = new JSONAdapter();
                     json.Escrever(model); 
                   
                   
                   
               }
               
               
               notifyObservers();
               
             
            }
         });

    }

    @Override
    public void registryObserver(Observer o) {
        if(!observadores.contains(o)){
          this.observadores.add(o);  
        }
        
    }

    @Override
    public void removeObserver(Observer o) {
       this.observadores.remove(o);
    }

    @Override
    public void notifyObservers() {
        
      for (Observer o : observadores) {
          
            o.update();
        }
    }

  

}
