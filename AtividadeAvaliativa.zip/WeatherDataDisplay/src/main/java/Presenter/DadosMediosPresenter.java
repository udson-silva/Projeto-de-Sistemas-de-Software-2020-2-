/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import Controler.WeatherDataControler;
import Model.WeatherDataModel;
import Observer.Observer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import views.DadosMediosView;
import javax.swing.JDesktopPane;

/**
 *
 * @author udson
 */
public class DadosMediosPresenter implements Observer{

    String datainicio, datafim;
    DadosMediosView view;

    public DadosMediosPresenter(JDesktopPane desktop) {

        view = new DadosMediosView();
        desktop.add(view);

        view.setVisible(true);

        view.getbtnGerarDados().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                GeraDados();

            }
        });

        view.getBtnFechar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                view.dispose();
            }
        });

    }

    public void GeraDados() {

        String data_inicial = view.gettxtdatainicio().getText();
        String data_final = view.gettxtDataFim().getText();

        String convertediainicial = data_inicial.substring(0, 2);
        String convertemesinicial = data_inicial.substring(3, 5);
        String converteanoinicial = data_inicial.substring(6);

        int diainicio = Integer.parseInt(convertediainicial);
        int mesinicio = Integer.parseInt(convertemesinicial);
        int anoinicio = Integer.parseInt(converteanoinicial);

        String convertediafim = data_final.substring(0, 2);
        String convertemesdatafim = data_final.substring(3, 5);
        String converteanodatafim = data_final.substring(6);

        int diafim = Integer.parseInt(convertediafim);
        int mesfim = Integer.parseInt(convertemesdatafim);
        int anofim = Integer.parseInt(converteanodatafim);

        WeatherDataModel mod = new WeatherDataModel();

        //data inicio encapsulada
        mod.setDia_inicio(diainicio);
        mod.setMes_inicio(mesinicio);
        mod.setAno_inicio(anoinicio);

        //data fim encapsulada
        mod.setDia_fim(diafim);
        mod.setMes_fim(mesfim);
        mod.setAno_fim(anofim);

        if (view.getJcomboboxPeriodo().getSelectedItem().equals("Diário")) {

            ContadoraDiasMesesPresenter contadora = new ContadoraDiasMesesPresenter();
            int dias = (int) contadora.DiferencaDatas(data_inicial, data_final);
            dias = dias+1;
            
            // 
            WeatherDataControler pesquisa = new WeatherDataControler();

            WeatherDataModel model = pesquisa.PesquisaDadosMedios(mod);
            
            float pressao =  model.getMediapressao();
            float temperatura = model.getMediatemperatura();
            float umidade = model.getMediaumidade();
            
            view.getJLabelTemperatura().setText(String.valueOf(temperatura/dias));
            view.getJLabelPressao().setText(String.valueOf(pressao/dias));
            view.getJLabelUmidade().setText(String.valueOf(umidade/dias));
            view.getJLabelNRegistros().setText(String.valueOf(model.getContador()));
            

        } else if (view.getJcomboboxPeriodo().getSelectedItem().equals("Semanal")) {

             ContadoraDiasMesesPresenter contadora = new ContadoraDiasMesesPresenter();
            int dias = (int) contadora.DiferencaDatas(data_inicial, data_final);
            dias = dias+1;
            float semanas = dias/7;
            System.out.println(semanas);
            
            // 
            WeatherDataControler pesquisa = new WeatherDataControler();

            WeatherDataModel model = pesquisa.PesquisaDadosMedios(mod);
            
            float pressao =  model.getMediapressao();
            float temperatura = model.getMediatemperatura();
            float umidade = model.getMediaumidade();
            
            view.getJLabelTemperatura().setText(String.valueOf(temperatura/semanas));
            view.getJLabelPressao().setText(String.valueOf(pressao/semanas));
            view.getJLabelUmidade().setText(String.valueOf(umidade/semanas));
            view.getJLabelNRegistros().setText(String.valueOf(model.getContador()));
            
          
            
            
        } else {
            
            
           int meses = mesfim - mesinicio;
           
           //quando o mes for 1
           if(meses==0){
               meses = meses+1;
           }
           
          
            
            // 
            WeatherDataControler pesquisa = new WeatherDataControler();

            WeatherDataModel model = pesquisa.PesquisaDadosMedios(mod);
            
            float pressao =  model.getMediapressao();
            float temperatura = model.getMediatemperatura();
            float umidade = model.getMediaumidade();
            
            view.getJLabelTemperatura().setText(String.valueOf(temperatura/meses));
            view.getJLabelPressao().setText(String.valueOf(pressao/meses));
            view.getJLabelUmidade().setText(String.valueOf(umidade/meses));
            view.getJLabelNRegistros().setText(String.valueOf(model.getContador()));
            
            

        }

    }
    
    
     public void GeraDadosObserver() {

        String data_inicial = "01/01/2021";
        String data_final = "28/01/2021";

        String convertediainicial = data_inicial.substring(0, 2);
        String convertemesinicial = data_inicial.substring(3, 5);
        String converteanoinicial = data_inicial.substring(6);

        int diainicio = Integer.parseInt(convertediainicial);
        int mesinicio = Integer.parseInt(convertemesinicial);
        int anoinicio = Integer.parseInt(converteanoinicial);

        String convertediafim = data_final.substring(0, 2);
        String convertemesdatafim = data_final.substring(3, 5);
        String converteanodatafim = data_final.substring(6);

        int diafim = Integer.parseInt(convertediafim);
        int mesfim = Integer.parseInt(convertemesdatafim);
        int anofim = Integer.parseInt(converteanodatafim);

        WeatherDataModel mod = new WeatherDataModel();

        //data inicio encapsulada
        mod.setDia_inicio(diainicio);
        mod.setMes_inicio(mesinicio);
        mod.setAno_inicio(anoinicio);

        //data fim encapsulada
        mod.setDia_fim(diafim);
        mod.setMes_fim(mesfim);
        mod.setAno_fim(anofim);

        if (view.getJcomboboxPeriodo().getSelectedItem().equals("Diário")) {

            ContadoraDiasMesesPresenter contadora = new ContadoraDiasMesesPresenter();
            int dias = (int) contadora.DiferencaDatas(data_inicial, data_final);
            dias = dias+1;
            
            // 
            WeatherDataControler pesquisa = new WeatherDataControler();

            WeatherDataModel model = pesquisa.PesquisaDadosMedios(mod);
            
            float pressao =  model.getMediapressao();
            float temperatura = model.getMediatemperatura();
            float umidade = model.getMediaumidade();
            
            view.getJLabelTemperatura().setText(String.valueOf(temperatura/dias));
            view.getJLabelPressao().setText(String.valueOf(pressao/dias));
            view.getJLabelUmidade().setText(String.valueOf(umidade/dias));
            view.getJLabelNRegistros().setText(String.valueOf(model.getContador()));
            

        } else if (view.getJcomboboxPeriodo().getSelectedItem().equals("Semanal")) {

             ContadoraDiasMesesPresenter contadora = new ContadoraDiasMesesPresenter();
            int dias = (int) contadora.DiferencaDatas(data_inicial, data_final);
            dias = dias+1;
            float semanas = dias/7;
            //System.out.println(semanas);
            
            // 
            WeatherDataControler pesquisa = new WeatherDataControler();

            WeatherDataModel model = pesquisa.PesquisaDadosMedios(mod);
            
            float pressao =  model.getMediapressao();
            float temperatura = model.getMediatemperatura();
            float umidade = model.getMediaumidade();
            
            view.getJLabelTemperatura().setText(String.valueOf(temperatura/semanas));
            view.getJLabelPressao().setText(String.valueOf(pressao/semanas));
            view.getJLabelUmidade().setText(String.valueOf(umidade/semanas));
            view.getJLabelNRegistros().setText(String.valueOf(model.getContador()));
            
          
            
            
        } else {
            
            
           int meses = mesfim - mesinicio;
           
           //quando o mes for 1
           if(meses==0){
               meses = meses+1;
           }
           
          
            
            // 
            WeatherDataControler pesquisa = new WeatherDataControler();

            WeatherDataModel model = pesquisa.PesquisaDadosMedios(mod);
            
            float pressao =  model.getMediapressao();
            float temperatura = model.getMediatemperatura();
            float umidade = model.getMediaumidade();
            
            view.getJLabelTemperatura().setText(String.valueOf(temperatura/meses));
            view.getJLabelPressao().setText(String.valueOf(pressao/meses));
            view.getJLabelUmidade().setText(String.valueOf(umidade/meses));
            view.getJLabelNRegistros().setText(String.valueOf(model.getContador()));
            
            

        }

    }
    
    

    @Override
    public void update() {
        GeraDadosObserver();
    }

}
