/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author udson
 */
public class ContadoraDiasMesesPresenter {
    
    
    public  int contadordeMeses(Date data_inicial, Date data_fim) {

        Calendar calini = Calendar.getInstance();
        Calendar calfim = Calendar.getInstance();

        calini.setTime(data_inicial);
        calfim.setTime(data_fim);

        int anoliq = calfim.get(Calendar.YEAR) - calini.get(Calendar.YEAR);
        int mesliq = calfim.get(Calendar.MONTH) - calini.get(Calendar.MONTH);
        int totmes = anoliq * 12 + mesliq;

        calini.set(Calendar.YEAR, calfim.get(Calendar.YEAR));
        calini.set(Calendar.MONTH, calfim.get(Calendar.MONTH));

        return (calini.after(calfim)) ? totmes - 1 : totmes;

    }

    public  int anoBisexto(int ano_inicial, int ano_fim) {

        int contador_ano = ano_fim - ano_inicial;

        int qtd_anos_bissexto = 0;

        for (int i = 0; i <= contador_ano; i++) {
            // se o ano for maior que 400
            if (ano_inicial % 400 == 0) {
               
                qtd_anos_bissexto = qtd_anos_bissexto + 1;
                // se o ano for menor que 400
            } else if ((ano_inicial % 4 == 0) && (ano_inicial % 100 != 0)) {
               
                qtd_anos_bissexto = qtd_anos_bissexto + 1;
            } else {
               
            }

            ano_inicial = ano_inicial + 1;

        }

        return qtd_anos_bissexto;
    }

  
public long DiferencaDatas(String data_inicial, String data_final){
	
     
    
    //converte as datas de vencimento e pagamento em substring
      String dia_inicio = data_inicial.substring(0,2);
      String mes_inicio = data_inicial.substring(3,5);
      String ano_inicio = data_inicial.substring(6,10);
      
      //transformna o mes em inteiro
       int contador_mes = Integer.parseInt(mes_inicio);
       int soma_meses, verifica_dias = 0;
       int dias_ano = 0;
      
      
      String dia_final = data_final.substring(0,2);
      String mes_final = data_final.substring(3,5);
      String ano_final = data_final.substring(6,10);
      
      //formata em localdate
    LocalDate data_de_vencimento = LocalDate.of(Integer.parseInt(ano_inicio),Integer.parseInt(mes_inicio), Integer.parseInt(dia_inicio)); 
    LocalDate data_de_pagamento = LocalDate.of(Integer.parseInt(ano_final),Integer.parseInt(mes_final), Integer.parseInt(dia_final));
     
     //verifica a diferença entre datas mes e ano
     int ano = Period.between(data_de_vencimento, data_de_pagamento).getYears();
     int mes = Period.between(data_de_vencimento, data_de_pagamento).getMonths();
     int dias = Period.between(data_de_vencimento, data_de_pagamento).getDays();
      
     // System.out.println("ano"+ano);
      //System.out.println("mes"+mes);
      //System.out.println("dia"+ dias);
     
      //verifica ano bisexto
     int VerificaAnoBisexto = anoBisexto(Integer.parseInt(ano_inicio), Integer.parseInt(ano_final));
     
      
      if(ano > 0){
          
         dias_ano  = (ano * 365) + VerificaAnoBisexto;
         
      }
      //
      
      // soma o mes da data atual mas os meses de atraso
      soma_meses = contador_mes + mes;
      
      //faz a atribuição de dias
      if(mes > 0){
         for(int i = contador_mes + 1;i<=soma_meses;i++){
             switch (i) {
                 case 1:
                     verifica_dias = 31;
                     break;
                 case 2:
                     verifica_dias = verifica_dias + 28;
                     break;
                 case 3:
                     verifica_dias = verifica_dias + 31;
                     break;
                 case 4:
                     verifica_dias = verifica_dias + 30;
                     break;
                 case 5:
                     verifica_dias = verifica_dias + 31;
                     break;
                 case 6:
                     verifica_dias = verifica_dias + 30;
                     break;
                 case 7:
                     verifica_dias = verifica_dias + 31;
                     break;
                 case 8:
                     verifica_dias = verifica_dias + 31;
                     break;
                 case 9:
                     verifica_dias = verifica_dias + 30;
                     break;
                 case 10:
                     verifica_dias = verifica_dias + 31;
                     break;
                 case 11:
                     verifica_dias = verifica_dias + 30;
                     break;
                 case 12:
                     verifica_dias = verifica_dias + 31;
                     //passou de 12 significa que está em outro ano e volta para janeiro de novo
                     break;
                 case 13:
                     verifica_dias = verifica_dias + 31;
                     break;
                 case 14:
                     verifica_dias = verifica_dias + 28;
                     break;
                 case 15:
                     verifica_dias = verifica_dias + 31;
                     break;
                 case 16:
                     verifica_dias = verifica_dias + 30;
                     break;
                 case 17:
                     verifica_dias = verifica_dias + 31;
                     break;
                 case 18:
                     verifica_dias = verifica_dias + 30;
                     break;
                 case 19:
                     verifica_dias = verifica_dias + 31;
                     break;
                 case 20:
                     verifica_dias = verifica_dias + 31;
                     break;
                 case 21:
                     verifica_dias = verifica_dias + 30;
                     break;
                 case 22:
                     verifica_dias = verifica_dias + 31;
                     break;
                 case 23:
                     verifica_dias = verifica_dias + 30;
                     break;
                 case 24:
                     verifica_dias = verifica_dias + 31;
                 default:
                     break;
             }
          
          
                          
      }          
                             
         
      }
      
       //dias do ano + dias dos meses + dias
         
           int resultado_dias = dias_ano + verifica_dias + dias;
         
           
         
           return resultado_dias;
    
    
		
	}          
    
    
}
