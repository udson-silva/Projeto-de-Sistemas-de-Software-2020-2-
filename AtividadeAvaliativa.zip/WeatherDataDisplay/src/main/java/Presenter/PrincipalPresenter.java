/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import Controler.WeatherDataControler;
import Model.WeatherDataModel;
import Observer.Observado;
import Observer.Observer;
import java.awt.AWTKeyStroke;
import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.beans.PropertyVetoException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JInternalFrame;
import views.PrincipalView;
import views.DadosTempoView;

/**
 *
 * @author udson
 */
public class PrincipalPresenter implements Observer{
    
    String tipo_de_log;
    private final PrincipalView view;
    DadosTempoPresenter dados;
    RegistrosPresenter registros;
    PrincipalPresenter instancia;
    
  
    public PrincipalPresenter(){
    
        view = new PrincipalView();
        
        instancia = this;
       
        
        Atualizacontador();
        TipoLog();
       
        
        view.getbtnDadosMedio().setEnabled(false);
        view.getbtnUtimaAtualizacao().setEnabled(false);
        view.getbtnRegistros().setEnabled(false);
      
        
        view.setVisible(true);

        view.getbtnDadosTempo().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

               dados = new DadosTempoPresenter(view.getjDesktopPanePrincipal(), tipo_de_log);
               
               dados.registryObserver((Observer)instancia);
               view.getbtnRegistros().setEnabled(true);
            }
        });
        
        
        view.getbtnDadosMedio().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
             
               DadosMediosPresenter dadosmedio = new DadosMediosPresenter(view.getjDesktopPanePrincipal());
                dados.registryObserver((Observer) dadosmedio); 
                registros.registryObserver((Observer) dadosmedio);
                //System.out.println(dados.observadores.size());
            }
        });
        
        view.getbtnUtimaAtualizacao().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
             
             UltimaAtualizacaoPresenter ultimaatualizacao = new UltimaAtualizacaoPresenter(view.getjDesktopPanePrincipal());
              dados.registryObserver((Observer) ultimaatualizacao);  
              registros.registryObserver((Observer) ultimaatualizacao);
            }
        });
        
        view.getbtnRegistros().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
              
                registros = new RegistrosPresenter(view.getjDesktopPanePrincipal(),tipo_de_log);
                dados.registryObserver((Observer) registros); 
                registros.registryObserver((Observer)instancia);
                view.getbtnDadosMedio().setEnabled(true);
                view.getbtnUtimaAtualizacao().setEnabled(true);
      
            }
        });
        
        
        
        view.getbtnConfiguracoes().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
             
                
             ConfiguracoesPresenter configura = new ConfiguracoesPresenter(view.getjDesktopPanePrincipal());
                
            }
        });

    }
    
    
    
   public void Atualizacontador(){
       
         WeatherDataModel mod = new WeatherDataModel();
        WeatherDataControler pesquisa = new WeatherDataControler();

        WeatherDataModel model = pesquisa.ContaRegistros(mod);
        
        view.getjLabelNumeroRegistrosTempo().setText(String.valueOf(model.getContador()));
         
       
   }
   
   public void TipoLog(){
       
        
        WeatherDataControler pesquisa = new WeatherDataControler();

        tipo_de_log = pesquisa.PesquisaLog();
        
      
         
       
   }

    @Override
    public void update() {
       Atualizacontador();
    }

    
  

}
