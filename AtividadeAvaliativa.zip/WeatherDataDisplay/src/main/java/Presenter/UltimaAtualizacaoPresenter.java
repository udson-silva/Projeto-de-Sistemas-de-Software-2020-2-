/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import Controler.WeatherDataControler;
import Model.WeatherDataModel;
import Observer.Observer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JDesktopPane;
import views.UltimaAtualizacaoView;

/**
 *
 * @author udson
 */
public class UltimaAtualizacaoPresenter implements Observer{
    
      UltimaAtualizacaoView view;

    public UltimaAtualizacaoPresenter(JDesktopPane desktop) {

        view = new UltimaAtualizacaoView();
        desktop.add(view);

        view.setVisible(true);
        
        WeatherDataModel mod = new WeatherDataModel();
        WeatherDataControler pesquisa = new WeatherDataControler();

        WeatherDataModel model = pesquisa.PesquisaUltimoDado(mod);
        
        view.getJLabelData().setText(model.getData());
        view.getjLabelPressao().setText(String.valueOf(model.getPressao()));
        view.getjLabelTemperatura().setText(String.valueOf(model.getTemperatura()));
        view.getjLabelUmidade().setText(String.valueOf(model.getUmidade()));
        
        

        view.getbtnFechar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                view.dispose();
            }
        });

    }

    @Override
    public void update() {
        
         WeatherDataModel mod = new WeatherDataModel();
        WeatherDataControler pesquisa = new WeatherDataControler();

        WeatherDataModel model = pesquisa.PesquisaUltimoDado(mod);
        
        view.getJLabelData().setText(model.getData());
        view.getjLabelPressao().setText(String.valueOf(model.getPressao()));
        view.getjLabelTemperatura().setText(String.valueOf(model.getTemperatura()));
        view.getjLabelUmidade().setText(String.valueOf(model.getUmidade()));
        
    }
    
    
    
    
    
}
