/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import Controler.WeatherDataControler;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JDesktopPane;
import views.ConfiguracaoSistemaView;

/**
 *
 * @author udson
 */
public class ConfiguracoesPresenter {
    
    ConfiguracaoSistemaView view;
    
    public ConfiguracoesPresenter(JDesktopPane desktop){
        
        view = new ConfiguracaoSistemaView();
         desktop.add(view);
        view.setVisible(true);
        
        
        view.getbtnSalvar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
             
             
                String tipo_log = (String) view.getjComboBoxLog().getSelectedItem();
                
                WeatherDataControler alterar = new WeatherDataControler();
                
                alterar.AlterarConfiguracao(tipo_log);
                
                System.exit(0);
                
                
            }
        });
        
        view.getBtnFechar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
           
                view.dispose();
            }
        });
        
        
    }
    
    
    
}
