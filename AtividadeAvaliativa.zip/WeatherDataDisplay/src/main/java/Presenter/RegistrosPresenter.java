/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import Controler.ConexaoBanco;
import Controler.WeatherDataControler;
import Model.ModelTabela;
import Model.WeatherDataModel;
import Observer.Observado;
import Observer.Observer;
import WeatherDataAdapter.IlogAdapter;
import WeatherDataAdapter.JSONAdapter;
import WeatherDataAdapter.XMLAdapter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JDesktopPane;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import views.RegistrosView;

/**
 *
 * @author udson
 */
public class RegistrosPresenter implements Observer, Observado {

    RegistrosView view;
    ConexaoBanco conTabela = new ConexaoBanco();
    int id = 0;
    float temperatura = 0, umidade = 0, pressao = 0;
    String data;
    
     final ArrayList<Observer> observadores2;
    public RegistrosPresenter(JDesktopPane desktop,String tipo_de_log) {
     observadores2 = new ArrayList<Observer>();  
        view = new RegistrosView();
        desktop.add(view);

        Preencher_Tabela("select *from dados_tempo");

        view.setVisible(true);

        view.getBtnFechar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                view.dispose();
            }
        });

        view.getjTableRegistros().addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent arg0) {

                id = (int) view.getjTableRegistros().getValueAt(view.getjTableRegistros().getSelectedRow(), 0);
                data = (String) view.getjTableRegistros().getValueAt(view.getjTableRegistros().getSelectedRow(), 1);
                temperatura = (float) view.getjTableRegistros().getValueAt(view.getjTableRegistros().getSelectedRow(), 2);
                umidade = (float) view.getjTableRegistros().getValueAt(view.getjTableRegistros().getSelectedRow(), 3);
                pressao = (float) view.getjTableRegistros().getValueAt(view.getjTableRegistros().getSelectedRow(), 4);
            }

            @Override
            public void mousePressed(MouseEvent arg0) {

            }

            @Override
            public void mouseReleased(MouseEvent arg0) {

            }

            @Override
            public void mouseEntered(MouseEvent arg0) {

            }

            @Override
            public void mouseExited(MouseEvent arg0) {

            }
        });

        view.getbtnRemover().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                if (id != 0) {
                    WeatherDataModel model = new WeatherDataModel();
                    model.setId(id);

                    WeatherDataControler control = new WeatherDataControler();
                    control.DeletarDado(model);
                    Preencher_Tabela("select *from dados_tempo");
                    
                     if(tipo_de_log.equals("XML")){
                   
                   
                    model.setId(id);
                    model.setData(data);
                    model.setTemperatura(temperatura);
                    model.setUmidade(umidade);
                    model.setPressao(pressao);
                    model.setTipo_registro("EXCLUSÃO");
                    IlogAdapter xml = new XMLAdapter();
                     xml.Escrever(model);
               }else{
                   
                    model.setId(id);
                    model.setData(data);
                    model.setTemperatura(temperatura);
                    model.setUmidade(umidade);
                    model.setPressao(pressao);
                    model.setTipo_registro("EXCLUSÃO");
                    IlogAdapter json = new JSONAdapter();
                     json.Escrever(model); 
                   
                   
                   
               }
               
                  notifyObservers();

                } else {
                    JOptionPane.showMessageDialog(view, "FAVOR SELECIONAR UM DADO NA TABELA!");

                }
                

            }
        });

    }
    public void Preencher_Tabela(String sql) {

        Connection c = null;
        Statement stmt = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:weatherdata.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            ArrayList dados = new ArrayList();

            String[] Colunas = new String[]{"id", "Data", "Temperatura", "Umidade", "Pressão"};
            while (rs.next()) {

                int id = rs.getInt("id");
                String data = rs.getString("data");
                float temperatura = rs.getFloat("temperatura");
                float umidade = rs.getFloat("umidade");
                float pressao = rs.getFloat("pressao");

                dados.add(new Object[]{id, data, temperatura, umidade, pressao});
            }

            ModelTabela modelo = new ModelTabela(dados, Colunas);

            view.getjTableRegistros().setModel(modelo);

            view.getjTableRegistros().getColumnModel().getColumn(0).setPreferredWidth(30);
            view.getjTableRegistros().getColumnModel().getColumn(0).setResizable(false);
            view.getjTableRegistros().getColumnModel().getColumn(1).setPreferredWidth(100);
            view.getjTableRegistros().getColumnModel().getColumn(1).setResizable(false);
            view.getjTableRegistros().getColumnModel().getColumn(2).setPreferredWidth(100);
            view.getjTableRegistros().getColumnModel().getColumn(2).setResizable(false);
            view.getjTableRegistros().getColumnModel().getColumn(3).setPreferredWidth(70);
            view.getjTableRegistros().getColumnModel().getColumn(3).setResizable(false);
            view.getjTableRegistros().getColumnModel().getColumn(4).setPreferredWidth(70);
            view.getjTableRegistros().getColumnModel().getColumn(4).setResizable(false);
            view.getjTableRegistros().setRowHeight(35);
            view.getjTableRegistros().getTableHeader().setReorderingAllowed(false);
            view.getjTableRegistros().setAutoResizeMode(view.getjTableRegistros().AUTO_RESIZE_OFF);
            view.getjTableRegistros().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {

            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

    }

    @Override
    public void update() {
        Preencher_Tabela("select *from dados_tempo");
    }

    @Override
    public void registryObserver(Observer o) {
       if(!observadores2.contains(o)){
          this.observadores2.add(o);  
        }
    }

    @Override
    public void removeObserver(Observer o) {
     this.observadores2.remove(o);  
    }

    @Override
    public void notifyObservers() {
         for (Observer o : observadores2) {
          
            o.update();
        }
    }

    

}
