/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graficodecorator;
public abstract class GraficoDecorator implements Grafico{
	private final Grafico graficoDecorador;
	
	public GraficoDecorator(Grafico grafico) {
		this.graficoDecorador = grafico;
	}
	
	@Override
    public float CalculoFinanceiro(int id_republica, String mes, String ano) { 
        
       
            return 0;
        
      
    }

    @Override
    public String TituloGrafico() {
        return graficoDecorador.TituloGrafico();
    }

	public Grafico getGrafico() {
		return graficoDecorador;
	}
}
