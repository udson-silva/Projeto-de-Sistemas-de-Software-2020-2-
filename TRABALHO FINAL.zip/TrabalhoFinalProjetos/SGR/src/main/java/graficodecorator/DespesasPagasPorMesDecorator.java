/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graficodecorator;

import dao.GraficoFinanceiroPorMesDao;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import presenter.NomeMesPresenter;

public class DespesasPagasPorMesDecorator extends GraficoDecorator {
	public DespesasPagasPorMesDecorator(Grafico grafico) {
		super(grafico);
		// TODO Auto-generated constructor stub
	}
	
	@Override
    public float CalculoFinanceiro(int id_republica, String mes, String ano) {
         float despesaspagas = 0;
            try {
               
                
                NomeMesPresenter pesquisanomemes = new NomeMesPresenter();
                 String nome_mes = pesquisanomemes.NomeMes(mes);
                
                
                GraficoFinanceiroPorMesDao graficofinanceiro = new GraficoFinanceiroPorMesDao();
                
                despesaspagas = graficofinanceiro.TotalDespesasPagas(id_republica, nome_mes, ano);
                
                
            } catch (SQLException ex) {
                Logger.getLogger(DespesasPagasPorMesDecorator.class.getName()).log(Level.SEVERE, null, ex);
            }
            return despesaspagas;
    }

    @Override
    public String TituloGrafico() {
        return "DESPESAS PAGAS";
    }
}
