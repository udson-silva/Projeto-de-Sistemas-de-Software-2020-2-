/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graficodecorator;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import views.GraficosView;

/**
 *
 * @author udson
 */
public class GraficoPresenter {

    GraficosView view;
    String mes, ano;
    int codrepublica;

    public GraficoPresenter(int id_republica) {

        codrepublica = id_republica;

        view = new GraficosView();
        view.setVisible(true);

        view.getbtnexibirgrafico().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                mes = (String) view.getjComboBoxMeses().getSelectedItem();
                ano = view.gettxtAno().getText();

                if (view.getjComboBoxTipoGrafico().getSelectedItem().equals("Barras Verticais")) {

                    GraficoBarrasVertical();
                } else {
                    GraficoBarrasHorizontais();
                }

            }
        });

    }

    private void GraficoBarrasVertical() {

        float total_despesas, total_despesas_pagas, total_receitas_recebidas, saldo_total;
        String titulo1, titulo2, titulo3, tituloPrincipal,titulovalores,rotulo;

        Grafico graficobarrasvertical = new DespesasPorMesDecorator();

        total_despesas = graficobarrasvertical.CalculoFinanceiro(codrepublica, mes, ano);
        titulo1 = graficobarrasvertical.TituloGrafico();
       

        graficobarrasvertical = new ReceitasRecebidasPorMesDecorator(graficobarrasvertical);

        total_receitas_recebidas= graficobarrasvertical.CalculoFinanceiro(codrepublica, mes, ano);
        titulo2 = graficobarrasvertical.TituloGrafico();

        
        graficobarrasvertical = new DespesasPagasPorMesDecorator(graficobarrasvertical);
        titulo3 = graficobarrasvertical.TituloGrafico();
        total_despesas_pagas = graficobarrasvertical.CalculoFinanceiro(codrepublica, mes, ano);
        
        
        graficobarrasvertical = new TituloPrincipalDecorator(graficobarrasvertical);
        
        tituloPrincipal = graficobarrasvertical.TituloGrafico();
        
        
        graficobarrasvertical = new TituloGraficoValoresDecorator(graficobarrasvertical);
        titulovalores = graficobarrasvertical.TituloGrafico();
        
        graficobarrasvertical = new RotuloLegendasDecorator(graficobarrasvertical);
        rotulo = graficobarrasvertical.TituloGrafico();
        
        
      
        saldo_total = total_receitas_recebidas  - total_despesas_pagas ;
        
        DefaultCategoryDataset barChartdata = new DefaultCategoryDataset();
        barChartdata.setValue(total_despesas, "", titulo1);
        barChartdata.setValue(total_despesas_pagas,"", titulo3);
        barChartdata.setValue(total_receitas_recebidas, "", titulo2);
        barChartdata.setValue(saldo_total, "", "SALDO");

        JFreeChart barChart = ChartFactory.createBarChart(tituloPrincipal, rotulo,titulovalores, barChartdata, PlotOrientation.VERTICAL, false, true, false);
        CategoryPlot barchrt = barChart.getCategoryPlot();
        barchrt.setRangeGridlinePaint(Color.BLUE);
        ChartPanel barPanel = new ChartPanel(barChart);

        view.getjPanelGrafico().removeAll();
        view.getjPanelGrafico().add(barPanel, BorderLayout.CENTER);
        view.getjPanelGrafico().validate();

    }

    private void GraficoBarrasHorizontais() {

        float total_despesas, total_despesas_pagas, total_receitas_recebidas, saldo_total;
        String titulo1, titulo2, titulo3,tituloPrincipal, rotulo, titulovalores;

        Grafico graficobarrashorizontal = new DespesasPorMesDecorator();

        total_despesas = graficobarrashorizontal.CalculoFinanceiro(codrepublica, mes, ano);
        titulo1 = graficobarrashorizontal.TituloGrafico();
        

        graficobarrashorizontal = new ReceitasRecebidasPorMesDecorator(graficobarrashorizontal);

        total_receitas_recebidas = graficobarrashorizontal.CalculoFinanceiro(codrepublica, mes, ano);
        titulo2 = graficobarrashorizontal.TituloGrafico();

        
        graficobarrashorizontal = new DespesasPagasPorMesDecorator(graficobarrashorizontal);
        titulo3 = graficobarrashorizontal.TituloGrafico();
        
         total_despesas_pagas = graficobarrashorizontal.CalculoFinanceiro(codrepublica, mes, ano);
       

        graficobarrashorizontal = new TituloPrincipalDecorator(graficobarrashorizontal);
        
        tituloPrincipal = graficobarrashorizontal.TituloGrafico();
        
        graficobarrashorizontal = new TituloGraficoValoresDecorator(graficobarrashorizontal);
        titulovalores = graficobarrashorizontal.TituloGrafico();
        
        graficobarrashorizontal = new RotuloLegendasDecorator(graficobarrashorizontal);
        rotulo = graficobarrashorizontal.TituloGrafico();
        
       
        
         saldo_total = total_receitas_recebidas  - total_despesas_pagas ;
        
        DefaultCategoryDataset barChartdata = new DefaultCategoryDataset();
        barChartdata.setValue(total_despesas, "", titulo1);
        barChartdata.setValue(total_despesas_pagas,"", titulo3);
        barChartdata.setValue(total_receitas_recebidas, "", titulo2);
        barChartdata.setValue(saldo_total, "", "SALDO");

        JFreeChart barChart = ChartFactory.createBarChart(tituloPrincipal, rotulo,titulovalores, barChartdata, PlotOrientation.HORIZONTAL, false, true, false);
        CategoryPlot barchrt = barChart.getCategoryPlot();
        barchrt.setRangeGridlinePaint(Color.BLUE);
        ChartPanel barPanel = new ChartPanel(barChart);

        view.getjPanelGrafico().removeAll();
        view.getjPanelGrafico().add(barPanel, BorderLayout.CENTER);
        view.getjPanelGrafico().validate();

    }

}
