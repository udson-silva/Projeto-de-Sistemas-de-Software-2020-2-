/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graficodecorator;

/**
 *
 * @author udson
 */
public class TituloGraficoValoresDecorator extends GraficoDecorator{
    
    public TituloGraficoValoresDecorator(Grafico grafico) {
        super(grafico);
    }
    
    
      @Override
    public String TituloGrafico() {
        return "VALORES DO MÊS";
    }
    
    
}
