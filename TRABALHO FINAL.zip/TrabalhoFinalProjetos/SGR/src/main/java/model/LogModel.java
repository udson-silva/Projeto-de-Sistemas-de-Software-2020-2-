/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author udson
 */
public class LogModel {

     private String tipo_log;
     private String tipo_persistencia;
     private String operacao;
     private String data;
     private String nome;
     private String hora;
     private String usuario;
     
    
    
     
       /**
     * @return the operacao
     */
    public String getOperacao() {
        return operacao;
    }

    /**
     * @param operacao the operacao to set
     */
    public void setOperacao(String operacao) {
        this.operacao = operacao;
    }

    /**
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the hora
     */
    public String getHora() {
        return hora;
    }

    /**
     * @param hora the hora to set
     */
    public void setHora(String hora) {
        this.hora = hora;
    }

    /**
     * @return the usuario
     */
    public String getUsuario() {
        return usuario;
    }

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
     
     
    /**
     * @return the tipo_log
     */
    public String getTipo_log() {
        return tipo_log;
    }

    /**
     * @param tipo_log the tipo_log to set
     */
    public void setTipo_log(String tipo_log) {
        this.tipo_log = tipo_log;
    }

    /**
     * @return the tipo_persistencia
     */
    public String getTipo_persistencia() {
        return tipo_persistencia;
    }

    /**
     * @param tipo_persistencia the tipo_persistencia to set
     */
    public void setTipo_persistencia(String tipo_persistencia) {
        this.tipo_persistencia = tipo_persistencia;
    }
    
    
}
