/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author udson
 */
public class SolicitaMoradiaModel {

    private String nome_solicitante;
    private String republica_atual;
    private String republica_solicitada;
    private String status;
    private String perfilredesocial;
    private int id_perfil_usuario;
    
    
    /**
     * @return the republica_solicitada
     */
    public String getRepublica_solicitada() {
        return republica_solicitada;
    }

    /**
     * @param republica_solicitada the republica_solicitada to set
     */
    public void setRepublica_solicitada(String republica_solicitada) {
        this.republica_solicitada = republica_solicitada;
    }

    /**
     * @return the nome_solicitante
     */
    public String getNome_solicitante() {
        return nome_solicitante;
    }

    /**
     * @param nome_solicitante the nome_solicitante to set
     */
    public void setNome_solicitante(String nome_solicitante) {
        this.nome_solicitante = nome_solicitante;
    }

    /**
     * @return the republica_atual
     */
    public String getRepublica_atual() {
        return republica_atual;
    }

    /**
     * @param republica_atual the republica_atual to set
     */
    public void setRepublica_atual(String republica_atual) {
        this.republica_atual = republica_atual;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the perfilredesocial
     */
    public String getPerfilredesocial() {
        return perfilredesocial;
    }

    /**
     * @param perfilredesocial the perfilredesocial to set
     */
    public void setPerfilredesocial(String perfilredesocial) {
        this.perfilredesocial = perfilredesocial;
    }

    /**
     * @return the id_perfil_usuario
     */
    public int getId_perfil_usuario() {
        return id_perfil_usuario;
    }

    /**
     * @param id_perfil_usuario the id_perfil_usuario to set
     */
    public void setId_perfil_usuario(int id_perfil_usuario) {
        this.id_perfil_usuario = id_perfil_usuario;
    }
    
    
    
    
}
