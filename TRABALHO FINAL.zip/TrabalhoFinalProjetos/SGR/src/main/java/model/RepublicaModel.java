/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;



/**
 *
 * @author udson
 */
public class RepublicaModel {

    
    
   private String nomeRepublica;
   private String dataFundacao;
   private float despesaMedia;
   private int totalVagas;
   private int vagasDisponiveis;
   private int vagasOcupadas;
   private int id_usuario;
   private int id_republica;
   private String vantagens;
   private String codigoEtica;
   private String logradouro;
   private String bairro;
   private String referencia;
   private String localizacaoGeografica;
   private String CEP;
   private String nome_morador;

    
    /**
     * @return the nome_morador
     */
    public String getNome_morador() {
        return nome_morador;
    }

    /**
     * @param nome_morador the nome_morador to set
     */
    public void setNome_morador(String nome_morador) {
        this.nome_morador = nome_morador;
    }

    /**
     * @return the id_republica
     */
    public int getId_republica() {
        return id_republica;
    }

    /**
     * @param id_republica the id_republica to set
     */
    public void setId_republica(int id_republica) {
        this.id_republica = id_republica;
    }

    /**
     * @return the id_usuario
     */
    public int getId_usuario() {
        return id_usuario;
    }

    /**
     * @param id_usuario the id_usuario to set
     */
    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

   
  
   

     /**
     * @return the despesaMedia
     */
    public float getDespesaMedia() {
        return despesaMedia;
    }

    /**
     * @param despesaMedia the despesaMedia to set
     */
    public void setDespesaMedia(float despesaMedia) {
        this.despesaMedia = despesaMedia;
    }
    
    
    public String getNomeRepublica() {
        return nomeRepublica;
    }

    public void setNomeRepublica(String nomeRepublica) {
        this.nomeRepublica = nomeRepublica;
    }

    public String getDataFundacao() {
        return dataFundacao;
    }

    public void setDataFundacao(String dataFundacao) {
        this.dataFundacao = dataFundacao;
    }

  
    public int getTotalVagas() {
        return totalVagas;
    }

    public void setTotalVagas(int totalVagas) {
        this.totalVagas = totalVagas;
    }

    public int getVagasDisponiveis() {
        return vagasDisponiveis;
    }

    public void setVagasDisponiveis(int vagasDisponiveis) {
        this.vagasDisponiveis = vagasDisponiveis;
    }

    public int getVagasOcupadas() {
        return vagasOcupadas;
    }

    public void setVagasOcupadas(int vagasOcupadas) {
        this.vagasOcupadas = vagasOcupadas;
    }

    public String getVantagens() {
        return vantagens;
    }

    public void setVantagens(String vantagens) {
        this.vantagens = vantagens;
    }

    public String getCodigoEtica() {
        return codigoEtica;
    }

    public void setCodigoEtica(String codigoEtica) {
        this.codigoEtica = codigoEtica;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getLocalizacaoGeografica() {
        return localizacaoGeografica;
    }

    public void setLocalizacaoGeografica(String localizacaoGeografica) {
        this.localizacaoGeografica = localizacaoGeografica;
    }

    public String getCEP() {
        return CEP;
    }

    public void setCEP(String CEP) {
        this.CEP = CEP;
    }
   
}
