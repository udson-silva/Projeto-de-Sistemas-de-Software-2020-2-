/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author udson
 */
public class UsuarioModel {

   
   
    private String nome_usuario;
    private String senha;
    private String status;
    private int id_usuario;
    private String apelido;
    private String telefone;
    private String link_rede;
    private String telefone_resp1;
    private String telefone_resp2;
    private String tipo_perfil;
   
    
    /**
     * @return the apelido
     */
    public String getApelido() {
        return apelido;
    }

    /**
     * @param apelido the apelido to set
     */
    public void setApelido(String apelido) {
        this.apelido = apelido;
    }

   
    
    
    /**
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the link_rede
     */
    public String getLink_rede() {
        return link_rede;
    }

    /**
     * @param link_rede the link_rede to set
     */
    public void setLink_rede(String link_rede) {
        this.link_rede = link_rede;
    }

    /**
     * @return the telefone_resp1
     */
    public String getTelefone_resp1() {
        return telefone_resp1;
    }

    /**
     * @param telefone_resp1 the telefone_resp1 to set
     */
    public void setTelefone_resp1(String telefone_resp1) {
        this.telefone_resp1 = telefone_resp1;
    }

    /**
     * @return the telefone_resp2
     */
    public String getTelefone_resp2() {
        return telefone_resp2;
    }

    /**
     * @param telefone_resp2 the telefone_resp2 to set
     */
    public void setTelefone_resp2(String telefone_resp2) {
        this.telefone_resp2 = telefone_resp2;
    }

    /**
     * @return the tipo_perfil
     */
    public String getTipo_perfil() {
        return tipo_perfil;
    }

    /**
     * @param tipo_perfil the tipo_perfil to set
     */
    public void setTipo_perfil(String tipo_perfil) {
        this.tipo_perfil = tipo_perfil;
    }

    

    /**
     * @return the id_usuario
     */
    public int getId_usuario() {
        return id_usuario;
    }

    /**
     * @param id_usuario the id_usuario to set
     */
    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    /**
     * @return the nome_usuario
     */
    public String getNome_usuario() {
        return nome_usuario;
    }

    /**
     * @param nome_usuario the nome_usuario to set
     */
    public void setNome_usuario(String nome_usuario) {
        this.nome_usuario = nome_usuario;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

}
