/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author udson
 */
public class ConviteMoradorModel {

   

    
   private int id_republica;
   private int id_convite_morador;
   private String status;
   private String data_convite;
   private int id_convidador;
   private int id_usuario_convidado;
   
   
   
    /**
     * @return the id_convidador
     */
    public int getId_convidador() {
        return id_convidador;
    }

    /**
     * @param id_convidador the id_convidador to set
     */
    public void setId_convidador(int id_convidador) {
        this.id_convidador = id_convidador;
    }

    /**
     * @return the id_usuario_convidado
     */
    public int getId_usuario_convidado() {
        return id_usuario_convidado;
    }

    /**
     * @param id_usuario_convidado the id_usuario_convidado to set
     */
    public void setId_usuario_convidado(int id_usuario_convidado) {
        this.id_usuario_convidado = id_usuario_convidado;
    } 
    
    
    /**
     * @return the id_republica
     */
    public int getId_republica() {
        return id_republica;
    }

    /**
     * @param id_republica the id_republica to set
     */
    public void setId_republica(int id_republica) {
        this.id_republica = id_republica;
    }

    /**
     * @return the id_convite_morador
     */
    public int getId_convite_morador() {
        return id_convite_morador;
    }

    /**
     * @param id_convite_morador the id_convite_morador to set
     */
    public void setId_convite_morador(int id_convite_morador) {
        this.id_convite_morador = id_convite_morador;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the data_convite
     */
    public String getData_convite() {
        return data_convite;
    }

    /**
     * @param data_convite the data_convite to set
     */
    public void setData_convite(String data_convite) {
        this.data_convite = data_convite;
    }
    
  
    
    
    
}
