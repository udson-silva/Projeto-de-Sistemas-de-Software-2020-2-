/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author udson
 */
public class MoradorRepublicaModel {

   
    private int id_morador;
    private int id_republica;
    private String nome_morador;
    private String data_ingresso;
    private float rateio;
    
    
    
    /**
     * @return the id_morador
     */
    public int getId_morador() {
        return id_morador;
    }

    /**
     * @param id_morador the id_morador to set
     */
    public void setId_morador(int id_morador) {
        this.id_morador = id_morador;
    }

   

    /**
     * @return the id_republicas
     */
    public int getId_republica() {
        return id_republica;
    }

    /**
     * @param id_republica the id_republicas to set
     */
    public void setId_republica(int id_republica) {
        this.id_republica = id_republica;
    }

    /**
     * @return the nome_morador
     */
    public String getNome_morador() {
        return nome_morador;
    }

    /**
     * @param nome_morador the nome_morador to set
     */
    public void setNome_morador(String nome_morador) {
        this.nome_morador = nome_morador;
    }

    /**
     * @return the data_ingresso
     */
    public String getData_ingresso() {
        return data_ingresso;
    }

    /**
     * @param data_ingresso the data_ingresso to set
     */
    public void setData_ingresso(String data_ingresso) {
        this.data_ingresso = data_ingresso;
    }

    /**
     * @return the rateio
     */
    public float getRateio() {
        return rateio;
    }

    /**
     * @param rateio the rateio to set
     */
    public void setRateio(float rateio) {
        this.rateio = rateio;
    }
    
    
    
    
}
