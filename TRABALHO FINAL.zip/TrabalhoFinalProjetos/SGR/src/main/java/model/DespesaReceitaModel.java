/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author udson
 */
public class DespesaReceitaModel {

    private int id_usuario;
    private String periodicidade;
    private String descricao;
    private String data_vencimento;
    private float valor;
    private float valor_dividido;
    private float valor_pago;
    private String status;
    private String data_cadastro;
    private String tipofatura;
    private String nome_usuario;
    private int id_despesas;
    private int id_receitas;
    private int id_republica;
    private String mes;
   
    
     /**
     * @return the mes
     */
    public String getMes() {
        return mes;
    }

    /**
     * @param mes the mes to set
     */
    public void setMes(String mes) {
        this.mes = mes;
    }
    
    
    
     /**
     * @return the id_republica
     */
    public int getId_republica() {
        return id_republica;
    }

    /**
     * @param id_republica the id_republica to set
     */
    public void setId_republica(int id_republica) {
        this.id_republica = id_republica;
    }
    
    
    /**
     * @return the id_despesas
     */
    public int getId_despesas() {
        return id_despesas;
    }

    /**
     * @param id_despesas the id_despesas to set
     */
    public void setId_despesas(int id_despesas) {
        this.id_despesas = id_despesas;
    }

    /**
     * @return the id_receitas
     */
    public int getId_receitas() {
        return id_receitas;
    }

    /**
     * @param id_receitas the id_receitas to set
     */
    public void setId_receitas(int id_receitas) {
        this.id_receitas = id_receitas;
    }
    
    
    /**
     * @return the nome_usuario
     */
    public String getNome_usuario() {
        return nome_usuario;
    }

    /**
     * @param nome_usuario the nome_usuario to set
     */
    public void setNome_usuario(String nome_usuario) {
        this.nome_usuario = nome_usuario;
    }

    /**
     * @return the tipofatura
     */
    public String getTipofatura() {
        return tipofatura;
    }

    /**
     * @param tipofatura the tipofatura to set
     */
    public void setTipofatura(String tipofatura) {
        this.tipofatura = tipofatura;
    }

    /**
     * @return the data_cadastro
     */
    public String getData_cadastro() {
        return data_cadastro;
    }

    /**
     * @param data_cadastro the data_cadastro to set
     */
    public void setData_cadastro(String data_cadastro) {
        this.data_cadastro = data_cadastro;
    }

    /**
     * @return the id_usuario
     */
    public int getId_usuario() {
        return id_usuario;
    }

    /**
     * @param id_usuario the id_usuario to set
     */
    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    /**
     * @return the periodicidade
     */
    public String getPeriodicidade() {
        return periodicidade;
    }

    /**
     * @param periodicidade the periodicidade to set
     */
    public void setPeriodicidade(String periodicidade) {
        this.periodicidade = periodicidade;
    }

    /**
     * @return the descricao
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * @param descricao the descricao to set
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    /**
     * @return the data_vencimento
     */
    public String getData_vencimento() {
        return data_vencimento;
    }

    /**
     * @param data_vencimento the data_vencimento to set
     */
    public void setData_vencimento(String data_vencimento) {
        this.data_vencimento = data_vencimento;
    }

    /**
     * @return the valor
     */
    public float getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(float valor) {
        this.valor = valor;
    }

    /**
     * @return the valor_dividido
     */
    public float getValor_dividido() {
        return valor_dividido;
    }

    /**
     * @param valor_dividido the valor_dividido to set
     */
    public void setValor_dividido(float valor_dividido) {
        this.valor_dividido = valor_dividido;
    }

    /**
     * @return the valor_pago
     */
    public float getValor_pago() {
        return valor_pago;
    }

    /**
     * @param valor_pago the valor_pago to set
     */
    public void setValor_pago(float valor_pago) {
        this.valor_pago = valor_pago;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

}
