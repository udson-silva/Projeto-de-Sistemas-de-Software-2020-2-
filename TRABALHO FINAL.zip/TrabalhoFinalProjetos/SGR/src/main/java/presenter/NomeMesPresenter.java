/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

/**
 *
 * @author udson
 */
public class NomeMesPresenter {
    
    
    
    public NomeMesPresenter(){
        
    }
    
    
    
     public String NomeMes(String mes) {
        
      String nome_mes ="";
      
       switch (mes) {
                case "JANEIRO":
                    nome_mes ="/01/";
                    break;
                case "FEVEREIRO":
                    nome_mes = "/02/";
                    break;
                case "MARÇO":
                   nome_mes = "/03/";
                    break;
                case "ABRIL":
                   nome_mes = "/04/";
                    break;
                case "MAIO":
                    nome_mes = "/05/";
                    break;
                case "JUNHO":
                    nome_mes = "/06/";
                    break;
                case "JULHO":
                    nome_mes = "/07/";
                    break;
                case "AGOSTO":
                    nome_mes = "/08/";
                    break;
                case "SETEMBRO":
                    nome_mes = "/09/";
                    break;
                case "OUTUBRO":
                    nome_mes = "/10/";
                    break;
                case "NOVEMBRO":
                   nome_mes = "/11/";
                    break;
                case "DEZEMBRO":
                   nome_mes = "/12/";
                    break;
                default:
                    nome_mes = "TODOS OS MESES";
                    break;
            }
        return nome_mes;
        
       
    }
  
    
    
    
}
