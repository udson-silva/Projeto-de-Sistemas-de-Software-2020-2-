/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import dao.UsuarioDao;
import model.UsuarioModel;
import views.CadastroUsuarioView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;


/**
 *
 * @author udson
 */
public class CadastroUsuarioPresenter {
    
    CadastroUsuarioView view;
    
    public CadastroUsuarioPresenter() {
        view = new CadastroUsuarioView();
        
        view.setVisible(true);
        
        view.getBtnCadastrar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                
                UsuarioModel usuariomodel = new UsuarioModel();
                UsuarioDao usuariodao = new UsuarioDao();
                
                String senha = view.getTxtSenha().getText();
                String contrasenha = view.getTxtSenhaConfirmaçao().getText();
                
                if (senha.equals(contrasenha)) {
                    usuariomodel.setNome_usuario(view.getTxtUsuario().getText());
                    usuariomodel.setSenha(view.getTxtSenha().getText());
                    usuariomodel.setStatus("SEM TETO");
                    usuariodao.inserirUsuario(usuariomodel);
                     JOptionPane.showMessageDialog(view, "Usuário Cadastrado com Sucesso!");
                    view.getTxtUsuario().setText("");
                    view.getTxtSenha().setText("");
                    view.getTxtSenhaConfirmaçao().setText("");
                    LoginPresenter login = new LoginPresenter();
                    view.dispose();
                    
                } else {
                    JOptionPane.showMessageDialog(view, "AS SENHAS NÃO CONFEREM!");
                    view.getTxtSenha().setText("");
                    view.getTxtSenhaConfirmaçao().setText("");
                    
                }
                
            }
        });
        
        view.getBtnCancelar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                LoginPresenter login = new LoginPresenter();
                view.dispose();
            }
        });
        
    }
    
}
