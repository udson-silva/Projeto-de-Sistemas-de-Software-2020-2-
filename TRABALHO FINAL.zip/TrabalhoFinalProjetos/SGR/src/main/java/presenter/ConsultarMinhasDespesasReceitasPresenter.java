/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import dao.TabelaDespesasDao;
import dao.TabelaReceitasDao;
import model.ModelTabela;
import views.ConsultarMinhasDespesasReceitasView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ListSelectionModel;
import observer.Observer;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JOptionPane;
import model.DespesaReceitaModel;

/**
 *
 * @author udson
 */
public class ConsultarMinhasDespesasReceitasPresenter implements Observer {

    int cod_usuario, id = 0;
    String tipo_pesquisa, descricao, data_vencimento;
    float valor, valor_pago;
    ConsultarMinhasDespesasReceitasPresenter instancia;
    ConfirmaPagamentoRecebimento confirmar;
    ConsultarMinhasDespesasReceitasView view;

    public ConsultarMinhasDespesasReceitasPresenter(int id_usuario, int id_republica) {

        instancia = this;

        cod_usuario = id_usuario;

        view = new ConsultarMinhasDespesasReceitasView();

        view.setVisible(true);

        view.getbtnpesquisar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    tipo_pesquisa = (String) view.getjComboBoxTipo().getSelectedItem();

                    Preencher_Tabela(id_usuario, tipo_pesquisa);
                } catch (SQLException ex) {
                    Logger.getLogger(ConsultarMinhasDespesasReceitasPresenter.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });

        view.getbtnConfirmarPagamentoRecebido().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DespesaReceitaModel despesareceita = new DespesaReceitaModel();
                despesareceita.setId_despesas(id);
                despesareceita.setTipofatura(tipo_pesquisa);
                despesareceita.setDescricao(descricao);
                despesareceita.setData_vencimento(data_vencimento);
                despesareceita.setValor_dividido(valor);
                despesareceita.setValor_pago(valor_pago);

                if (id != 0) {
                    confirmar = new ConfirmaPagamentoRecebimento(despesareceita);
                    confirmar.registryObserver((Observer) instancia);
                } else {
                    JOptionPane.showMessageDialog(view, "Selecione um " + tipo_pesquisa + " na tabela!");
                }

            }
        });

        view.getbtnConsultarResultadoRepublica().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                ConsultarResultadoMensalPresenter consultarresultadomensal = new ConsultarResultadoMensalPresenter(id_republica);

            }
        });

        view.getjTableDadosFinanceiro().addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

                id = (int) view.getjTableDadosFinanceiro().getValueAt(view.getjTableDadosFinanceiro().getSelectedRow(), 0);
                descricao = (String) view.getjTableDadosFinanceiro().getValueAt(view.getjTableDadosFinanceiro().getSelectedRow(), 1);
                data_vencimento = (String) view.getjTableDadosFinanceiro().getValueAt(view.getjTableDadosFinanceiro().getSelectedRow(), 2);
                valor = (float) view.getjTableDadosFinanceiro().getValueAt(view.getjTableDadosFinanceiro().getSelectedRow(), 3);
                valor_pago = (float) view.getjTableDadosFinanceiro().getValueAt(view.getjTableDadosFinanceiro().getSelectedRow(), 4);

            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

    }

    private void Preencher_Tabela(int id_usuario, String tipo_pesquisa) throws SQLException {

        ArrayList dados = new ArrayList();
        String[] Colunas;

        if (tipo_pesquisa.equals("RECEITA")) {
            TabelaReceitasDao buscareceitas = new TabelaReceitasDao();
            dados = buscareceitas.Preencher_TabelaReceitas(id_usuario);
            Colunas = new String[]{"Cód", "Descrição", "Data Vencimento", "Valor", "Valor Recebido", "Status"};
        } else {
            TabelaDespesasDao buscadespesas = new TabelaDespesasDao();

            dados = buscadespesas.Preencher_TabelaDespesas(id_usuario);
            Colunas = new String[]{"Cód", "Descrição", "Data Vencimento", "Valor", "Valor Pago", "Status"};
        }

        try {

            ModelTabela modelo = new ModelTabela(dados, Colunas);

            view.getjTableDadosFinanceiro().setModel(modelo);

            view.getjTableDadosFinanceiro().getColumnModel().getColumn(0).setPreferredWidth(40);
            view.getjTableDadosFinanceiro().getColumnModel().getColumn(0).setResizable(false);
            view.getjTableDadosFinanceiro().getColumnModel().getColumn(1).setPreferredWidth(185);
            view.getjTableDadosFinanceiro().getColumnModel().getColumn(1).setResizable(false);
            view.getjTableDadosFinanceiro().getColumnModel().getColumn(2).setPreferredWidth(100);
            view.getjTableDadosFinanceiro().getColumnModel().getColumn(2).setResizable(false);
            view.getjTableDadosFinanceiro().getColumnModel().getColumn(3).setPreferredWidth(100);
            view.getjTableDadosFinanceiro().getColumnModel().getColumn(3).setResizable(false);
            view.getjTableDadosFinanceiro().getColumnModel().getColumn(4).setPreferredWidth(100);
            view.getjTableDadosFinanceiro().getColumnModel().getColumn(4).setResizable(false);
            view.getjTableDadosFinanceiro().getColumnModel().getColumn(5).setPreferredWidth(90);
            view.getjTableDadosFinanceiro().getColumnModel().getColumn(5).setResizable(false);

            view.getjTableDadosFinanceiro().setRowHeight(35);
            view.getjTableDadosFinanceiro().getTableHeader().setReorderingAllowed(false);
            view.getjTableDadosFinanceiro().setAutoResizeMode(view.getjTableDadosFinanceiro().AUTO_RESIZE_OFF);
            view.getjTableDadosFinanceiro().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        } catch (Exception e) {

            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

    }

    @Override
    public void update() {
        try {
            Preencher_Tabela(cod_usuario, tipo_pesquisa);
        } catch (SQLException ex) {
            Logger.getLogger(ConsultarMinhasDespesasReceitasPresenter.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
