/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import Model.LogModel;
import adapter.RegistrosdeLog;
import dao.DespesasDao;
import dao.ReceitasDao;
import dao.TabelaMoradorRepublica;
import model.DespesaReceitaModel;
import views.NovaReceitaDespesaView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;

/**
 *
 * @author Pessoal
 */
public class ReceitaDespesaPresenter {

    NovaReceitaDespesaView view;

    JList lista;
    private float valor_dividido, valor;
    String tipo_fatura, periodicidade;
    String nome_morador = null, nome_responsavel = null;
    DefaultListModel moradores = new DefaultListModel();
    DefaultListModel responsaveis = new DefaultListModel();

    public ReceitaDespesaPresenter(int id_republica) throws SQLException {

        view = new NovaReceitaDespesaView();

        Preencher_TabelaMoradores(id_republica);

        view.getjRadioButtonReceita().setSelected(true);
        view.getjRadioButtonIndefinido().setSelected(true);

        //pega a data do sistema e formata em mes e ano
        Date dataSistema = new Date();
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        String datacadastro = formato.format(dataSistema);

        view.gettxtDataCadastro().setText(datacadastro);

        view.setVisible(true);

        view.getbtnConfirma().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                //verifica qual o tipo de fatura do usuario
                if (view.getjRadioButtonDespesa().isSelected() == true) {
                    tipo_fatura = "DESPESA";
                } else {
                    tipo_fatura = "RECEITA";
                }

                int nresponsaveis = responsaveis.size();
                //informa que é preciso ter pelo menos um responsável pela fatura
                if (nresponsaveis != 0) {

                    if (view.getjRadioButtonAnual().isSelected() == true) {
                        periodicidade = "ANUAL";
                    } else if (view.getjRadioButtonSemanal().isSelected() == true) {
                        periodicidade = "SEMANAL";
                    } else if (view.getjRadioButtonMensal().isSelected() == true) {
                        periodicidade = "MENSAL";
                    } else {
                        periodicidade = "INDEFINIDO";
                    }

                    if (tipo_fatura.equals("DESPESA")) {
                        IncluirDespesa(periodicidade, id_republica);
                        JOptionPane.showMessageDialog(view, "" + tipo_fatura + " CADASTRADA COM SUCESSO!");
                    } else {
                        IncluirReceita(periodicidade, id_republica);
                        JOptionPane.showMessageDialog(view, "" + tipo_fatura + " CADASTRADA COM SUCESSO!");
                    }

                    //limpando os campos 
                    view.getjRadioButtonReceita().setSelected(true);
                    view.getjRadioButtonIndefinido().setSelected(true);
                    view.gettxtDescricao().setText("");
                    view.gettxtDataVencimento().setText("");
                    view.gettxtvalor().setText("");

                    moradores.clear();
                    responsaveis.clear();

                    LogModel logmodel = new LogModel();

                    logmodel.setUsuario(String.valueOf(id_republica));
                    logmodel.setOperacao("Inclusão Receita/Despesa");
                    logmodel.setNome(String.valueOf(id_republica));

                    RegistrosdeLog gravarlog = new RegistrosdeLog();
                    gravarlog.GravaLog(logmodel);

                    try {
                        Preencher_TabelaMoradores(id_republica);
                    } catch (SQLException ex) {
                        Logger.getLogger(ReceitaDespesaPresenter.class.getName()).log(Level.SEVERE, null, ex);
                    }

                } else {
                    JOptionPane.showMessageDialog(view, "É NECESSÁRIO TER PELO MENOS UM RESPONSÁVEL PELA " + tipo_fatura + "");
                }

            }
        }
        );

        view.getbtnDireita().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (nome_morador != null) {
                    int index = view.getjListMoradores().getSelectedIndex();
                    responsaveis.addElement(nome_morador);
                    view.getjListResponsaveis().setModel(responsaveis);
                    moradores.removeElementAt(index);

                    view.getjListMoradores().setModel(moradores);
                    nome_morador = null;

                }

            }
        });

        view.getbtnEsquerda().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (nome_responsavel != null) {
                    int index = view.getjListResponsaveis().getSelectedIndex();
                    moradores.addElement(nome_responsavel);
                    view.getjListMoradores().setModel(moradores);
                    responsaveis.removeElementAt(index);

                    view.getjListResponsaveis().setModel(responsaveis);
                    nome_responsavel = null;

                }

            }
        });

        view.getjListResponsaveis().addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

                nome_responsavel = view.getjListResponsaveis().getSelectedValue();
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        view.getjListMoradores().addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

                nome_morador = view.getjListMoradores().getSelectedValue();

            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }

        });
    }

    private void IncluirDespesa(String periodicidade, int id_republica) {

        DespesaReceitaModel despesareceitamodel = new DespesaReceitaModel();
        int nresponsaveis = responsaveis.size();

        for (int i = 0; i < responsaveis.size(); i++) {
            try {

                despesareceitamodel.setDescricao(view.gettxtDescricao().getText());
                despesareceitamodel.setData_cadastro(view.gettxtDataCadastro().getText());
                despesareceitamodel.setData_vencimento(view.gettxtDataVencimento().getText());
                despesareceitamodel.setValor(Float.parseFloat(view.gettxtvalor().getText()));
                valor = Float.parseFloat(view.gettxtvalor().getText());
                valor_dividido = valor / nresponsaveis;
                despesareceitamodel.setValor_dividido(valor_dividido);
                despesareceitamodel.setValor_pago(0);
                despesareceitamodel.setStatus("A PAGAR");
                despesareceitamodel.setPeriodicidade(periodicidade);
                despesareceitamodel.setId_republica(id_republica);
                //pesquisa o id do usuario
                nome_responsavel = (String) responsaveis.get(i);

                TabelaMoradorRepublica pesquisamorador = new TabelaMoradorRepublica();
                int id_morador = pesquisamorador.PesquisaMoradores(nome_responsavel);
                despesareceitamodel.setId_usuario(id_morador);

                //incluindo no banco de dados 
                DespesasDao incluirdespesas = new DespesasDao();

                incluirdespesas.inserirDespesas(despesareceitamodel);

            } catch (SQLException ex) {
                Logger.getLogger(ReceitaDespesaPresenter.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

    private void IncluirReceita(String periodicidade, int id_republica) {

        DespesaReceitaModel despesareceitamodel = new DespesaReceitaModel();
        int nresponsaveis = responsaveis.size();

        for (int i = 0; i < responsaveis.size(); i++) {
            try {

                despesareceitamodel.setDescricao(view.gettxtDescricao().getText());
                despesareceitamodel.setData_cadastro(view.gettxtDataCadastro().getText());
                despesareceitamodel.setData_vencimento(view.gettxtDataVencimento().getText());
                despesareceitamodel.setValor(Float.parseFloat(view.gettxtvalor().getText()));
                valor = Float.parseFloat(view.gettxtvalor().getText());
                valor_dividido = valor / nresponsaveis;
                despesareceitamodel.setValor_dividido(valor_dividido);
                despesareceitamodel.setValor_pago(0);
                despesareceitamodel.setStatus("A RECEBER");
                despesareceitamodel.setPeriodicidade(periodicidade);
                despesareceitamodel.setId_republica(id_republica);
                //pesquisa o id do usuario
                nome_responsavel = (String) responsaveis.get(i);

                TabelaMoradorRepublica pesquisamorador = new TabelaMoradorRepublica();
                int id_morador = pesquisamorador.PesquisaMoradores(nome_responsavel);
                despesareceitamodel.setId_usuario(id_morador);

                //incluindo no banco de dados 
                ReceitasDao incluirreceitas = new ReceitasDao();
                incluirreceitas.inserirReceitasDao(despesareceitamodel);

            } catch (SQLException ex) {
                Logger.getLogger(ReceitaDespesaPresenter.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

    private void Preencher_TabelaMoradores(int id_republica) throws SQLException {

        ArrayList dados = new ArrayList();
        TabelaMoradorRepublica buscarmorador = new TabelaMoradorRepublica();

        dados = buscarmorador.Preencher_Tabela(id_republica);

        String nome;

        for (int i = 0; i < dados.size(); ++i) {
            nome = (String) dados.get(i);
            moradores.addElement(nome);

        }

        view.getjListMoradores().setModel(moradores);

    }

}
