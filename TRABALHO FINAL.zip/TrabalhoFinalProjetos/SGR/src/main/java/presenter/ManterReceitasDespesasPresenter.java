/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import dao.TabelaDespesasDao;
import dao.TabelaMoradorRepublica;
import dao.TabelaReceitasDao;
import model.ModelTabela;
import views.ManterReceitasDepesasView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ListSelectionModel;

/**
 *
 * @author Pessoal
 */
public class ManterReceitasDespesasPresenter {

    ManterReceitasDepesasView view;
    String tipo_pesquisa;

    public ManterReceitasDespesasPresenter(int id_republica) {

        view = new ManterReceitasDepesasView();
        view.gettxtpesquisadata().setEnabled(false);
        view.getjComboBoxPessoa().setEnabled(false);
        try {
            preencherComboPessoa(id_republica);
        } catch (SQLException ex) {
            Logger.getLogger(ManterReceitasDespesasPresenter.class.getName()).log(Level.SEVERE, null, ex);
        }
        view.setVisible(true);

        view.getbtnNovaDespesaReceita().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    ReceitaDespesaPresenter receitasdespesas = new ReceitaDespesaPresenter(id_republica);
                } catch (SQLException ex) {
                    Logger.getLogger(ManterReceitasDespesasPresenter.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });

        view.getjComboBoxtipoPesquisa().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (view.getjComboBoxtipoPesquisa().getSelectedItem().equals("Pessoa")) {
                    tipo_pesquisa = "Pessoa";
                    view.getjComboBoxPessoa().setEnabled(true);
                    view.gettxtpesquisadata().setEnabled(false);

                } else {
                    view.gettxtpesquisadata().setEnabled(true);
                    view.getjComboBoxPessoa().setEnabled(false);
                    tipo_pesquisa = "Data";
                }

            }
        });

        view.getbtnBuscar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                //verifica que tipo de pesquisa é se é receita ou despesa
                if (view.getjComboBoxTipo().getSelectedItem().equals("RECEITA")) {

                    String pesquisa;
                    if (tipo_pesquisa.equals("Pessoa")) {

                        try {
                            pesquisa = (String) view.getjComboBoxPessoa().getSelectedItem();

                            Preencher_TabelaReceita(pesquisa, tipo_pesquisa);
                        } catch (SQLException ex) {
                            Logger.getLogger(ManterReceitasDespesasPresenter.class.getName()).log(Level.SEVERE, null, ex);
                        }

                    } else {
                        try {
                            pesquisa = view.gettxtpesquisadata().getText();
                            Preencher_TabelaReceita(pesquisa, tipo_pesquisa);
                        } catch (SQLException ex) {
                            Logger.getLogger(ManterReceitasDespesasPresenter.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }

                } else {

                    String pesquisa;
                    if (tipo_pesquisa.equals("Pessoa")) {

                        try {
                            pesquisa = (String) view.getjComboBoxPessoa().getSelectedItem();

                            Preencher_TabelaDespesa(pesquisa, tipo_pesquisa);
                        } catch (SQLException ex) {
                            Logger.getLogger(ManterReceitasDespesasPresenter.class.getName()).log(Level.SEVERE, null, ex);
                        }

                    } else {
                        try {
                            pesquisa = view.gettxtpesquisadata().getText();
                            Preencher_TabelaDespesa(pesquisa, tipo_pesquisa);
                        } catch (SQLException ex) {
                            Logger.getLogger(ManterReceitasDespesasPresenter.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }

                }

            }
        });

    }

    public final void preencherComboPessoa(int id_republica) throws SQLException {

        ArrayList dados = new ArrayList();
        TabelaMoradorRepublica buscarmorador = new TabelaMoradorRepublica();

        dados = buscarmorador.Preencher_Tabela(id_republica);

        view.getjComboBoxPessoa().removeAllItems();
        for (int i = 0; i < dados.size(); ++i) {

            view.getjComboBoxPessoa().addItem((String) dados.get(i));

        }

    }

    private void Preencher_TabelaDespesa(String pesquisa, String tipo_pesquisa) throws SQLException {

        ArrayList dados = new ArrayList();
        TabelaDespesasDao buscadepesas = new TabelaDespesasDao();

        if (tipo_pesquisa.equals("Pessoa")) {
            dados = buscadepesas.Preencher_TabelaDespesasPessoa(pesquisa);
        } else {
            dados = buscadepesas.Preencher_TabelaDespesasData(pesquisa);
        }

        try {

            String[] Colunas = new String[]{"Cód", "Descrição", "Data Vencimento", "Valor", "Periodicidade", "Moradores", "Valor Dividido", "Valor Pago", "Status"};

            ModelTabela modelo = new ModelTabela(dados, Colunas);

            view.getjTableDespesasReceitas().setModel(modelo);

            view.getjTableDespesasReceitas().getColumnModel().getColumn(0).setPreferredWidth(40);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(0).setResizable(false);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(1).setPreferredWidth(160);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(1).setResizable(false);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(2).setPreferredWidth(100);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(2).setResizable(false);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(3).setPreferredWidth(70);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(3).setResizable(false);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(4).setPreferredWidth(100);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(4).setResizable(false);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(5).setPreferredWidth(200);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(5).setResizable(false);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(6).setPreferredWidth(100);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(6).setResizable(false);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(7).setPreferredWidth(100);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(7).setResizable(false);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(8).setPreferredWidth(80);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(8).setResizable(false);

            view.getjTableDespesasReceitas().setRowHeight(35);
            view.getjTableDespesasReceitas().getTableHeader().setReorderingAllowed(false);
            view.getjTableDespesasReceitas().setAutoResizeMode(view.getjTableDespesasReceitas().AUTO_RESIZE_OFF);
            view.getjTableDespesasReceitas().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        } catch (Exception e) {

            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

    }

    private void Preencher_TabelaReceita(String pesquisa, String tipo_pesquisa) throws SQLException {

        ArrayList dados = new ArrayList();
        TabelaReceitasDao buscadepesas = new TabelaReceitasDao();

        if (tipo_pesquisa.equals("Pessoa")) {
            dados = buscadepesas.Preencher_TabelaReceitasPessoa(pesquisa);
        } else {
            dados = buscadepesas.Preencher_TabelaReceitasData(pesquisa);
        }

        try {

            String[] Colunas = new String[]{"Cód", "Descrição", "Data Vencimento", "Valor", "Periodicidade", "Moradores", "Valor Dividido", "Valor Pago", "Status"};

            ModelTabela modelo = new ModelTabela(dados, Colunas);

            view.getjTableDespesasReceitas().setModel(modelo);

            view.getjTableDespesasReceitas().getColumnModel().getColumn(0).setPreferredWidth(40);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(0).setResizable(false);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(1).setPreferredWidth(160);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(1).setResizable(false);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(2).setPreferredWidth(100);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(2).setResizable(false);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(3).setPreferredWidth(70);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(3).setResizable(false);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(4).setPreferredWidth(100);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(4).setResizable(false);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(5).setPreferredWidth(200);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(5).setResizable(false);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(6).setPreferredWidth(100);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(6).setResizable(false);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(7).setPreferredWidth(100);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(7).setResizable(false);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(8).setPreferredWidth(80);
            view.getjTableDespesasReceitas().getColumnModel().getColumn(8).setResizable(false);

            view.getjTableDespesasReceitas().setRowHeight(35);
            view.getjTableDespesasReceitas().getTableHeader().setReorderingAllowed(false);
            view.getjTableDespesasReceitas().setAutoResizeMode(view.getjTableDespesasReceitas().AUTO_RESIZE_OFF);
            view.getjTableDespesasReceitas().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        } catch (Exception e) {

            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

    }

}
