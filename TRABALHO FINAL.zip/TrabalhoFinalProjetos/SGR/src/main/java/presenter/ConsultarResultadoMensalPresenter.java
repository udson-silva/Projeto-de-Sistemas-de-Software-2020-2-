/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import dao.ResultadoMensalDao;
import graficodecorator.GraficoPresenter;
import model.ModelTabela;
import views.ConsultarResultadoMensalView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ListSelectionModel;

/**
 *
 * @author udson
 */
public class ConsultarResultadoMensalPresenter {

    ConsultarResultadoMensalView view;

    public ConsultarResultadoMensalPresenter(int id_republica) {

        view = new ConsultarResultadoMensalView();

        view.setVisible(true);

        view.getbtnbuscar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    String mes = (String) view.getjComboBoxMeses().getSelectedItem();
                    String ano = view.gettxtAno().getText();

                    NomeMesPresenter pesquisanomemes = new NomeMesPresenter();
                    String nome_mes = pesquisanomemes.NomeMes(mes);

                    Preencher_Tabela(id_republica, nome_mes, ano);
                } catch (SQLException ex) {
                    Logger.getLogger(ConsultarResultadoMensalPresenter.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });

        view.getbtnvisualizargrafico().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                GraficoPresenter grafico = new GraficoPresenter(id_republica);

            }
        });

    }

    private void Preencher_Tabela(int id_republica, String mes, String ano) throws SQLException {

        ArrayList dados = new ArrayList();
        String[] Colunas;
        ResultadoMensalDao resultadomensaldao = new ResultadoMensalDao();

        if (mes.equals("TODOS OS MESES")) {

            dados = resultadomensaldao.Preencher_TabelaDespesasTodosMeses(id_republica, ano);
        } else {

            dados = resultadomensaldao.Preencher_TabelaDespesas(id_republica, mes, ano);
        }

        try {

            Colunas = new String[]{"Mês/Ano", "Total Despesas", "Total Despesas Pagas", "Total Receitas Recebidas", "Saldo Total"};

            ModelTabela modelo = new ModelTabela(dados, Colunas);

            view.getjTablefinanceiro().setModel(modelo);

            view.getjTablefinanceiro().getColumnModel().getColumn(0).setPreferredWidth(80);
            view.getjTablefinanceiro().getColumnModel().getColumn(0).setResizable(false);
            view.getjTablefinanceiro().getColumnModel().getColumn(1).setPreferredWidth(110);
            view.getjTablefinanceiro().getColumnModel().getColumn(1).setResizable(false);
            view.getjTablefinanceiro().getColumnModel().getColumn(2).setPreferredWidth(165);
            view.getjTablefinanceiro().getColumnModel().getColumn(2).setResizable(false);
            view.getjTablefinanceiro().getColumnModel().getColumn(3).setPreferredWidth(160);
            view.getjTablefinanceiro().getColumnModel().getColumn(3).setResizable(false);
            view.getjTablefinanceiro().getColumnModel().getColumn(4).setPreferredWidth(95);
            view.getjTablefinanceiro().getColumnModel().getColumn(4).setResizable(false);

            view.getjTablefinanceiro().setRowHeight(35);
            view.getjTablefinanceiro().getTableHeader().setReorderingAllowed(false);
            view.getjTablefinanceiro().setAutoResizeMode(view.getjTablefinanceiro().AUTO_RESIZE_OFF);
            view.getjTablefinanceiro().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        } catch (Exception e) {

            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

    }

}
