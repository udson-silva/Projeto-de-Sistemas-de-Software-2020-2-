/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import Dao.ConfiguracoesLogDao;
import Views.ConfiguraLogView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import observer.Observado;
import observer.Observer;


/**
 *
 * @author udson
 */
public class ConfiguracaoLogPresenter implements Observado{
    
    ConfiguraLogView view;
     final ArrayList<Observer> observadores;
    
    public  ConfiguracaoLogPresenter(){
        
       observadores = new ArrayList<Observer>();
          
        view = new ConfiguraLogView();
        
        view.setVisible(true);
        
        
        view.getbtnalterar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
             
             
                String tipo_log = (String) view.gejComboBoxtipolog().getSelectedItem();
                
                ConfiguracoesLogDao alterarlog = new ConfiguracoesLogDao();
                
                alterarlog.AlterarConfiguracao(tipo_log);
                 JOptionPane.showMessageDialog(view, "Tipo de Log alterado com sucesso!");
                notifyObservers();
               
                
                
            }
        });
        
        view.getbtnfechar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
           
                view.dispose();
            }
        });
        
        
    }

   @Override
    public void registryObserver(Observer o) {
        if (!observadores.contains(o)) {
            this.observadores.add(o);
        }

    }

    @Override
    public void removeObserver(Observer o) {
        this.observadores.remove(o);
    }

    @Override
    public void notifyObservers() {

        observadores.forEach((o) -> {
            o.update();
        });
    }

    
 
   
    
    
}
