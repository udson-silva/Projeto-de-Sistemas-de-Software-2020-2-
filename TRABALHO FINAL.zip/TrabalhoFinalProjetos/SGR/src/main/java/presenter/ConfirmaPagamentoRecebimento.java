/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import dao.DespesasDao;
import dao.ReceitasDao;
import model.DespesaReceitaModel;
import views.ConfirmarPagamentoRecebimentoView;
import observer.Observado;
import observer.Observer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 *
 * @author udson
 */
public class ConfirmaPagamentoRecebimento implements Observado {

    ConfirmarPagamentoRecebimentoView view;

    final ArrayList<Observer> observadores;

    public ConfirmaPagamentoRecebimento(DespesaReceitaModel despesareceita) {

        observadores = new ArrayList<Observer>();
        view = new ConfirmarPagamentoRecebimentoView();

        view.setTitle(despesareceita.getTipofatura());
        view.gettxtcodigo().setText(String.valueOf(despesareceita.getId_despesas()));
        view.gettxtdescricao().setText(despesareceita.getDescricao());
        view.gettxtdatavencimento().setText(despesareceita.getData_vencimento());
        view.gettxtvalor().setText(String.valueOf(despesareceita.getValor_dividido()));
        view.gettxtvalorpago().setText(String.valueOf(despesareceita.getValor_pago()));

        view.setVisible(true);

        view.getbtnRealizarpagamento().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                DespesaReceitaModel despesareceitamodel = new DespesaReceitaModel();
                if (despesareceita.getTipofatura().equals("RECEITA")) {

                    despesareceitamodel.setId_receitas(Integer.parseInt(view.gettxtcodigo().getText()));
                    despesareceitamodel.setValor_pago(Float.parseFloat(view.gettxtvalorpago().getText()));
                    despesareceitamodel.setStatus("RECEBIDO");
                    ReceitasDao realizarrecebimento = new ReceitasDao();
                    realizarrecebimento.RealizarRecebimentoReceitas(despesareceitamodel);

                } else {
                    despesareceitamodel.setId_despesas(Integer.parseInt(view.gettxtcodigo().getText()));
                    despesareceitamodel.setValor_pago(Float.parseFloat(view.gettxtvalorpago().getText()));
                    despesareceitamodel.setStatus("PAGO");
                    DespesasDao realizarpagamento = new DespesasDao();
                    realizarpagamento.RealizarPagamentoDespesa(despesareceitamodel);
                }
                
               
    
                
                

               
                view.gettxtcodigo().setText("");
                view.gettxtdescricao().setText("");
                view.gettxtdatavencimento().setText("");
                view.gettxtvalor().setText("");
                view.gettxtvalorpago().setText("");
                notifyObservers();

            }
        });

    }

    @Override
    public void registryObserver(Observer o) {
        if (!observadores.contains(o)) {
            this.observadores.add(o);
        }
    }

    @Override
    public void removeObserver(Observer o) {
        this.observadores.remove(o);
    }

    @Override
    public void notifyObservers() {
        for (Observer o : observadores) {

            o.update();
        }
    }

}
