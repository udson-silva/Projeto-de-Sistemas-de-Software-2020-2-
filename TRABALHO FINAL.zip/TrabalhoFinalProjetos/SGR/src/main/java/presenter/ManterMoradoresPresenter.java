/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import dao.RepublicaDao;
import dao.TabelaMoradoresRepublicaDao;
import model.ModelTabela;
import model.RepublicaModel;
import views.ManterMoradorRepublicaView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import observer.Observer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author udson
 */
public class ManterMoradoresPresenter implements Observer {

    String nome_morador = null, data_ingresso;
    int identificador_morador;
    float rateio;
    ManterMoradorRepublicaView view;
    ManterMoradoresPresenter instancia;
    EditarMoradorPresenter editarmorador;

    public ManterMoradoresPresenter(int id_morador) throws SQLException {

        view = new ManterMoradorRepublicaView();

        instancia = this;

        identificador_morador = id_morador;

        PesquisaRepublica(id_morador);

        view.setVisible(true);

        view.getTblMoradores().addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

                nome_morador = (String) view.getTblMoradores().getValueAt(view.getTblMoradores().getSelectedRow(), 0);
                data_ingresso = (String) view.getTblMoradores().getValueAt(view.getTblMoradores().getSelectedRow(), 1);
                rateio = (float) view.getTblMoradores().getValueAt(view.getTblMoradores().getSelectedRow(), 2);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        view.getBtnEditar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (nome_morador != null) {

                    editarmorador = new EditarMoradorPresenter(nome_morador, data_ingresso, rateio);

                    editarmorador.registryObserver((Observer) instancia);

                } else {
                    JOptionPane.showMessageDialog(view, "FAVOR SELECIONAR UM MORADOR NA TABELA!");
                }

            }
        });
        
        
        
        view.getBtnConvidar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ConvidarAceitarMoradorPresenter convidarmoradorsemteto = new ConvidarAceitarMoradorPresenter(nome_morador, identificador_morador, identificador_morador);
            }
        });

    }

    private void PesquisaRepublica(int id_morador) throws SQLException {

        //pesquisa a republica do usuario
        RepublicaDao pesquisarrepublica = new RepublicaDao();

        RepublicaModel republicamodel = new RepublicaModel();
        RepublicaModel republica;
        republicamodel.setId_usuario(id_morador);

        republica = pesquisarrepublica.PesquisaRepublicaPosCriacao(republicamodel);

        Preencher_Tabela("select *from moradores_republicas  inner join perfil_morador on perfil_morador.id_usuario"
                + " = moradores_republicas.id_morador where id_republica=" + republicamodel.getId_republica() + "");

    }

    private void Preencher_Tabela(String sql) throws SQLException {
      
        ArrayList dados = new ArrayList();
        TabelaMoradoresRepublicaDao pesquisamoradores = new TabelaMoradoresRepublicaDao();
        
        dados = pesquisamoradores.Preencher_Tabela(sql);
       

        try {
            
           

            String[] Colunas = new String[]{"Nome", "Data de Ingresso", "Rateio %"};
          

            ModelTabela modelo = new ModelTabela(dados, Colunas);

            view.getTblMoradores().setModel(modelo);

            view.getTblMoradores().getColumnModel().getColumn(0).setPreferredWidth(150);
            view.getTblMoradores().getColumnModel().getColumn(0).setResizable(false);
            view.getTblMoradores().getColumnModel().getColumn(1).setPreferredWidth(160);
            view.getTblMoradores().getColumnModel().getColumn(1).setResizable(false);
            view.getTblMoradores().getColumnModel().getColumn(2).setPreferredWidth(160);
            view.getTblMoradores().getColumnModel().getColumn(2).setResizable(false);

            view.getTblMoradores().setRowHeight(35);
            view.getTblMoradores().getTableHeader().setReorderingAllowed(false);
            view.getTblMoradores().setAutoResizeMode(view.getTblMoradores().AUTO_RESIZE_OFF);
            view.getTblMoradores().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

           
        } catch (Exception e) {

            System.err.println(e.getClass().getName() + ": " + e.getMessage());
           // System.exit(0);
        }

    }

    @Override
    public void update() {

        try {
            //pesquisa a republica do usuario
            RepublicaDao pesquisar = new RepublicaDao();

            RepublicaModel republ = new RepublicaModel();
            RepublicaModel model;
            republ.setId_usuario(identificador_morador);

            model = pesquisar.PesquisaRepublicaPosCriacao(republ);

            Preencher_Tabela("select *from moradores_republicas where id_republica=" + model.getId_republica() + "");
        } catch (SQLException ex) {
            Logger.getLogger(ManterMoradoresPresenter.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
