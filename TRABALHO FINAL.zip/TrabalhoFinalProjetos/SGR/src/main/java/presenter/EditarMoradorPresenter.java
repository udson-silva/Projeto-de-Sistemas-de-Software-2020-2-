/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;
import dao.MoradoresRepublicaDao;
import model.MoradorRepublicaModel;
import views.EditarMoradorView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import observer.Observado;
import observer.Observer;
import java.util.ArrayList;


/**
 *
 * @author udson
 */
public class EditarMoradorPresenter implements Observado{
    
    EditarMoradorView view;
       final ArrayList<Observer> observadores;
    
    public EditarMoradorPresenter(String nome_morador, String data_ingresso, float rateio){
        
        observadores = new ArrayList<Observer>();
        view = new EditarMoradorView();
        
        view.gettxtNome().setText(nome_morador);
        view.gettxtDataIngresso().setText(data_ingresso);
        view.gettxtRateio().setText(String.valueOf(rateio));
        
        view.setVisible(true);
        
        
        view.getbtnSalvar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              
                MoradorRepublicaModel moradorrepublicamodel = new  MoradorRepublicaModel();
                
                moradorrepublicamodel.setData_ingresso(view.gettxtDataIngresso().getText());
                moradorrepublicamodel.setRateio(Float.parseFloat(view.gettxtRateio().getText()));
                moradorrepublicamodel.setNome_morador(view.gettxtNome().getText());
                
                MoradoresRepublicaDao alterar = new MoradoresRepublicaDao();
                alterar.AlterarDadosMoradores(moradorrepublicamodel);
                
                JOptionPane.showMessageDialog(view, "Dados Alterados com Sucesso!");
                notifyObservers();
                view.dispose();
                
            }
        });
        
    }

    @Override
    public void registryObserver(Observer o) {
        if (!observadores.contains(o)) {
            this.observadores.add(o);
        }
    }

    @Override
    public void removeObserver(Observer o) {
        this.observadores.remove(o);
    }

    @Override
    public void notifyObservers() {
        for (Observer o : observadores) {

            o.update();
        }
    }
    
}
