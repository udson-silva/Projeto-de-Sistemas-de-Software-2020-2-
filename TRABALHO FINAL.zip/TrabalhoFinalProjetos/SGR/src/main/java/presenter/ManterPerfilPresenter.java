/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import Model.LogModel;
import adapter.RegistrosdeLog;
import dao.PerfilMoradorDao;
import model.UsuarioModel;
import views.PerfilView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author udson
 */
public class ManterPerfilPresenter {

    PerfilView view;

    public ManterPerfilPresenter(int id_usuario) throws SQLException {

        view = new PerfilView();
        view.getbtnConfirma().setText("EDITAR");

        view.setVisible(true);
        CarregarDados(id_usuario);

        view.getbtnConfirma().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String perfil;
                if (view.getjRadioButtonPublico().isSelected() == true) {
                    perfil = "PÚBLICO";
                } else {
                    perfil = "PRIVADO";
                }

                UsuarioModel usuariomodel = new UsuarioModel();

                usuariomodel.setNome_usuario(view.gettxtNome().getText());
                usuariomodel.setApelido(view.gettxtApelido().getText());
                usuariomodel.setTelefone(view.gettxtTelefone().getText());
                usuariomodel.setLink_rede(view.gettxtLinkRedeSocial().getText());
                usuariomodel.setTelefone_resp1(view.gettxtTelResp1().getText());
                usuariomodel.setTelefone_resp2(view.gettxtTelResp2().getText());
                usuariomodel.setTipo_perfil(perfil);
                usuariomodel.setId_usuario(id_usuario);

                PerfilMoradorDao alterar = new PerfilMoradorDao();
                alterar.AlterarPerfil(usuariomodel);

                JOptionPane.showMessageDialog(view, "Perfil de Usuário Alterado com Sucesso!");

                LogModel logmodel = new LogModel();

                logmodel.setUsuario(view.gettxtNome().getText());
                logmodel.setOperacao("EDIÇÃO");
                logmodel.setNome(view.gettxtNome().getText());

                RegistrosdeLog gravarlog = new RegistrosdeLog();
                gravarlog.GravaLog(logmodel);

                view.dispose();

            }
        });

        view.getbtnExcluirConta().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                PerfilMoradorDao excluir = new PerfilMoradorDao();
                excluir.DeletarPerfil(id_usuario);
                JOptionPane.showMessageDialog(view, "Perfil de Usuário Excluido com Sucesso!");

                LogModel logmodel = new LogModel();

                logmodel.setUsuario(view.gettxtNome().getText());
                logmodel.setOperacao("EXCLUSÃO");
                logmodel.setNome(view.gettxtNome().getText());

                RegistrosdeLog gravarlog = new RegistrosdeLog();
                gravarlog.GravaLog(logmodel);

                view.dispose();

            }
        });

    }

    void CarregarDados(int id_usuario) throws SQLException {

        PerfilMoradorDao pesquisar = new PerfilMoradorDao();

        UsuarioModel usuariomodel = new UsuarioModel();

        usuariomodel.setId_usuario(id_usuario);

        UsuarioModel usuario = pesquisar.PesquisaDadosMorador(usuariomodel);

        //se o usuario não tiver perfil o sistema avisa e redireciona para o mesmo criar o perfil
        if (usuario.getNome_usuario() == null) {
            JOptionPane.showMessageDialog(view, "Usúario Não Tem Perfil Cadastrado \n"
                    + " no Sistema. Favor Criar um Perfil!");

            view.dispose();
            CriarPerfilPresenter criarPerfil = new CriarPerfilPresenter(id_usuario);
        } else {
            view.gettxtNome().setText(usuario.getNome_usuario());
            view.gettxtApelido().setText(usuario.getApelido());
            view.gettxtTelefone().setText(usuario.getTelefone());
            view.gettxtLinkRedeSocial().setText(usuario.getLink_rede());
            view.gettxtTelResp1().setText(usuario.getTelefone_resp1());
            view.gettxtTelResp2().setText(usuario.getTelefone_resp2());

            String tipo_perfil = usuario.getTipo_perfil();
            if (tipo_perfil.equals("PÚBLICO")) {
                view.getjRadioButtonPublico().setSelected(true);
            } else {
                view.getjRadioButtonPrivado().setSelected(true);
            }

        }

    }

}
