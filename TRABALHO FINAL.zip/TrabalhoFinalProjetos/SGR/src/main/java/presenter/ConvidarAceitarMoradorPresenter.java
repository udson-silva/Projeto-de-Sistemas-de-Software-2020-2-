/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import dao.ConviteMoradorDao;
import dao.MoradoresRepublicaDao;
import dao.RepublicaDao;
import dao.SolicitaMoradiaDao;
import dao.TabelasSolicitacaoMoradiaDao;
import dao.UsuarioDao;
import model.ConviteMoradorModel;
import model.ModelTabela;
import model.MoradorRepublicaModel;
import model.RepublicaModel;
import model.UsuarioModel;
import views.ConvidarAceitarMoradorView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import observer.Observado;
import observer.Observer;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 *
 * @author udson
 */
public class ConvidarAceitarMoradorPresenter implements Observado, Observer {

    ConvidarAceitarMoradorView view;

    float despesa_media;
    String nome_morador, republica, status_tabela;
    int total_vagas, vagas_disponiveis, vagas_ocupadas, id_republica, id_solicitacao, identificador_usuario = 0, id_usuario_convidado = 0;
    final ArrayList<Observer> observadores;

    public ConvidarAceitarMoradorPresenter(String nome_republica, int id_usuario, int cod_republica) {

        observadores = new ArrayList<Observer>();

        view = new ConvidarAceitarMoradorView();
        view.getBtnAceitar().setVisible(false);
        view.getBtnRecusar().setVisible(false);
        view.getbtnConvidarUsuario().setVisible(false);
        view.getbtnNaoAceitos().setVisible(false);

        view.setVisible(true);

        view.getMenuAceitarSolicitacoes().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Preencher_TabelaSolicitacoes("select * from perfil_morador inner join solicitacao_moradia on perfil_morador.id = solicitacao_moradia.id_perfil_usuario where republica_solicitada='" + nome_republica + "'and status = 'PENDENTE'");

                    status_tabela = "TABELA_ACEITAR_SOLICITAÇÕES";
                } catch (SQLException ex) {
                    Logger.getLogger(ConvidarAceitarMoradorPresenter.class.getName()).log(Level.SEVERE, null, ex);
                }

                view.getBtnAceitar().setVisible(true);
                view.getBtnRecusar().setVisible(true);
                view.getbtnConvidarUsuario().setVisible(false);
                view.getbtnNaoAceitos().setVisible(true);
            }
        });

        view.getMenuConvidarUsuario().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Preencher_TabelaConvite("select *from perfil_morador inner join usuarios on perfil_morador.id_usuario = usuarios.id_usuario where tipo_perfil = 'PÚBLICO' and status = 'SEM TETO'");
                    status_tabela = "TABELA_CONVITE";
                } catch (SQLException ex) {
                    Logger.getLogger(ConvidarAceitarMoradorPresenter.class.getName()).log(Level.SEVERE, null, ex);
                }

                view.getBtnAceitar().setVisible(false);
                view.getBtnRecusar().setVisible(false);
                view.getbtnConvidarUsuario().setVisible(true);
                view.getbtnNaoAceitos().setVisible(true);

            }
        });

        view.getbtnConvidarUsuario().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (id_usuario_convidado != 0) {

                    ConviteMoradorModel convitemorador = new ConviteMoradorModel();
                    convitemorador.setId_convidador(id_usuario);
                    convitemorador.setId_republica(cod_republica);
                    convitemorador.setId_usuario_convidado(id_usuario_convidado);
                    convitemorador.setStatus("CONVIDADO Á MORAR");
                    //pega a data do sistema e formata em mes e ano
                    Date dataSistema = new Date();
                    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                    String data_pc = formato.format(dataSistema);
                    convitemorador.setData_convite(data_pc);

                    ConviteMoradorDao fazerconvite = new ConviteMoradorDao();
                    fazerconvite.FazerConviteMorador(convitemorador);

                    JOptionPane.showMessageDialog(view, "Convite realizado com Sucesso!");
                    notifyObservers();

                } else {

                    JOptionPane.showMessageDialog(view, "Selecione um usuário na tabela, para realizar o convite!");

                }

            }
        });

        view.getBtnAceitar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (identificador_usuario != 0) {

                    try {
                        VerificarVagasDiponiveisRepublica(nome_republica);
                    } catch (SQLException ex) {
                        Logger.getLogger(ConvidarAceitarMoradorPresenter.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    InserirUsuarioNaRepublica();
                    MudarStatusUsuario();
                    AtualizaSolicitacaoMoradiaAceito();
                    JOptionPane.showMessageDialog(view, "Solicitação de Moradia Aceita com Sucesso!");
                    try {
                        Preencher_TabelaSolicitacoes("select * from perfil_morador inner join solicitacao_moradia on perfil_morador.id = solicitacao_moradia.id_perfil_usuario where republica_solicitada='" + nome_republica + "'and status = 'PENDENTE'");
                    } catch (SQLException ex) {
                        Logger.getLogger(ConvidarAceitarMoradorPresenter.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    notifyObservers();

                } else {
                    JOptionPane.showMessageDialog(view, "Selecione um usuário na tabela, para aceitar a solicitação!");
                }

            }

        });

        view.getBtnRecusar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    AtualizaSolicitacaoMoradiaNaoAceito();
                    Preencher_TabelaSolicitacoes("select * from perfil_morador inner join solicitacao_moradia on perfil_morador.id = solicitacao_moradia.id_perfil_usuario where republica_solicitada='" + nome_republica + "'and status = 'PENDENTE'");
                } catch (SQLException ex) {
                    Logger.getLogger(ConvidarAceitarMoradorPresenter.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });

        view.getbtnNaoAceitos().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Preencher_TabelaSolicitacoes("select * from perfil_morador inner join solicitacao_moradia on perfil_morador.id = solicitacao_moradia.id_perfil_usuario where republica_solicitada='" + nome_republica + "'and status = 'NÃO ACEITO'");
                } catch (SQLException ex) {
                    Logger.getLogger(ConvidarAceitarMoradorPresenter.class.getName()).log(Level.SEVERE, null, ex);
                }

                view.getBtnAceitar().setText("Aceitar");
                view.getBtnRecusar().setVisible(false);

            }
        });

        view.getTblListaUsuarioConvite().addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

                if (status_tabela.equals("TABELA_ACEITAR_SOLICITAÇÕES")) {
                    // System.out.println("tabella aceitar convite");

                    id_solicitacao = (int) view.getTblListaUsuarioAceitar().getValueAt(view.getTblListaUsuarioAceitar().getSelectedRow(), 0);
                    identificador_usuario = (int) view.getTblListaUsuarioAceitar().getValueAt(view.getTblListaUsuarioAceitar().getSelectedRow(), 1);
                    nome_morador = (String) view.getTblListaUsuarioAceitar().getValueAt(view.getTblListaUsuarioAceitar().getSelectedRow(), 2);
                    republica = (String) view.getTblListaUsuarioAceitar().getValueAt(view.getTblListaUsuarioAceitar().getSelectedRow(), 3);

                } else {
                    id_usuario_convidado = (int) view.getTblListaUsuarioConvite().getValueAt(view.getTblListaUsuarioConvite().getSelectedRow(), 0);
                    // System.out.println("tabella convidar");
                }

            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

    }

    private void AtualizaSolicitacaoMoradiaNaoAceito() {
        String status = "NÃO ACEITO";
        int id_solicitacao = (int) view.getTblListaUsuarioAceitar().getValueAt(view.getTblListaUsuarioAceitar().getSelectedRow(), 0);
        String republica = (String) view.getTblListaUsuarioAceitar().getValueAt(view.getTblListaUsuarioAceitar().getSelectedRow(), 3);
        SolicitaMoradiaDao alterastatus = new SolicitaMoradiaDao();
        alterastatus.AlterarStatusSolicitacao(status, id_solicitacao, republica);
        notifyObservers();

    }

    private void AtualizaSolicitacaoMoradiaAceito() {
        String status = "ACEITO";
        int id_solicitacao = (int) view.getTblListaUsuarioAceitar().getValueAt(view.getTblListaUsuarioAceitar().getSelectedRow(), 0);
        String republica = (String) view.getTblListaUsuarioAceitar().getValueAt(view.getTblListaUsuarioAceitar().getSelectedRow(), 3);
        SolicitaMoradiaDao alterastatus = new SolicitaMoradiaDao();
        alterastatus.AlterarStatusSolicitacao(status, id_solicitacao, republica);

    }

    private void InserirUsuarioNaRepublica() {
        //aqui insere o morador na republica
        MoradorRepublicaModel morador = new MoradorRepublicaModel();
        int id_usuario = (int) view.getTblListaUsuarioAceitar().getValueAt(view.getTblListaUsuarioAceitar().getSelectedRow(), 1);
        morador.setId_morador(id_usuario);
        morador.setId_republica(id_republica);
        morador.setRateio(despesa_media);

        //pega a data do sistema e formata em mes e ano
        Date dataSistema = new Date();
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        String data_pc = formato.format(dataSistema);

        morador.setData_ingresso(data_pc);
        //aqui insere o morador e a republica na tabela moradores_republica
        MoradoresRepublicaDao inserir = new MoradoresRepublicaDao();
        inserir.inserirMoradoresRepublica(morador);

    }

    private void VerificarVagasDiponiveisRepublica(String nome_republica) throws SQLException {

        RepublicaDao pesquisar = new RepublicaDao();

        RepublicaModel republicamodel = new RepublicaModel();

        republicamodel.setNomeRepublica(nome_republica);

        RepublicaModel republica = pesquisar.PesquisaVagasRepublica(republicamodel);

        despesa_media = republica.getDespesaMedia();
        total_vagas = republica.getTotalVagas();
        vagas_disponiveis = republica.getVagasDisponiveis();
        vagas_ocupadas = republica.getVagasOcupadas();

        id_republica = republica.getId_republica();
        vagas_disponiveis = vagas_disponiveis - 1;
        vagas_ocupadas = vagas_ocupadas + 1;

        if (vagas_ocupadas > total_vagas) {
            JOptionPane.showMessageDialog(view, "República Não tem mais vagas disponiveis!");
            view.dispose();
        } else {

            republicamodel.setVagasDisponiveis(vagas_disponiveis);
            republicamodel.setVagasOcupadas(vagas_ocupadas);
            republicamodel.setId_republica(id_republica);

            RepublicaDao alterarvagasrepublica = new RepublicaDao();
            alterarvagasrepublica.AlterarVagasRepublica(republica);

        }

    }

    private void MudarStatusUsuario() {

        //mudando o status do usuario no banco
        int id_usuario = (int) view.getTblListaUsuarioAceitar().getValueAt(view.getTblListaUsuarioAceitar().getSelectedRow(), 1);
        String status = "MORADOR DA REPÚBLICA";

        UsuarioModel usuariomodel = new UsuarioModel();
        usuariomodel.setId_usuario(id_usuario);
        usuariomodel.setStatus(status);

        UsuarioDao alterarstatus = new UsuarioDao();
        alterarstatus.AlterarStatusUsuario(usuariomodel);

    }

    private void Preencher_TabelaConvite(String sql) throws SQLException {

        ArrayList dados = new ArrayList();

        TabelasSolicitacaoMoradiaDao tabelaconvite = new TabelasSolicitacaoMoradiaDao();

        dados = tabelaconvite.Preencher_TabelaConvite(sql);

        try {

            String[] Colunas = new String[]{"id", "Nome", "Apelido", "Telefone", "Perfil Rede Social"};

            ModelTabela modelo = new ModelTabela(dados, Colunas);

            view.getTblListaUsuarioConvite().setModel(modelo);

            view.getTblListaUsuarioConvite().getColumnModel().getColumn(0).setPreferredWidth(40);
            view.getTblListaUsuarioConvite().getColumnModel().getColumn(0).setResizable(false);
            view.getTblListaUsuarioConvite().getColumnModel().getColumn(1).setPreferredWidth(230);
            view.getTblListaUsuarioConvite().getColumnModel().getColumn(1).setResizable(false);
            view.getTblListaUsuarioConvite().getColumnModel().getColumn(2).setPreferredWidth(160);
            view.getTblListaUsuarioConvite().getColumnModel().getColumn(2).setResizable(false);
            view.getTblListaUsuarioConvite().getColumnModel().getColumn(3).setPreferredWidth(100);
            view.getTblListaUsuarioConvite().getColumnModel().getColumn(3).setResizable(false);
            view.getTblListaUsuarioConvite().getColumnModel().getColumn(4).setPreferredWidth(200);
            view.getTblListaUsuarioConvite().getColumnModel().getColumn(4).setResizable(false);

            view.getTblListaUsuarioConvite().setRowHeight(35);
            view.getTblListaUsuarioConvite().getTableHeader().setReorderingAllowed(false);
            view.getTblListaUsuarioConvite().setAutoResizeMode(view.getTblListaUsuarioConvite().AUTO_RESIZE_OFF);
            view.getTblListaUsuarioConvite().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        } catch (Exception e) {

            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

    }

    private void Preencher_TabelaSolicitacoes(String sql) throws SQLException {

        ArrayList dados = new ArrayList();

        TabelasSolicitacaoMoradiaDao tabelassolicitacao = new TabelasSolicitacaoMoradiaDao();

        dados = tabelassolicitacao.Preencher_TabelaSolicitacoes(sql);

        try {

            String[] Colunas = new String[]{"Cód Solicitação", "Cod Solicitante", "Nome Solicitante", "República Solicitada", "Status", "Perfil Rede Social", "República Atual"};

            ModelTabela modelo = new ModelTabela(dados, Colunas);

            view.getTblListaUsuarioAceitar().setModel(modelo);
            view.getTblListaUsuarioAceitar().getColumnModel().getColumn(0).setPreferredWidth(100);
            view.getTblListaUsuarioAceitar().getColumnModel().getColumn(0).setResizable(false);
            view.getTblListaUsuarioAceitar().getColumnModel().getColumn(1).setPreferredWidth(100);
            view.getTblListaUsuarioAceitar().getColumnModel().getColumn(1).setResizable(false);
            view.getTblListaUsuarioAceitar().getColumnModel().getColumn(2).setPreferredWidth(160);
            view.getTblListaUsuarioAceitar().getColumnModel().getColumn(2).setResizable(false);
            view.getTblListaUsuarioAceitar().getColumnModel().getColumn(3).setPreferredWidth(160);
            view.getTblListaUsuarioAceitar().getColumnModel().getColumn(3).setResizable(false);
            view.getTblListaUsuarioAceitar().getColumnModel().getColumn(4).setPreferredWidth(100);
            view.getTblListaUsuarioAceitar().getColumnModel().getColumn(4).setResizable(false);
            view.getTblListaUsuarioAceitar().getColumnModel().getColumn(5).setPreferredWidth(200);
            view.getTblListaUsuarioAceitar().getColumnModel().getColumn(5).setResizable(false);
            view.getTblListaUsuarioAceitar().getColumnModel().getColumn(6).setPreferredWidth(160);
            view.getTblListaUsuarioAceitar().getColumnModel().getColumn(6).setResizable(false);

            view.getTblListaUsuarioAceitar().setRowHeight(35);
            view.getTblListaUsuarioAceitar().getTableHeader().setReorderingAllowed(false);
            view.getTblListaUsuarioAceitar().setAutoResizeMode(view.getTblListaUsuarioAceitar().AUTO_RESIZE_OFF);
            view.getTblListaUsuarioAceitar().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        } catch (Exception e) {

            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

    }

    @Override
    public void registryObserver(Observer o) {
        if (!observadores.contains(o)) {
            this.observadores.add(o);
        }
    }

    @Override
    public void removeObserver(Observer o) {
        this.observadores.remove(o);
    }

    @Override
    public void notifyObservers() {
        for (Observer o : observadores) {

            o.update();
        }
    }

    @Override
    public void update() {

        try {
            Preencher_TabelaConvite("select *from perfil_morador inner join usuarios on perfil_morador.id_usuario = usuarios.id_usuario where tipo_perfil = 'PÚBLICO' and status = 'SEM TETO'");
        } catch (SQLException ex) {
            Logger.getLogger(ConvidarAceitarMoradorPresenter.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
