/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;
import dao.RepublicaDao;
import model.RepublicaModel;
import views.ManterRepublicaView;
import java.sql.SQLException;

/**
 *
 * @author udson
 */
public class InformacoesRepublica {
    
    ManterRepublicaView view;
    
    

    public InformacoesRepublica(String nome_republica) throws SQLException {
        
        view = new ManterRepublicaView();
        
        CarregarDados(nome_republica);
        
        view.setTitle("Informações da República");
        view.setVisible(true);
        
        
    }
    
    
    private void CarregarDados(String nome_republica) throws SQLException{
        
        view.gettxtnome().setEnabled(false);
        view.gettxtdatafundacao().setEnabled(false);
        view.gettxtdespesamedia().setEnabled(false);
        view.gettxttotalvagas().setEnabled(false);
        view.gettxtVagasdisponiveis().setEnabled(false);
        view.gettxtvagasocupadas().setEnabled(false);
        view.gettxtVantagens().setEnabled(false);
        view.gettxtcodigoetica().setEnabled(false);
        view.gettxtLogadouro().setEnabled(false);
        view.gettxtBairro().setEnabled(false);
        view.gettxtPontoreferencia().setEnabled(false);
        view.gettxtLocalizacaoGeo().setEnabled(false);
        view.gettxtCep().setEnabled(false);
        view.getBtnEditarRepublica().setVisible(false);
        view.getBtnExcluirRepublica().setVisible(false);
        view.getBtnManterRepublica().setVisible(false);
        
        
        RepublicaDao pesquisar = new RepublicaDao();
        
        RepublicaModel republicamodel = new RepublicaModel();
        
        republicamodel.setNomeRepublica(nome_republica);
        
       RepublicaModel republica = pesquisar.PesquisaDadosRepublicaPorNome(republicamodel);
        
        view.gettxtnome().setText(republicamodel.getNomeRepublica());
        view.gettxtdatafundacao().setText(republicamodel.getDataFundacao());
        view.gettxtdespesamedia().setText(String.valueOf(republicamodel.getDespesaMedia()));
        view.gettxttotalvagas().setText(String.valueOf(republicamodel.getTotalVagas()));
        view.gettxtVagasdisponiveis().setText(String.valueOf(republicamodel.getVagasDisponiveis()));
        view.gettxtvagasocupadas().setText(String.valueOf(republicamodel.getVagasOcupadas()));
        view.gettxtVantagens().setText(republicamodel.getVantagens());
        view.gettxtcodigoetica().setText(republicamodel.getCodigoEtica());
        view.gettxtLogadouro().setText(republicamodel.getLogradouro());
        view.gettxtBairro().setText(republicamodel.getBairro());
        view.gettxtPontoreferencia().setText(republicamodel.getReferencia());
        view.gettxtLocalizacaoGeo().setText(republicamodel.getLocalizacaoGeografica());
        view.gettxtCep().setText(republicamodel.getCEP());
        
        
        
        
        
        
        
    }
    
    
    
}
