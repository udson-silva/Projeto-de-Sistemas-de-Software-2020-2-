/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import Model.LogModel;
import adapter.RegistrosdeLog;
import dao.PerfilMoradorDao;
import model.UsuarioModel;
import views.PerfilView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author udson
 */
public class CriarPerfilPresenter {

    PerfilView view;

    public CriarPerfilPresenter(int id_usuario) throws SQLException {

        view = new PerfilView();
        view.getbtnExcluirConta().setVisible(false);
        view.setVisible(true);
        VerificarPerfilUsuario(id_usuario);

        view.getbtnConfirma().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String perfil;
                if (view.getjRadioButtonPublico().isSelected() == true) {
                    perfil = "PÚBLICO";
                } else {
                    perfil = "PRIVADO";
                }

                UsuarioModel usuariomodel = new UsuarioModel();

                usuariomodel.setNome_usuario(view.gettxtNome().getText());
                usuariomodel.setApelido(view.gettxtApelido().getText());
                usuariomodel.setTelefone(view.gettxtTelefone().getText());
                usuariomodel.setLink_rede(view.gettxtLinkRedeSocial().getText());
                usuariomodel.setTelefone_resp1(view.gettxtTelResp1().getText());
                usuariomodel.setTelefone_resp2(view.gettxtTelResp2().getText());
                usuariomodel.setTipo_perfil(perfil);
                usuariomodel.setId_usuario(id_usuario);

                PerfilMoradorDao inserir = new PerfilMoradorDao();
                inserir.inserirUsuario(usuariomodel);
                

                JOptionPane.showMessageDialog(view, "Perfil de Usuário Cadastrado com Sucesso!");
                
                 LogModel logmodel = new LogModel();
                 
                 logmodel.setUsuario(view.gettxtNome().getText());
                 logmodel.setOperacao("INCLUSÃO");
                 logmodel.setNome(view.gettxtNome().getText());
                 
                  RegistrosdeLog gravarlog = new RegistrosdeLog();
                 gravarlog.GravaLog(logmodel);
                
                

                view.dispose();

            }
        });

    }
    
    
    
   public void VerificarPerfilUsuario(int id_usuario) throws SQLException{
        
        boolean retorno;
        PerfilMoradorDao pesquisar = new PerfilMoradorDao();
        
        retorno = pesquisar.PesquisaUsuario(id_usuario);
        
       
       
        if(retorno==true){
            JOptionPane.showMessageDialog(view, "USUÁRIO JÁ TEM UM PERFIL CADASTRADO!");
            view.dispose();
        }
        
        
        
        
        
    }  
    
    

}
