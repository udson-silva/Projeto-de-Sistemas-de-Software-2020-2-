/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import Model.LogModel;
import adapter.RegistrosdeLog;
import dao.RepublicaDao;
import dao.UsuarioDao;
import model.RepublicaModel;
import model.UsuarioModel;
import observer.Observado;
import observer.Observer;
import state.IUsuarioState;
import state.UsuarioNovoState;
import views.ManterRepublicaView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author udson
 */
public class ManterRepublicaPresenter implements Observado {

    ManterRepublicaView view;

    int id_republica;
    final ArrayList<Observer> observadores;

    ManterRepublicaPresenter(int id_usuario, String status, String usuario) throws SQLException {
        observadores = new ArrayList<Observer>();
        view = new ManterRepublicaView();

        CarregarDados(id_usuario);

        view.setVisible(true);

        view.getBtnEditarRepublica().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                RepublicaModel republica = new RepublicaModel();
                //inserir dados da tela em model republica

                int totalVagas = Integer.parseInt(view.gettxttotalvagas().getText());
                int vagasOcupadas = Integer.parseInt(view.gettxtvagasocupadas().getText());

                int vagasdisponiveis = totalVagas - vagasOcupadas;
                view.gettxtVagasdisponiveis().setText(String.valueOf(vagasdisponiveis));

                if (vagasdisponiveis > 0) {

                    republica.setNomeRepublica(view.gettxtnome().getText());
                    republica.setDataFundacao(view.gettxtdatafundacao().getText());
                    republica.setDespesaMedia(Float.parseFloat(view.gettxtdespesamedia().getText()));
                    republica.setTotalVagas(Integer.parseInt(view.gettxttotalvagas().getText()));

                    //vagas ocupadas serão o total de vagas -1 do criador da republica
                    //que já deve está ocupando um lugar. Devo corrigir essa parte depois
                    republica.setVagasOcupadas(vagasOcupadas);

                    //Total de Vagas não é editavel na tela de criação e os dados serão pegos aki
                    republica.setVagasDisponiveis(vagasdisponiveis);

                    republica.setVantagens(view.gettxtVantagens().getText());
                    republica.setCodigoEtica(view.gettxtcodigoetica().getText());
                    republica.setLogradouro(view.gettxtLogadouro().getText());
                    republica.setBairro(view.gettxtBairro().getText());
                    republica.setReferencia(view.gettxtPontoreferencia().getText());
                    republica.setLocalizacaoGeografica(view.gettxtLocalizacaoGeo().getText());
                    republica.setCEP(view.gettxtCep().getText());
                    republica.setId_usuario(id_usuario);
                    republica.setId_republica(id_republica);
                    //limpar dados da tela

                    RepublicaDao alterar = new RepublicaDao();
                    alterar.AlterarRepublica(republica);
                    JOptionPane.showMessageDialog(view, "República editada com sucesso!");

                    LogModel logmodel = new LogModel();

                    logmodel.setUsuario(usuario);
                    logmodel.setOperacao("EDIÇÃO DE REPÚBLICA");
                    logmodel.setNome(usuario);

                    RegistrosdeLog gravarlog = new RegistrosdeLog();
                    gravarlog.GravaLog(logmodel);

                    view.gettxtnome().setText("");
                    view.gettxtdatafundacao().setText("");
                    view.gettxtdespesamedia().setText("");
                    view.gettxttotalvagas().setText("");
                    view.gettxtVantagens().setText("");
                    view.gettxtcodigoetica().setText("");
                    view.gettxtLogadouro().setText("");
                    view.gettxtLogadouro().setText("");
                    view.gettxtBairro().setText("");
                    view.gettxtPontoreferencia().setText("");
                    view.gettxtLocalizacaoGeo().setText("");
                    view.gettxtCep().setText("");
                    view.gettxtVagasdisponiveis().setText("");
                    view.gettxtvagasocupadas().setText("");
                } else {
                    JOptionPane.showMessageDialog(view, "Número de vagas ocupadas superior ao total!");

                }

            }
        });

        view.getBtnExcluirRepublica().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String[] valores = {"NÃO", "SIM"};

                Object selecionado = JOptionPane.showInputDialog(view, "Deseja excluir a república?", "Exclusão de república.", JOptionPane.DEFAULT_OPTION, null, valores, "0");
                if (selecionado != null) {
                    String selectedString = selecionado.toString();
                    //do something
                } else {
                    //  System.out.println("Operação Cancelada!");
                }

                String valor_selecionado = (String) selecionado;

                //verifica se o valor que o usuario escolheu é sim, se for atualiza o valor de custo
                if (valor_selecionado.equals("SIM")) {

                    //exclui a republica 
                    RepublicaDao excluir = new RepublicaDao();
                    excluir.DeletarRepublica(id_republica);

                    JOptionPane.showMessageDialog(view, " República excluída com sucesso!");

                    //altera o status do usuario
                    IUsuarioState state = new UsuarioNovoState();

                    String Tipo_status = state.AlterarEstado(status);
                    //mudando o status do usuario no banco
                    UsuarioModel usuariomodel = new UsuarioModel();
                    usuariomodel.setNome_usuario(usuario);
                    usuariomodel.setStatus(Tipo_status);

                    UsuarioDao alterarstatus = new UsuarioDao();
                    alterarstatus.AlterarStatusUsuario(usuariomodel);
                    JOptionPane.showMessageDialog(view, " Status do Usuário Alterado com Sucesso!");
                    notifyObservers();
                    
                    
                    
                    LogModel logmodel = new LogModel();

                    logmodel.setUsuario(usuario);
                    logmodel.setOperacao("EXCLUÃO DE REPÚBLICA");
                    logmodel.setNome(usuario);

                    RegistrosdeLog gravarlog = new RegistrosdeLog();
                    gravarlog.GravaLog(logmodel);
                    
                    
                    view.dispose();
                } else {
                    view.dispose();
                }
            }
        });

    }

    void CarregarDados(int id_usuario) throws SQLException {

        RepublicaDao pesquisar = new RepublicaDao();

        RepublicaModel republicamodel = new RepublicaModel();

        republicamodel.setId_usuario(id_usuario);

        RepublicaModel republica = pesquisar.PesquisaDadosRepublica(republicamodel);

        view.gettxtnome().setText(republica.getNomeRepublica());
        view.gettxtdatafundacao().setText(republica.getDataFundacao());
        view.gettxtdespesamedia().setText(String.valueOf(republica.getDespesaMedia()));
        view.gettxttotalvagas().setText(String.valueOf(republica.getTotalVagas()));
        view.gettxtVagasdisponiveis().setText(String.valueOf(republica.getVagasDisponiveis()));
        view.gettxtvagasocupadas().setText(String.valueOf(republica.getVagasOcupadas()));
        view.gettxtVantagens().setText(republica.getVantagens());
        view.gettxtcodigoetica().setText(republica.getCodigoEtica());
        view.gettxtLogadouro().setText(republica.getLogradouro());
        view.gettxtBairro().setText(republica.getBairro());
        view.gettxtPontoreferencia().setText(republica.getReferencia());
        view.gettxtLocalizacaoGeo().setText(republica.getLocalizacaoGeografica());
        view.gettxtCep().setText(republica.getCEP());
        id_republica = republica.getId_republica();

    }

    @Override
    public void registryObserver(Observer o) {
        if (!observadores.contains(o)) {
            this.observadores.add(o);
        }
    }

    @Override
    public void removeObserver(Observer o) {
        this.observadores.remove(o);
    }

    @Override
    public void notifyObservers() {
        for (Observer o : observadores) {

            o.update();
        }
    }

}
