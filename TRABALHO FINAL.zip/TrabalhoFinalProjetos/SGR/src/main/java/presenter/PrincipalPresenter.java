/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;


import Presenter.ConfiguracaoLogPresenter;
import adapter.RegistrosdeLog;
import dao.RepublicaDao;
import dao.UsuarioDao;
import model.RepublicaModel;
import model.UsuarioModel;
import observer.Observer;
import views.PrincipalView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import criarrepublicacommand.CriarRepublicaPresenter;
import semtetocommand.AceitarConvitesRepublicasPresenter;

/**
 *
 * @author udson
 */
public final class PrincipalPresenter implements Observer {
    ConfiguracaoLogPresenter configuracoessistema;
    PrincipalView view;
    CriarRepublicaPresenter criarrepublica;
    ManterRepublicaPresenter manter;
    AceitarConvitesRepublicasPresenter aceitarconvite;
    ConvidarAceitarMoradorPresenter convidaraceitarconvite;
    PrincipalPresenter instancia;
    String nome_usuario;
    int identificador, id_republica;

    public PrincipalPresenter(String status, String usuario, int id_usuario) throws SQLException {
        view = new PrincipalView();
        
        
       
        

        instancia = this;

        nome_usuario = usuario;
        identificador = id_usuario;

        GerarDados(status, nome_usuario, identificador);
        TipoLog();

        ConfigurarTela(status);

        view.setVisible(true);

        view.getMenuSair().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                System.exit(0);
            }
        });

        view.getMenuManterRepublica().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                try {
                    manter = new ManterRepublicaPresenter(id_usuario, status, usuario);
                    manter.registryObserver((Observer) instancia);
                } catch (SQLException ex) {
                    Logger.getLogger(PrincipalPresenter.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        view.getMenuCriarRepublica().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                boolean flag;

                //verifica se o usuario é sem teto
                if (status.equals("SEM TETO")) {
                    flag = true;
                    try {
                        criarrepublica = new CriarRepublicaPresenter(status, usuario, flag, id_usuario);
                        criarrepublica.registryObserver((Observer) instancia);
                    } catch (SQLException ex) {
                        Logger.getLogger(PrincipalPresenter.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else {
                    flag = false;
                    try {
                        criarrepublica = new CriarRepublicaPresenter(status, usuario, flag, id_usuario);
                        criarrepublica.registryObserver((Observer) instancia);
                    } catch (SQLException ex) {
                        Logger.getLogger(PrincipalPresenter.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            }
        });

        view.getMenuCriarPerfil().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    CriarPerfilPresenter criarperfil = new CriarPerfilPresenter(id_usuario);
                } catch (SQLException ex) {
                    Logger.getLogger(PrincipalPresenter.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        view.getMenuManterPerfil().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    ManterPerfilPresenter manterperfil = new ManterPerfilPresenter(id_usuario);
                } catch (SQLException ex) {
                    Logger.getLogger(PrincipalPresenter.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });

        view.getMenuManterMoradores().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    ManterMoradoresPresenter mantermoradores = new ManterMoradoresPresenter(id_usuario);
                } catch (SQLException ex) {
                    Logger.getLogger(PrincipalPresenter.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });

        view.getMenuBuscarVagas().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String republica_atual = view.getlblNomeRepublica().getText();

                if (republica_atual == null) {
                    republica_atual = "SEM REPÚBLICA";
                }

                // System.out.println(republica_atual);
                //está passando o id do usuario e se ele tiver em uma republica o nome da republica
                BuscarVagasPresenter buscarvagas = new BuscarVagasPresenter(id_usuario, republica_atual);

            }
        });

        view.getMenuConvidarMoradores().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String republica_atual = view.getlblNomeRepublica().getText();
                convidaraceitarconvite = new ConvidarAceitarMoradorPresenter(republica_atual, identificador, id_republica);
                convidaraceitarconvite.registryObserver((Observer) instancia);

            }
        });

        view.getMenuAceitarConvite().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                aceitarconvite = new AceitarConvitesRepublicasPresenter(id_usuario, status);
                aceitarconvite.registryObserver((Observer) instancia);

            }
        });
        
        
        view.getMenuManterReceitasDespesas().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              
              ManterReceitasDespesasPresenter manterreceitasdespesas = new ManterReceitasDespesasPresenter(id_republica);  
                
                
            }
        });
        
        
        view.getMenuConsultarReceitasDespesas().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
             
                
                
               ConsultarMinhasDespesasReceitasPresenter consultarminhasreceitasdespesas = new ConsultarMinhasDespesasReceitasPresenter(id_usuario, id_republica);
                
                
            }
        });
        
        
        
        view.getjMenuItemLog().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              
              configuracoessistema = new ConfiguracaoLogPresenter();
                 configuracoessistema.registryObserver((Observer)instancia);   
                
                
            }
        });
        
        
        view.getMenuConsultarResultadoMensal().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              ConsultarResultadoMensalPresenter consultarresultadomensal = new ConsultarResultadoMensalPresenter(id_republica);
            }
        });
        
        
        view.getMenuRegistrarPagamentoReceitaDespesa().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                 ConsultarMinhasDespesasReceitasPresenter consultarminhasreceitasdespesas = new ConsultarMinhasDespesasReceitasPresenter(id_usuario, id_republica);
            }
        });
        
        
        
        

    }

    private void GerarDados(String status, String usuario, int id_usuario) throws SQLException {

        view.getlblstatus().setText(status);
        view.getlblusuario().setText(usuario);

        RepublicaDao pesquisarrepublica = new RepublicaDao();

        RepublicaModel republicamodel = new RepublicaModel();

        republicamodel.setId_usuario(id_usuario);

        RepublicaModel republica = pesquisarrepublica.PesquisaNomeVagasRepublica(republicamodel);

        id_republica = republica.getId_republica();

        view.getlblNomeRepublica().setText(republica.getNomeRepublica());
        view.getlblQuantidadeMoradores().setText(String.valueOf(republica.getVagasOcupadas()));

    }

    private void ConfigurarTela(String status) {

        if (status.equals("REPRESENTANTE DA REPÚBLICA")) {

            view.getMenuManterRepublica().setEnabled(true);
            view.getMenuManterMoradores().setEnabled(true);
            view.getMenuConfirmarSolucao().setEnabled(true);
            view.getMenuConvidarMoradores().setEnabled(true);
            view.getMenuManterTarefas().setEnabled(true);
            view.getMenuManterReceitasDespesas().setEnabled(true);
            view.getMenuFazerEstorno().setEnabled(true);
            view.getMenuManterPerfil().setEnabled(true);
            view.getjMenuItemLog().setEnabled(true);

            view.getMenuCriarRepublica().setEnabled(true);
            view.getMenuBuscarVagas().setEnabled(false);

            view.getMenuConsultarResultadoMensal().setEnabled(false);
            view.getMenuManterReclamacoesSugestoes().setEnabled(false);

            view.getMenuAceitarConvite().setEnabled(false);
            view.getMenuRegistrarConclusaoTarefas().setEnabled(false);
            view.getMenuConsultarReceitasDespesas().setEnabled(true);
            view.getMenuRegistrarPagamentoReceitaDespesa().setEnabled(false);

        } else if (status.equals("MORADOR DA REPÚBLICA")) {
            view.getMenuManterRepublica().setEnabled(false);
            view.getMenuManterMoradores().setEnabled(false);
            view.getMenuConfirmarSolucao().setEnabled(false);
            view.getMenuConvidarMoradores().setEnabled(true);
            view.getMenuManterTarefas().setEnabled(false);
            view.getMenuManterReceitasDespesas().setEnabled(false);
            view.getMenuFazerEstorno().setEnabled(false);
            view.getjMenuItemLog().setEnabled(false);

            view.getMenuCriarRepublica().setEnabled(false);
            view.getMenuBuscarVagas().setEnabled(false);

            view.getMenuConsultarResultadoMensal().setEnabled(true);
            view.getMenuManterReclamacoesSugestoes().setEnabled(true);
            view.getMenuManterPerfil().setEnabled(true);
            view.getMenuAceitarConvite().setEnabled(false);
            view.getMenuRegistrarConclusaoTarefas().setEnabled(true);
            view.getMenuConsultarReceitasDespesas().setEnabled(true);
            view.getMenuRegistrarPagamentoReceitaDespesa().setEnabled(true);
        } else {
            view.getMenuManterRepublica().setEnabled(false);
            view.getMenuManterMoradores().setEnabled(false);
            view.getMenuConfirmarSolucao().setEnabled(false);
            view.getMenuConvidarMoradores().setEnabled(false);
            view.getMenuManterTarefas().setEnabled(false);
            view.getMenuManterReceitasDespesas().setEnabled(false);
            view.getMenuFazerEstorno().setEnabled(false);
            view.getjMenuItemLog().setEnabled(false);

            view.getMenuCriarRepublica().setEnabled(true);
            view.getMenuBuscarVagas().setEnabled(true);

            view.getMenuConsultarResultadoMensal().setEnabled(false);
            view.getMenuManterReclamacoesSugestoes().setEnabled(false);
            view.getMenuManterPerfil().setEnabled(true);
            view.getMenuAceitarConvite().setEnabled(true);
            view.getMenuRegistrarConclusaoTarefas().setEnabled(false);
            view.getMenuConsultarReceitasDespesas().setEnabled(false);
            view.getMenuRegistrarPagamentoReceitaDespesa().setEnabled(false);
        }

    }

    public void Pesquisa_status() throws SQLException {
        UsuarioModel usuariomodel = new UsuarioModel();
        usuariomodel.setNome_usuario(view.getlblusuario().getText());

        UsuarioDao pesquisa = new UsuarioDao();

        UsuarioModel user = pesquisa.PesquisaUsuario(usuariomodel);

        String status = user.getStatus();

        view.getlblstatus().setText(status);

    }

    @Override
    public void update() {

        try {
            //pesquisa status
            Pesquisa_status();
            String status = view.getlblstatus().getText();
            GerarDados(status, nome_usuario, identificador);
            ConfigurarTela(status);
            TipoLog();
        } catch (SQLException ex) {
            Logger.getLogger(PrincipalPresenter.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    
    
      public void TipoLog() {

         String tipo_log; 
      
          RegistrosdeLog pesquisa = new RegistrosdeLog();
        

         tipo_log = pesquisa.Pesquisatipolog();

        view.getlbltipolog().setText(tipo_log);
    

    }

}
