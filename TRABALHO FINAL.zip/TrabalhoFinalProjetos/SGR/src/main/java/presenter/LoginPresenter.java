/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import views.LoginView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import dao.UsuarioDao;
import model.UsuarioModel;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author udson
 */
public class LoginPresenter {

    LoginView view;

    public LoginPresenter() {

        view = new LoginView();

        view.gettxtSenha().setText("");

        view.setVisible(true);

        view.getbtnNovoUsuario().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                CadastroUsuarioPresenter cadastro = new CadastroUsuarioPresenter();
                view.dispose();

            }
        });

        view.getbtnAcessar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                try {
                    String usuario = view.gettxtUsuario().getText();
                    String senha = view.gettxtSenha().getText();
                    
                    UsuarioModel usuariomodel = new UsuarioModel();
                     usuariomodel.setNome_usuario(usuario);
                    
                    UsuarioDao pesquisa = new UsuarioDao();
                    
                    UsuarioModel user = pesquisa.PesquisaUsuario(usuariomodel);
                    
                    String status  = user.getStatus();
                    int id_usuario = user.getId_usuario();
                    
                    // System.out.println(nivel_acesso);
                    
                    if (senha.equals(user.getSenha())) {
                        PrincipalPresenter principal = new PrincipalPresenter(status,usuario,id_usuario);
                        view.dispose();
                    } else {
                        JOptionPane.showMessageDialog(view, "USUÁRIO OU SENHA INCORRETOS!");
                        view.gettxtUsuario().setText("");
                        view.gettxtSenha().setText("");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(LoginPresenter.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });

       

    }

}
