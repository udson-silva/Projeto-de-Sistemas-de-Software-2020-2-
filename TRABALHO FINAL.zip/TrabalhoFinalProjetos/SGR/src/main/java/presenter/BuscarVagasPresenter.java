/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import dao.PerfilMoradorDao;
import dao.SolicitaMoradiaDao;
import dao.TabelaBuscarVagas;
import model.ModelTabela;
import model.SolicitaMoradiaModel;
import model.UsuarioModel;
import views.BuscarVagasRepublicaView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

/**
 *
 * @author udson
 */
public class BuscarVagasPresenter {

    BuscarVagasRepublicaView view;
    String nome_republica = null, perfil_redesocial, nome_solicitante;
    int id_perfil_user;

    BuscarVagasPresenter(int id_usuario, String republica_atual) {

        view = new BuscarVagasRepublicaView();

        view.gettxtDE().setVisible(false);
        view.gettxtValorAte().setVisible(false);
        view.getlblAte().setVisible(false);
        view.getlblDe().setVisible(false);

        view.setVisible(true);

        view.getCbBusca().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (view.getCbBusca().getSelectedItem().equals("intervalo de valor médio de despesas mensais")) {
                    view.gettxtDE().setVisible(true);
                    view.gettxtValorAte().setVisible(true);
                    view.getlblAte().setVisible(true);
                    view.getlblDe().setVisible(true);
                    view.getTxtBusca().setVisible(false);
                    view.getlblDigite().setText("");
                } else {
                    view.gettxtDE().setVisible(false);
                    view.gettxtValorAte().setVisible(false);
                    view.getlblAte().setVisible(false);
                    view.getlblDe().setVisible(false);
                    view.getTxtBusca().setVisible(true);
                    String texto = (String) view.getCbBusca().getSelectedItem();
                    view.getlblDigite().setText(texto);

                }

            }
        });

        view.getTblListaRepublica().addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

                nome_republica = (String) view.getTblListaRepublica().getValueAt(view.getTblListaRepublica().getSelectedRow(), 0);

            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        view.getBtnBusca().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (view.getCbBusca().getSelectedItem().equals("Nome")) {

                    Preencher_Tabela("select *from republicas where nome_republica like'%" + view.getTxtBusca().getText() + "%'");

                } else if (view.getCbBusca().getSelectedItem().equals("Vantagens")) {
                    Preencher_Tabela("select *from republicas where vantagens like'%" + view.getTxtBusca().getText() + "%'");
                } else {

                    float despesa_inicial = Float.parseFloat(view.gettxtDE().getText());
                    float despesa_final = Float.parseFloat(view.gettxtValorAte().getText());
                    Preencher_Tabela("select *from republicas where despesa_media_morador >=" + despesa_inicial + " and despesa_media_morador <=" + despesa_final + "");
                }

            }
        });

        view.getBtnVerInformacoes().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (nome_republica != null) {

                    try {
                        InformacoesRepublica informacoes = new InformacoesRepublica(nome_republica);
                    } catch (SQLException ex) {
                        Logger.getLogger(BuscarVagasPresenter.class.getName()).log(Level.SEVERE, null, ex);
                    }

                } else {

                    JOptionPane.showMessageDialog(view, "Favor Selecionar uma República na Tabela!");

                }

            }
        });

        view.getBtnSolicitarMoradia().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                boolean pesquisa_perfil;
                if (nome_republica != null) {

                    try {
                        //verifica se o usuario tem um perfil no sistema associado a ele se nao ele emite o alerta e 
                        //direciona o mesmo para criar um perfil
                        pesquisa_perfil = VerificarPerfilUsuario(id_usuario);

                        //se o retorno for verdadeiro significa que o usuario tem perfil cadastrado no sistema
                        if (pesquisa_perfil == true) {
                            SolicitaMoradiaModel solicitarmoradiamodel = new SolicitaMoradiaModel();
                            SolicitaMoradiaDao solicitar = new SolicitaMoradiaDao();

                            solicitarmoradiamodel.setId_perfil_usuario(id_perfil_user);
                            solicitarmoradiamodel.setNome_solicitante(nome_solicitante);
                            solicitarmoradiamodel.setPerfilredesocial(perfil_redesocial);
                            solicitarmoradiamodel.setRepublica_atual(republica_atual);
                            solicitarmoradiamodel.setRepublica_solicitada(nome_republica);
                            solicitarmoradiamodel.setStatus("PENDENTE");
                            solicitar.SolicitarMoradia(solicitarmoradiamodel);
                            JOptionPane.showMessageDialog(view, "Solicitação de Moradia Realizada com Sucesso!");
                            view.dispose();

                        } else {
                            JOptionPane.showMessageDialog(view, "USUÁRIO NÃO TEM UM PERFIL CADASTRADO, FAVOR REALIZAR O CADASTRO!");
                            CriarPerfilPresenter criarperfil = new CriarPerfilPresenter(id_usuario);

                            view.dispose();
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(BuscarVagasPresenter.class.getName()).log(Level.SEVERE, null, ex);
                    }

                } else {

                    JOptionPane.showMessageDialog(view, "Favor Selecionar uma República na Tabela!");

                }
            }
        });

    }

    public boolean VerificarPerfilUsuario(int id_usuario) throws SQLException {

        boolean tem_perfil;
        UsuarioModel retorno;
        UsuarioModel usuariomodel = new UsuarioModel();
        usuariomodel.setId_usuario(id_usuario);
        PerfilMoradorDao pesquisar = new PerfilMoradorDao();

        retorno = pesquisar.PesquisaPerfilUsuario(usuariomodel);

        id_perfil_user = usuariomodel.getId_usuario();
        nome_solicitante = usuariomodel.getNome_usuario();
        perfil_redesocial = usuariomodel.getLink_rede();

        if (nome_solicitante == null) {

            tem_perfil = false;

        } else {
            tem_perfil = true;
        }
        return tem_perfil;
    }

    private void Preencher_Tabela(String sql) {

        ArrayList dados = new ArrayList();

        TabelaBuscarVagas buscarvagas = new TabelaBuscarVagas();

        dados = buscarvagas.Preencher_Tabela(sql);

        try {

            String[] Colunas = new String[]{"Nome", "Despesas Média", "Vagas Disponíveis", "Total Vagas"};

            ModelTabela modelo = new ModelTabela(dados, Colunas);

            view.getTblListaRepublica().setModel(modelo);

            view.getTblListaRepublica().getColumnModel().getColumn(0).setPreferredWidth(240);
            view.getTblListaRepublica().getColumnModel().getColumn(0).setResizable(false);
            view.getTblListaRepublica().getColumnModel().getColumn(1).setPreferredWidth(160);
            view.getTblListaRepublica().getColumnModel().getColumn(1).setResizable(false);
            view.getTblListaRepublica().getColumnModel().getColumn(2).setPreferredWidth(160);
            view.getTblListaRepublica().getColumnModel().getColumn(2).setResizable(false);
            view.getTblListaRepublica().getColumnModel().getColumn(3).setPreferredWidth(160);
            view.getTblListaRepublica().getColumnModel().getColumn(3).setResizable(false);

            view.getTblListaRepublica().setRowHeight(35);
            view.getTblListaRepublica().getTableHeader().setReorderingAllowed(false);
            view.getTblListaRepublica().setAutoResizeMode(view.getTblListaRepublica().AUTO_RESIZE_OFF);
            view.getTblListaRepublica().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        } catch (Exception e) {

            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

    }

}
