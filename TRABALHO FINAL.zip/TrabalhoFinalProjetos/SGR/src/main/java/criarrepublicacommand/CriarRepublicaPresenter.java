/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package criarrepublicacommand;

import Model.LogModel;
import adapter.RegistrosdeLog;
import dao.PerfilMoradorDao;
import dao.RepublicaDao;

import model.RepublicaModel;

import views.CriarRepublicaView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.SQLException;
import javax.swing.JOptionPane;
import observer.Observado;
import observer.Observer;
import java.util.ArrayList;
import presenter.CriarPerfilPresenter;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author udson
 */
public final class CriarRepublicaPresenter implements Observado, ICommandCriarRepublica {

    CriarRepublicaView view;

    final ArrayList<Observer> observadores;

    int totalVagas, vagasOcupadas, vagasdisponiveis, id;

    public CriarRepublicaPresenter(String status, String usuario, boolean flag, int id_usuario) throws SQLException {

        id = id_usuario;

        observadores = new ArrayList<Observer>();

        view = new CriarRepublicaView();

        view.setVisible(true);

        //verifica se o usuario já tem uma republica associada a ele!
        VerificarRepublicaUsuario(id_usuario);
        //verifica se o usuario já tem um perfil cadastrado no sistema para criar republica
        VerificarPerfilUsuario(id_usuario);

        view.getBtnCriarRepublica().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                //inserir dados da tela em model republica
                totalVagas = Integer.parseInt(view.gettxttotalvagas().getText());
                vagasOcupadas = Integer.parseInt(view.gettxtvagasocupadas().getText());

                vagasdisponiveis = totalVagas - vagasOcupadas;
                view.gettxtVagasdisponiveis().setText(String.valueOf(vagasdisponiveis));

                if (vagasdisponiveis > 0) {

                    //System.out.println(flag);
                    // se for sem teto a flag será true então ele chama o state e troca no bancop o estado do usuario
                    if (flag == true) {
                        //alterando o status do usuario caso ele for sem teto

                        //cria uma republica
                        executar();

                        ICommandCriarRepublica mudarstatuscriadorrepublica = new MudarStatusCriadorRepublicaCommand(status, id_usuario);
                        mudarstatuscriadorrepublica.executar();
                        JOptionPane.showMessageDialog(view, " Status do Usuário Alterado com Sucesso!");

                    }

                    float rateio = Float.parseFloat(view.gettxtdespesamedia().getText());

                    //pega a data do sistema e formata em mes e ano
                    Date dataSistema = new Date();
                    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                    String dataingresso = formato.format(dataSistema);

                    ICommandCriarRepublica inserirmoradornarepublica = new InserirMoradorNaRepublicaCommand(id_usuario, rateio, dataingresso);
                    inserirmoradornarepublica.executar();


                    notifyObservers();
                    
                    
                    LogModel logmodel = new LogModel();

                    logmodel.setUsuario(String.valueOf(id_usuario));
                    logmodel.setOperacao("INCLUSÃO DE REPÚBLICA");
                    logmodel.setNome(String.valueOf(id_usuario));

                    RegistrosdeLog gravarlog = new RegistrosdeLog();
                    gravarlog.GravaLog(logmodel);
                    
                    

                    view.dispose();
                } else {
                    JOptionPane.showMessageDialog(view, "Número de vagas ocupadas superior ao total!");
                }

            }

        });
    }

    //verifica antes de cadastrar se o usuario não tem uma republica cadastrada em seu nome
    public final void VerificarRepublicaUsuario(int id_usuario) throws SQLException {

        boolean retorno;
        RepublicaDao pesquisar = new RepublicaDao();

        retorno = pesquisar.PesquisaUsuario(id_usuario);

        if (retorno == true) {
            JOptionPane.showMessageDialog(view, "USUÁRIO JÁ TEM UMA REPÚBLICA ASSOCIADA A ELE!");
            view.dispose();
        }

    }

    public void VerificarPerfilUsuario(int id_usuario) throws SQLException {

        boolean retorno;
        PerfilMoradorDao pesquisarmoradordao = new PerfilMoradorDao();

        retorno = pesquisarmoradordao.PesquisaUsuario(id_usuario);

        if (retorno == false) {
            JOptionPane.showMessageDialog(view, "USUÁRIO NÃO TEM UM PERFIL CADASTRADO NO SISTEMA, FAVOR CADASTRAR!");
            view.dispose();
            CriarPerfilPresenter criarPerfilPresenter = new CriarPerfilPresenter(id_usuario);

        }

    }

    @Override
    public void registryObserver(Observer o) {
        if (!observadores.contains(o)) {
            this.observadores.add(o);
        }
    }

    @Override
    public void removeObserver(Observer o) {
        this.observadores.remove(o);
    }

    @Override
    public void notifyObservers() {
        for (Observer o : observadores) {

            o.update();
        }
    }

    @Override
    public void executar() {
        RepublicaModel republica = new RepublicaModel();
        republica.setNomeRepublica(view.gettxtnome().getText());
        republica.setDataFundacao(view.gettxtdatafundacao().getText());
        republica.setDespesaMedia(Float.parseFloat(view.gettxtdespesamedia().getText()));
        republica.setTotalVagas(Integer.parseInt(view.gettxttotalvagas().getText()));

        //vagas ocupadas serão o total de vagas -1 do criador da republica
        //que já deve está ocupando um lugar. Devo corrigir essa parte depois
        republica.setVagasOcupadas(vagasOcupadas);

        //Total de Vagas não é editavel na tela de criação e os dados serão pegos aki
        republica.setVagasDisponiveis(vagasdisponiveis);

        republica.setVantagens(view.gettxtVantagens().getText());
        republica.setCodigoEtica(view.gettxtcodigoetica().getText());
        republica.setLogradouro(view.gettxtLogadouro().getText());
        republica.setBairro(view.gettxtendereco().getText());
        republica.setReferencia(view.gettxtPontoreferencia().getText());
        republica.setLocalizacaoGeografica(view.gettxtLocalizacaoGeo().getText());
        republica.setCEP(view.gettxtCep().getText());
        republica.setId_usuario(id);
        //limpar dados da tela

        RepublicaDao cadastrar = new RepublicaDao();
        cadastrar.inserirRepublica(republica);

        JOptionPane.showMessageDialog(view, "República cadastrada com sucesso!");

    }

}
