/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package criarrepublicacommand;

import Model.LogModel;
import adapter.RegistrosdeLog;
import dao.MoradoresRepublicaDao;
import dao.RepublicaDao;
import model.MoradorRepublicaModel;
import model.RepublicaModel;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author udson
 */
public class InserirMoradorNaRepublicaCommand implements ICommandCriarRepublica {

    public int id;
    public float despesa_media;
    public String data_ingresso;

    public InserirMoradorNaRepublicaCommand(int id_usuario, float rateio, String data) {

        id = id_usuario;
        despesa_media = rateio;
        data_ingresso = data;

    }

    @Override
    public void executar() {

        //pesquisa a republica do usuario
        RepublicaDao pesquisar = new RepublicaDao();

        RepublicaModel republicamodel = new RepublicaModel();
        RepublicaModel pesquisarepublica = new RepublicaModel();
        republicamodel.setId_usuario(id);

        try {
            pesquisarepublica = pesquisar.PesquisaRepublicaPosCriacao(republicamodel);
        } catch (SQLException ex) {
            Logger.getLogger(InserirMoradorNaRepublicaCommand.class.getName()).log(Level.SEVERE, null, ex);
        }

      
        int id_republica = pesquisarepublica.getId_republica();

        //encapsula os dados para inserir na tabela moradores_republica
        MoradorRepublicaModel morador = new MoradorRepublicaModel();
        morador.setId_morador(id);
        morador.setId_republica(id_republica);
        morador.setRateio(despesa_media);
        morador.setData_ingresso(data_ingresso);

        //aqui insere o morador e a republica na tabela moradores_republica
        MoradoresRepublicaDao inserir = new MoradoresRepublicaDao();
        inserir.inserirMoradoresRepublica(morador);
        
         LogModel logmodel = new LogModel();

         logmodel.setUsuario(String.valueOf(id));
         logmodel.setOperacao("INCLUSÃO DE MORADOR NA REPÚBLICA");
         logmodel.setNome(String.valueOf(id));

         RegistrosdeLog gravarlog = new RegistrosdeLog();
         gravarlog.GravaLog(logmodel);

    }

}
