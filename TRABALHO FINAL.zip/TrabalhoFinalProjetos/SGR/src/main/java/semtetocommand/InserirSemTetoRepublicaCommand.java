/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semtetocommand;

import dao.MoradoresRepublicaDao;

import model.MoradorRepublicaModel;

/**
 *
 * @author udson
 */
public class InserirSemTetoRepublicaCommand implements ICommandSemTeto {

    public int id, id_republica;
    public float despesa_media;
    public String data_ingresso;

    public InserirSemTetoRepublicaCommand(int id_usuario, float rateio, String data, int idrepublica) {

        id_republica = idrepublica;
        id = id_usuario;
        despesa_media = rateio;
        data_ingresso = data;

    }

    @Override
    public void executar() {

        //encapsula os dados para inserir na tabela moradores_republica
        MoradorRepublicaModel morador = new MoradorRepublicaModel();
        morador.setId_morador(id);
        morador.setId_republica(id_republica);
        morador.setRateio(despesa_media);
        morador.setData_ingresso(data_ingresso);

        //aqui insere o morador e a republica na tabela moradores_republica
        MoradoresRepublicaDao inserir = new MoradoresRepublicaDao();
        inserir.inserirMoradoresRepublica(morador);

    }

}
