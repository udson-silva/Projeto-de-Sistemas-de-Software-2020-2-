/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semtetocommand;

import dao.RepublicaDao;
import model.RepublicaModel;
import views.AceitarConvitesRepublicasView;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author udson
 */
public class VerificarVagasRepublicaPresenter implements ICommandSemTeto {

    String nome_republica;

    AceitarConvitesRepublicasView view;

    public VerificarVagasRepublicaPresenter(String nomerepublica) {
        nome_republica = nomerepublica;

    }

    @Override
    public void executar() {

        int total_vagas, vagas_disponiveis, vagas_ocupadas, id_republica;

        try {
            RepublicaDao pesquisar = new RepublicaDao();

            RepublicaModel republicamodel = new RepublicaModel();

            republicamodel.setNomeRepublica(nome_republica);

            RepublicaModel republica = pesquisar.PesquisaVagasRepublica(republicamodel);

            total_vagas = republica.getTotalVagas();
            vagas_disponiveis = republica.getVagasDisponiveis();
            vagas_ocupadas = republica.getVagasOcupadas();

            id_republica = republica.getId_republica();
            vagas_disponiveis = vagas_disponiveis - 1;
            vagas_ocupadas = vagas_ocupadas + 1;

            if (vagas_ocupadas > total_vagas) {
                JOptionPane.showMessageDialog(view, "República Não tem mais vagas disponiveis!");

            } else {

                republicamodel.setVagasDisponiveis(vagas_disponiveis);
                republicamodel.setVagasOcupadas(vagas_ocupadas);
                republicamodel.setId_republica(id_republica);

                RepublicaDao alterarvagasrepublica = new RepublicaDao();
                alterarvagasrepublica.AlterarVagasRepublica(republica);

            }
        } catch (SQLException ex) {
            Logger.getLogger(VerificarVagasRepublicaPresenter.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
