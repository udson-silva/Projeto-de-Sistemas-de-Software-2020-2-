/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semtetocommand;


import dao.RecusarConviteMoradiaDao;
import model.MoradorRepublicaModel;

/**
 *
 * @author Pessoal
 */
public class RecusarConviteCommand implements ICommandSemTeto{
    
    int cod_republica;
    
    
    public RecusarConviteCommand(int id_republica){
        
        cod_republica = id_republica;
        
    }

    @Override
    public void executar() {
     
       MoradorRepublicaModel morador = new MoradorRepublicaModel();
      
        morador.setId_republica(cod_republica);  
        
         //aqui deleta o convite 
         RecusarConviteMoradiaDao recusarconvite = new RecusarConviteMoradiaDao();
         recusarconvite.RecusarConvite(cod_republica);
       
        
    }
    
}
