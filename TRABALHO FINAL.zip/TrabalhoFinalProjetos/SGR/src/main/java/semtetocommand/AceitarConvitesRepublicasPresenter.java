/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semtetocommand;

/**
 *
 * @author Pessoal
 */
import dao.TabelaAceitacaoRepublicas;
import model.ModelTabela;
import observer.Observado;
import observer.Observer;
import views.AceitarConvitesRepublicasView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class AceitarConvitesRepublicasPresenter implements Observado, Observer {

    float rateio = 0;
    String nome_republica;
    int id_republica = 0, cod_usuario;
    AceitarConvitesRepublicasView view;
    final ArrayList<Observer> observadores;

    public AceitarConvitesRepublicasPresenter(int id_usuario, String status) {

        cod_usuario = id_usuario;
        observadores = new ArrayList<Observer>();
        view = new AceitarConvitesRepublicasView();

        view.setVisible(true);

        try {
            Preencher_Tabela("select *from convite_morador inner join republicas on convite_morador.id_republica"
                    + " = republicas.id_republica inner join perfil_morador on convite_morador.id_usuario_convidado = "
                    + "perfil_morador.id_usuario where convite_morador.id_usuario_convidado =" + id_usuario + "");
        } catch (SQLException ex) {
            Logger.getLogger(AceitarConvitesRepublicasPresenter.class.getName()).log(Level.SEVERE, null, ex);
        }

        view.getbtnAceitar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (rateio != 0) {

                    ICommandSemTeto verificarvagasrepublica = new VerificarVagasRepublicaPresenter(nome_republica);

                    verificarvagasrepublica.executar();

                    //pega a data do sistema e formata em mes e ano
                    Date dataSistema = new Date();
                    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                    String dataingresso = formato.format(dataSistema);

                    ICommandSemTeto inserirsemtetonarepublica = new InserirSemTetoRepublicaCommand(id_usuario, rateio, dataingresso, id_republica);
                    inserirsemtetonarepublica.executar();
                    JOptionPane.showMessageDialog(view, " Convite Aceito com Sucesso!");

                    ICommandSemTeto mudarstatus = new MudarStatusUsuarioCommand(status, id_usuario);

                    mudarstatus.executar();

                    JOptionPane.showMessageDialog(view, " Status do Usuário Alterado com Sucesso!");
                    notifyObservers();
                    view.dispose();

                } else {

                    JOptionPane.showMessageDialog(view, "Selecione uma república na tabela, para aceitar o convite!");

                }

            }
        });

        view.getbtnRecusar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (id_republica != 0) {

                    ICommandSemTeto recusarconvite = new RecusarConviteCommand(id_republica);
                    recusarconvite.executar();
                    JOptionPane.showMessageDialog(view, "Convite Excluído!");
                    update();

                } else {
                    JOptionPane.showMessageDialog(view, "Selecione uma república na tabela!");

                }

            }
        });

        view.getjTableAceitarConvite().addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

                id_republica = (int) view.getjTableAceitarConvite().getValueAt(view.getjTableAceitarConvite().getSelectedRow(), 0);
                nome_republica = (String) view.getjTableAceitarConvite().getValueAt(view.getjTableAceitarConvite().getSelectedRow(), 1);
                rateio = (float) view.getjTableAceitarConvite().getValueAt(view.getjTableAceitarConvite().getSelectedRow(), 5);

            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

    }

    private void Preencher_Tabela(String sql) throws SQLException {

        ArrayList dados = new ArrayList();

        TabelaAceitacaoRepublicas vagasaceitar = new TabelaAceitacaoRepublicas();

        dados = vagasaceitar.Preencher_TabelaConvite(sql);

        try {

            String[] Colunas = new String[]{"Cód Rep", "República", "Data Fundação", "Endereço", "Número de Vagas Disponíveis", "Despesas Média Morador"};

            ModelTabela modelo = new ModelTabela(dados, Colunas);

            view.getjTableAceitarConvite().setModel(modelo);

            view.getjTableAceitarConvite().getColumnModel().getColumn(0).setPreferredWidth(100);
            view.getjTableAceitarConvite().getColumnModel().getColumn(0).setResizable(false);
            view.getjTableAceitarConvite().getColumnModel().getColumn(1).setPreferredWidth(150);
            view.getjTableAceitarConvite().getColumnModel().getColumn(1).setResizable(false);
            view.getjTableAceitarConvite().getColumnModel().getColumn(2).setPreferredWidth(100);
            view.getjTableAceitarConvite().getColumnModel().getColumn(2).setResizable(false);
            view.getjTableAceitarConvite().getColumnModel().getColumn(3).setPreferredWidth(180);
            view.getjTableAceitarConvite().getColumnModel().getColumn(3).setResizable(false);
            view.getjTableAceitarConvite().getColumnModel().getColumn(4).setPreferredWidth(200);
            view.getjTableAceitarConvite().getColumnModel().getColumn(4).setResizable(false);
            view.getjTableAceitarConvite().getColumnModel().getColumn(5).setPreferredWidth(180);
            view.getjTableAceitarConvite().getColumnModel().getColumn(5).setResizable(false);

            view.getjTableAceitarConvite().setRowHeight(35);
            view.getjTableAceitarConvite().getTableHeader().setReorderingAllowed(false);
            view.getjTableAceitarConvite().setAutoResizeMode(view.getjTableAceitarConvite().AUTO_RESIZE_OFF);
            view.getjTableAceitarConvite().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        } catch (Exception e) {

            // System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
            System.out.println(e);
        }

    }

    @Override
    public void registryObserver(Observer o) {
        if (!observadores.contains(o)) {
            this.observadores.add(o);
        }
    }

    @Override
    public void removeObserver(Observer o) {
        this.observadores.remove(o);
    }

    @Override
    public void notifyObservers() {
        for (Observer o : observadores) {

            o.update();
        }
    }

    @Override
    public void update() {
        try {
            Preencher_Tabela("select *from convite_morador inner join republicas on convite_morador.id_republica"
                    + " = republicas.id_republica inner join perfil_morador on convite_morador.id_usuario_convidado = "
                    + "perfil_morador.id_usuario where convite_morador.id_usuario_convidado =" + cod_usuario + "");
        } catch (SQLException ex) {
            Logger.getLogger(AceitarConvitesRepublicasPresenter.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
