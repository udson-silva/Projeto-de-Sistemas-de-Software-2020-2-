/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semtetocommand;


import dao.UsuarioDao;
import model.UsuarioModel;
import state.IUsuarioState;
import state.UsuarioState;


/**
 *
 * @author udson
 */
public class MudarStatusUsuarioCommand implements ICommandSemTeto {

    public String estado;
    public int id;

    public MudarStatusUsuarioCommand(String status, int id_usuario) {
        estado = status;
        id = id_usuario;

    }

    @Override
    public void executar() {
        IUsuarioState state = new UsuarioState();

        String Tipo_status = state.AlterarEstado(estado);
        //mudando o status do usuario no banco
        UsuarioModel usuariomodel = new UsuarioModel();

        usuariomodel.setId_usuario(id);
        usuariomodel.setStatus(Tipo_status);

        UsuarioDao alterarstatus = new UsuarioDao();
        alterarstatus.AlterarStatusUsuario(usuariomodel);

    }

}
