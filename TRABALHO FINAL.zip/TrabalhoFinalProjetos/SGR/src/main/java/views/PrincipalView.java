/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import javax.swing.JDesktopPane;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

/**
 *
 * @author nandi
 */
public class PrincipalView extends javax.swing.JFrame {

    /**
     * Creates new form TelaInicialView
     */
    public PrincipalView() {
        initComponents();
    }

    
    public JLabel getlblNomeRepublica(){
        return lblNomeRepublica;
    }
    
     public JLabel getlblQuantidadeMoradores(){
        return lblQuantidadeMoradores;
    }
    
    public JMenuItem getMenuAceitarConvite() {
        return menuAceitarConvite;
    }
    
    public JMenuItem getMenuCriarPerfil(){
        return jMenuItemCriarPerfil;
    }

    public void setMenuAceitarConvite(JMenuItem menuAceitarConvite) {
        this.menuAceitarConvite = menuAceitarConvite;
    }

    public JMenuItem getMenuBuscarVagas() {
        return menuBuscarVagas;
    }

    public void setMenuBuscarVagas(JMenuItem menuBuscarVagas) {
        this.menuBuscarVagas = menuBuscarVagas;
    }

    public JMenuItem getMenuConfirmarSolucao() {
        return menuConfirmarSolucao;
    }

    public void setMenuConfirmarSolucao(JMenuItem menuConfirmarSolucao) {
        this.menuConfirmarSolucao = menuConfirmarSolucao;
    }

    public JMenuItem getMenuConsultarReceitasDespesas() {
        return menuConsultarReceitasDespesas;
    }

    public void setMenuConsultarReceitasDespesas(JMenuItem menuConsultarReceitasDespesas) {
        this.menuConsultarReceitasDespesas = menuConsultarReceitasDespesas;
    }

    public JMenuItem getMenuConsultarResultadoMensal() {
        return menuConsultarResultadoMensal;
    }

    public void setMenuConsultarResultadoMensal(JMenuItem menuConsultarResultadoMensal) {
        this.menuConsultarResultadoMensal = menuConsultarResultadoMensal;
    }

    public JMenuItem getMenuConvidarMoradores() {
        return menuConvidarMoradores;
    }

    public void setMenuConvidarMoradores(JMenuItem menuConvidarMoradores) {
        this.menuConvidarMoradores = menuConvidarMoradores;
    }

    public JMenuItem getMenuCriarRepublica() {
        return menuCriarRepublica;
    }

    public void setMenuCriarRepublica(JMenuItem menuCriarRepublica) {
        this.menuCriarRepublica = menuCriarRepublica;
    }

    public JMenuItem getMenuFazerEstorno() {
        return menuFazerEstorno;
    }

    public void setMenuFazerEstorno(JMenuItem menuFazerEstorno) {
        this.menuFazerEstorno = menuFazerEstorno;
    }

    public JMenuItem getMenuManterPerfil() {
        return menuManterPerfil;
    }

    public void setMenuManterPerfil(JMenuItem menuManterPerfil) {
        this.menuManterPerfil = menuManterPerfil;
    }

    public JMenuItem getMenuManterReceitasDespesas() {
        return menuManterReceitasDespesas;
    }

    public void setMenuManterReceitasDespesas(JMenuItem menuManterReceitasDespesas) {
        this.menuManterReceitasDespesas = menuManterReceitasDespesas;
    }

    public JMenuItem getMenuManterReclamacoesSugestoes() {
        return menuManterReclamacoesSugestoes;
    }

    public void setMenuManterReclamacoesSugestoes(JMenuItem menuManterReclamacoesSugestoes) {
        this.menuManterReclamacoesSugestoes = menuManterReclamacoesSugestoes;
    }

    public JMenuItem getMenuManterRepublica() {
        return menuManterRepublica;
    }

    public void setMenuManterRepublica(JMenuItem menuManterRepublica) {
        this.menuManterRepublica = menuManterRepublica;
    }

    public JMenuItem getMenuManterTarefas() {
        return menuManterTarefas;
    }

    public void setMenuManterTarefas(JMenuItem menuManterTarefas) {
        this.menuManterTarefas = menuManterTarefas;
    }

    public JMenuItem getMenuRegistrarConclusaoTarefas() {
        return menuRegistrarConclusaoTarefas;
    }

    public void setMenuRegistrarConclusaoTarefas(JMenuItem menuRegistrarConclusaoTarefas) {
        this.menuRegistrarConclusaoTarefas = menuRegistrarConclusaoTarefas;
    }

    public JMenuItem getMenuRegistrarPagamentoReceitaDespesa() {
        return menuRegistrarPagamentoReceitaDespesa;
    }

    public void setMenuRegistrarPagamentoReceitaDespesa(JMenuItem menuRegistrarPagamentoReceitaDespesa) {
        this.menuRegistrarPagamentoReceitaDespesa = menuRegistrarPagamentoReceitaDespesa;
    }

    public JMenu getMenuSair() {
        return menuSair;
    }

    public void setMenuSair(JMenu menuSair) {
        this.menuSair = menuSair;
    }
    
    public JMenuItem getMenuManterMoradores(){
        return menuManterMoradores;
    }
    
    
    public JLabel getlblstatus(){
        return lblstatus;
    }
    
    
     public JLabel getlblusuario(){
        return lblusuario;
    }
     
       public JMenuItem getjMenuItemLog(){
        return jMenuItemLog;
    }
   
       public JLabel getlbltipolog(){
           return lbltipolog;
       }
     
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu3 = new javax.swing.JMenu();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        jLabel1 = new javax.swing.JLabel();
        lblstatus = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lblusuario = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lblNomeRepublica = new javax.swing.JLabel();
        lblQuantidadeMoradores = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lbltipolog = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        menuManterRepublica = new javax.swing.JMenuItem();
        menuManterMoradores = new javax.swing.JMenuItem();
        menuConfirmarSolucao = new javax.swing.JMenuItem();
        menuConvidarMoradores = new javax.swing.JMenuItem();
        menuCriarRepublica = new javax.swing.JMenuItem();
        menuBuscarVagas = new javax.swing.JMenuItem();
        menuConsultarResultadoMensal = new javax.swing.JMenuItem();
        menuManterReclamacoesSugestoes = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItemCriarPerfil = new javax.swing.JMenuItem();
        menuManterPerfil = new javax.swing.JMenuItem();
        menuAceitarConvite = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        menuManterTarefas = new javax.swing.JMenuItem();
        menuRegistrarConclusaoTarefas = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        menuManterReceitasDespesas = new javax.swing.JMenuItem();
        menuFazerEstorno = new javax.swing.JMenuItem();
        menuConsultarReceitasDespesas = new javax.swing.JMenuItem();
        menuRegistrarPagamentoReceitaDespesa = new javax.swing.JMenuItem();
        menuSair = new javax.swing.JMenu();
        jMenuItemLog = new javax.swing.JMenuItem();

        jMenu3.setText("jMenu3");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Gestão de Republicas");
        setAlwaysOnTop(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 102, 255));
        jLabel1.setText("STATUS:");

        lblstatus.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblstatus.setForeground(new java.awt.Color(51, 102, 255));
        lblstatus.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblstatus.setText("jLabel2");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 102, 255));
        jLabel2.setText("USUÁRIO:");

        lblusuario.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblusuario.setForeground(new java.awt.Color(51, 102, 255));
        lblusuario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblusuario.setText("jLabel2");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 102, 255));
        jLabel3.setText("NOME REPÚBLICA:");

        lblNomeRepublica.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblNomeRepublica.setForeground(new java.awt.Color(51, 102, 255));
        lblNomeRepublica.setText("jlABEL3");

        lblQuantidadeMoradores.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblQuantidadeMoradores.setForeground(new java.awt.Color(51, 102, 255));
        lblQuantidadeMoradores.setText("jlABEL3");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 102, 255));
        jLabel6.setText("QTD MORADORES:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 102, 255));
        jLabel4.setText("LOG:");

        lbltipolog.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbltipolog.setForeground(new java.awt.Color(51, 102, 255));
        lbltipolog.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbltipolog.setText("jLabel2");

        jMenu1.setText("República");
        jMenu1.add(jSeparator1);

        menuManterRepublica.setText("Manter república");
        menuManterRepublica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuManterRepublicaActionPerformed(evt);
            }
        });
        jMenu1.add(menuManterRepublica);

        menuManterMoradores.setText("Manter moradores");
        menuManterMoradores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuManterMoradoresActionPerformed(evt);
            }
        });
        jMenu1.add(menuManterMoradores);

        menuConfirmarSolucao.setText("Confirmar solução de reclamação/sugestões");
        menuConfirmarSolucao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuConfirmarSolucaoActionPerformed(evt);
            }
        });
        jMenu1.add(menuConfirmarSolucao);

        menuConvidarMoradores.setText("Convidar moradores/ aceitar convite");
        menuConvidarMoradores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuConvidarMoradoresActionPerformed(evt);
            }
        });
        jMenu1.add(menuConvidarMoradores);

        menuCriarRepublica.setText("Criar república");
        jMenu1.add(menuCriarRepublica);

        menuBuscarVagas.setText("Buscar Vagas");
        jMenu1.add(menuBuscarVagas);

        menuConsultarResultadoMensal.setText("Consultar resultado mensal");
        menuConsultarResultadoMensal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuConsultarResultadoMensalActionPerformed(evt);
            }
        });
        jMenu1.add(menuConsultarResultadoMensal);

        menuManterReclamacoesSugestoes.setText("Manter reclamações/sugestões");
        jMenu1.add(menuManterReclamacoesSugestoes);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Morador");

        jMenuItemCriarPerfil.setText("Criar Perfil");
        jMenu2.add(jMenuItemCriarPerfil);

        menuManterPerfil.setText("Manter perfil");
        menuManterPerfil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuManterPerfilActionPerformed(evt);
            }
        });
        jMenu2.add(menuManterPerfil);

        menuAceitarConvite.setText("Aceitar convite");
        jMenu2.add(menuAceitarConvite);

        jMenuBar1.add(jMenu2);

        jMenu4.setText("Tarefas");

        menuManterTarefas.setText("Manter tarefas");
        jMenu4.add(menuManterTarefas);

        menuRegistrarConclusaoTarefas.setText("Registrar conclusão de tarefas");
        jMenu4.add(menuRegistrarConclusaoTarefas);

        jMenuBar1.add(jMenu4);

        jMenu5.setText("Lançamentos");

        menuManterReceitasDespesas.setText("Manter receitas e despesas");
        jMenu5.add(menuManterReceitasDespesas);

        menuFazerEstorno.setText("Fazer estorno de lançamentos");
        jMenu5.add(menuFazerEstorno);

        menuConsultarReceitasDespesas.setText("Consultar minhas receitas e despesas");
        jMenu5.add(menuConsultarReceitasDespesas);

        menuRegistrarPagamentoReceitaDespesa.setText("Registrar pagamento de receita ou despesas");
        jMenu5.add(menuRegistrarPagamentoReceitaDespesa);

        jMenuBar1.add(jMenu5);

        menuSair.setText("Configurações");

        jMenuItemLog.setText("Log");
        menuSair.add(jMenuItemLog);

        jMenuBar1.add(menuSair);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel3))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lbltipolog, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 147, Short.MAX_VALUE)
                        .addComponent(jLabel2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(lblusuario, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(44, 44, 44)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(lblstatus, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(lblNomeRepublica, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6)
                        .addGap(41, 41, 41)
                        .addComponent(lblQuantidadeMoradores, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(338, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(lblQuantidadeMoradores)
                    .addComponent(lblNomeRepublica)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(lblusuario)
                        .addComponent(jLabel4)
                        .addComponent(lbltipolog))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblstatus)
                        .addComponent(jLabel1))))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void menuManterRepublicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuManterRepublicaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuManterRepublicaActionPerformed

    private void menuManterMoradoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuManterMoradoresActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuManterMoradoresActionPerformed

    private void menuConfirmarSolucaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuConfirmarSolucaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuConfirmarSolucaoActionPerformed

    private void menuConvidarMoradoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuConvidarMoradoresActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuConvidarMoradoresActionPerformed

    private void menuConsultarResultadoMensalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuConsultarResultadoMensalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuConsultarResultadoMensalActionPerformed

    private void menuManterPerfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuManterPerfilActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuManterPerfilActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
          this.setExtendedState(MAXIMIZED_BOTH);
    }//GEN-LAST:event_formWindowOpened

    /**
     * @param args the command line arguments
     */
 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItemCriarPerfil;
    private javax.swing.JMenuItem jMenuItemLog;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JLabel lblNomeRepublica;
    private javax.swing.JLabel lblQuantidadeMoradores;
    private javax.swing.JLabel lblstatus;
    private javax.swing.JLabel lbltipolog;
    private javax.swing.JLabel lblusuario;
    private javax.swing.JMenuItem menuAceitarConvite;
    private javax.swing.JMenuItem menuBuscarVagas;
    private javax.swing.JMenuItem menuConfirmarSolucao;
    private javax.swing.JMenuItem menuConsultarReceitasDespesas;
    private javax.swing.JMenuItem menuConsultarResultadoMensal;
    private javax.swing.JMenuItem menuConvidarMoradores;
    private javax.swing.JMenuItem menuCriarRepublica;
    private javax.swing.JMenuItem menuFazerEstorno;
    private javax.swing.JMenuItem menuManterMoradores;
    private javax.swing.JMenuItem menuManterPerfil;
    private javax.swing.JMenuItem menuManterReceitasDespesas;
    private javax.swing.JMenuItem menuManterReclamacoesSugestoes;
    private javax.swing.JMenuItem menuManterRepublica;
    private javax.swing.JMenuItem menuManterTarefas;
    private javax.swing.JMenuItem menuRegistrarConclusaoTarefas;
    private javax.swing.JMenuItem menuRegistrarPagamentoReceitaDespesa;
    private javax.swing.JMenu menuSair;
    // End of variables declaration//GEN-END:variables
}
