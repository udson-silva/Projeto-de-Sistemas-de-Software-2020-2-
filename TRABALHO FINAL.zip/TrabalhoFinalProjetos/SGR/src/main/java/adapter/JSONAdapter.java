/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adapter;


import Model.LogModel;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.simple.JSONObject;

/**
 *
 * @author udson
 */
public class JSONAdapter implements IlogAdapter {



    @Override
    public void Escrever(LogModel logmodel) {
        FileWriter writeFile = null;
        JSONObject objetojson = new JSONObject();
       

        objetojson.put("operacao", logmodel.getOperacao());
        objetojson.put("nome", logmodel.getNome());
        objetojson.put("data", logmodel.getData());
        objetojson.put("hora", logmodel.getHora());
        objetojson.put("usuario", logmodel.getUsuario());
        
      //  System.out.println(logmodel.getOperacao());
       // System.out.println(logmodel.getHora());
       
       

        try {
           writeFile = new FileWriter("logjson/"+logmodel.getOperacao()+logmodel.getNome()+".json");
            writeFile.write(objetojson.toJSONString());
            writeFile.close();
        } catch (IOException ex) {
            Logger.getLogger(JSONAdapter.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
