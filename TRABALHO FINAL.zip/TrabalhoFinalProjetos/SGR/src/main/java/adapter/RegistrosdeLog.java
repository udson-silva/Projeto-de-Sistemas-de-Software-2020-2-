/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adapter;

import Dao.ConfiguracoesLogDao;
import Model.LogModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.Timer;

/**
 *
 * @author udson
 */
public class RegistrosdeLog {
    
    public RegistrosdeLog() {
        
    }
    
    public void GravaLog(LogModel logmodel) {
        
        String log;        
        
        log = Pesquisatipolog();
        
          //pega a data do sistema e formata em mes e ano
        Date dataSistema = new Date();
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        String data = formato.format(dataSistema);
        
        logmodel.setData(data);
        
        Timer timer = new Timer(1000, new hora());
        timer.start();
        Calendar now  = Calendar.getInstance();
        logmodel.setHora(String.format("%1$tH:%1$tM:%1$tS", now));
       
     
        
        
        switch (log) {
            case "JSON":
                IlogAdapter json = new JSONAdapter();
                json.Escrever(logmodel);
                
                break;
            case "XML":
                IlogAdapter xml = new XMLAdapter();
                xml.Escrever(logmodel);
                
                break;
            default:
                IlogAdapter csv = new CSVAdapter();
                csv.Escrever(logmodel);
                break;
        }
        
    }
    
    public String Pesquisatipolog() {
        
        String tipo_log = null;
        
        ConfiguracoesLogDao pesquisa = new ConfiguracoesLogDao();
        
        tipo_log = pesquisa.PesquisaLog();
        
        return tipo_log;
        
    }
    
   class hora implements ActionListener {
     @Override
     public void actionPerformed(ActionEvent e){
         Calendar now  = Calendar.getInstance();
        
         
     }
 }  
    
    
    
}
