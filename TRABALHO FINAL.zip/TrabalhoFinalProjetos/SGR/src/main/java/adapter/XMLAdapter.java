/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adapter;

import Model.LogModel;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author udson
 */
public class XMLAdapter implements IlogAdapter {

    @Override
    public void Escrever(LogModel logmodel) {
        try {
            DocumentBuilderFactory documentbuiderfactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentbuilder = documentbuiderfactory.newDocumentBuilder();

            Document documentoXML = documentbuilder.newDocument();

           Element root = documentoXML.createElement(logmodel.getOperacao());
            documentoXML.appendChild(root);

            Element dados = documentoXML.createElement("Dados");
            Attr id = documentoXML.createAttribute("id");

            id.setValue("1");

          dados.setAttributeNode(id);

           root.appendChild(dados);

            Element nome = documentoXML.createElement("nome");

            nome.appendChild(documentoXML.createTextNode(logmodel.getNome()));

            dados.appendChild(nome);
            
            
            Element data = documentoXML.createElement("data");

            data.appendChild(documentoXML.createTextNode(logmodel.getData()));

            dados.appendChild(data);
            
            
            Element hora = documentoXML.createElement("hora");

            hora.appendChild(documentoXML.createTextNode(logmodel.getHora()));

            dados.appendChild(hora);
            
            
             Element usuario = documentoXML.createElement("usuario");

            usuario.appendChild(documentoXML.createTextNode(logmodel.getUsuario()));

            dados.appendChild(usuario);
            
            
            

            TransformerFactory transformerfactory = TransformerFactory.newInstance();
            Transformer transformer = transformerfactory.newTransformer();

            DOMSource documentofonte = new DOMSource(documentoXML);

            StreamResult documentofinal = new StreamResult(new File("logxml/"+logmodel.getOperacao()+logmodel.getNome()+".xml"));

           transformer.transform(documentofonte, documentofinal);

        } catch (ParserConfigurationException ex) {
            Logger.getLogger(XMLAdapter.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerConfigurationException ex) {
            Logger.getLogger(XMLAdapter.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerException ex) {
            Logger.getLogger(XMLAdapter.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
