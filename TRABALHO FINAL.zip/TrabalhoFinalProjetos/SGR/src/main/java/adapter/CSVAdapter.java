/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adapter;

import Model.LogModel;
import com.opencsv.CSVWriter;


import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Pessoal
 */
public class CSVAdapter implements IlogAdapter{

    // private static final String CSV_PATH = "/logCSV/generatedCsv.csv";
    
    
    @Override
    public void Escrever(LogModel logmodel) {
        

      
       
   
         
        try {
           // System.out.println("Iniciando geração do CSV");
             
            try (FileWriter fw = new FileWriter("logCSV/"+logmodel.getOperacao()+logmodel.getNome()+".csv")) {
                CSVWriter cw = new CSVWriter(fw);
                
                String[] headers = {"operacao" , "nome", "data", "hora", "usuario"};
                
                List<String[]> data = new ArrayList<String[]>();
                String[] item1 = {logmodel.getOperacao() , logmodel.getNome() , logmodel.getData(), logmodel.getHora(), logmodel.getUsuario()};
               
                
                data.add(headers);
                data.add(item1);
               
                
                cw.writeAll(data);
                
                cw.close();
            }
             
            System.out.println("Escrita de arquivo finalizado");
             
        }catch (Exception e) {
            e.printStackTrace();
        }       
    
        
        
    }       
    
    
}
