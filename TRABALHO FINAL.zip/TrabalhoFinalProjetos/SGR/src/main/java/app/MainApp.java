/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;
import presenter.LoginPresenter;


/**
 *
 * @author udson
 */
public class MainApp {
    
    public static void main(String[] args) {
        
         
         LoginPresenter login = new LoginPresenter();
         
       //  System.out.println("teste");
      // String nivel_acesso = "SEM TETO";
     //  String usuario = "udson";
      
      //PrincipalPresenter pre = new PrincipalPresenter(nivel_acesso, usuario);
        
    }
}
