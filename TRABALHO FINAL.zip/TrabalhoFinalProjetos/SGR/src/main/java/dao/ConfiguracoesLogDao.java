/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.LogModel;
import dao.ConexaoBanco;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


/**
 *
 * @author udson
 */
public class ConfiguracoesLogDao {
    
    
     public String PesquisaLog() {

        LogModel dadoslog = new LogModel();
        String tipo_log = null;
        Connection c = null;
        Statement stmt = null;
       
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("select *from configuracoes");

            tipo_log = rs.getString("tipo_log");
           // tipo_persistencia = rs.getString("tipo_persistencia");
           
           
          
            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.out.println(e);
            // System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return tipo_log;
    }

    public void AlterarConfiguracao(String tipo_log) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("Update configuracoes set tipo_log = '" + tipo_log + "'");
            sql.executeUpdate();

        } catch (SQLException ex) {
                System.err.println(ex.getClass().getName() + ": " + ex.getMessage());
        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }
    
}
