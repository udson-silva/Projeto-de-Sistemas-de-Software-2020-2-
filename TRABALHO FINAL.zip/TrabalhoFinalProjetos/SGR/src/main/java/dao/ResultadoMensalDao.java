/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author udson
 */
public class ResultadoMensalDao {

    
    float valor_despesa, valor_receita, valor_despesa_paga, saldo_total;
    String mes_ano;

    public ArrayList Preencher_TabelaDespesas(int id_republica, String mes, String ano) throws SQLException {

        String sql = "select sum(valor_dividido) as valor from despesas  where id_republica=" + id_republica + ""
                + " and data_vencimento like'%"+mes+"%' and data_vencimento like '%"+ano+"%'";
        String sql2 = "select sum(valor_dividido) as valor from receitas where id_republica=" + id_republica + " "
                + "and data_vencimento like'%"+mes+"%' and data_vencimento like '%"+ano+"%'";
        String sql3 = "select sum(valor_pago) as valor from despesas where id_republica=" + id_republica + " "
                + "and data_vencimento like'%"+mes+"%' and data_vencimento like '%"+ano+"%'";
        ArrayList dados = new ArrayList(); 
        Connection c = null;
        Statement stmt = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {

                valor_despesa = rs.getFloat("valor");

            }

            ResultSet rs2 = stmt.executeQuery(sql2);

            while (rs2.next()) {

                valor_receita = rs2.getFloat("valor");

            }
            
              ResultSet rs3 = stmt.executeQuery(sql3);

            while (rs3.next()) {

                valor_despesa_paga = rs3.getFloat("valor");

            }
            
            String converte_mes = mes.replace("/", "");
            mes_ano = converte_mes+"/"+ano;
              saldo_total = valor_receita  - valor_despesa_paga ;
            
            dados.add(new Object[]{mes_ano,valor_despesa, valor_despesa_paga, valor_receita,saldo_total});
            rs2.close();
            rs.close();
            rs3.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
             System.err.println(e.getClass().getName() + ": " + e.getMessage());
            stmt.close();
            c.close();
            

        }
        return dados;

    }
    
    
    
    
    
    public ArrayList Preencher_TabelaDespesasTodosMeses(int id_republica, String ano) throws SQLException {

         String sql,sql2,sql3;
        
        
        ArrayList dados = new ArrayList();
        for(int i = 1; i<=12; i++){
            
        int mes = i;
        String mes_convertido = String.valueOf(mes);
           
        if(mes<=10){
        sql = "select sum(valor_dividido) as valor from despesas  where id_republica=" + id_republica + ""
                + " and data_vencimento like'%/0"+mes_convertido+"/%' and data_vencimento like '%"+ano+"%'";
        sql2 = "select sum(valor_dividido) as valor from receitas where id_republica=" + id_republica + " "
                + "and data_vencimento like'%/0"+mes_convertido+"/%' and data_vencimento like '%"+ano+"%'";
        sql3 = "select sum(valor_pago) as valor from despesas where id_republica=" + id_republica + " "
                + "and data_vencimento like'%/0"+mes_convertido+"/%' and data_vencimento like '%"+ano+"%'";
        }else{
             
         sql = "select sum(valor_dividido) as valor from despesas  where id_republica=" + id_republica + ""
                + " and data_vencimento like'%/"+mes_convertido+"/%' and data_vencimento like '%"+ano+"%'";
         sql2 = "select sum(valor_dividido) as valor from receitas where id_republica=" + id_republica + " "
                + "and data_vencimento like'%/"+mes_convertido+"/%' and data_vencimento like '%"+ano+"%'";
         sql3 = "select sum(valor_pago) as valor from despesas where id_republica=" + id_republica + " "
                + "and data_vencimento like'%/"+mes_convertido+"/%' and data_vencimento like '%"+ano+"%'"; 
            
                }
        Connection c = null;
        Statement stmt = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {

                valor_despesa = rs.getFloat("valor");

            }

            ResultSet rs2 = stmt.executeQuery(sql2);

            while (rs2.next()) {

                valor_receita = rs.getFloat("valor");

            }
            
              ResultSet rs3 = stmt.executeQuery(sql3);

            while (rs3.next()) {

                valor_despesa_paga = rs.getFloat("valor");

            }
            
            
            mes_ano = "0"+mes_convertido+"/"+ano;
           saldo_total = valor_receita   - valor_despesa_paga ;
            
            dados.add(new Object[]{mes_ano,valor_despesa, valor_despesa_paga, valor_receita,saldo_total});
            rs2.close();
            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
             System.err.println(e.getClass().getName() + ": " + e.getMessage());
            stmt.close();
            c.close();
           

        }
        }
        return dados;

    } 
    
    
    
}