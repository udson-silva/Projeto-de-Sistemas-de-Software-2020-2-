/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.RepublicaModel;
import model.UsuarioModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author udson
 */
public class RepublicaDao {

    public void inserirRepublica(RepublicaModel republicamodel) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("insert into republicas(nome_republica, data_criacao, despesa_media_morador,"
                    + "total_vagas,vagas_disponiveis,vagas_ocupadas,vantagens,codigo_etica,logradouro,bairro,ponto_referencia,"
                    + "localizacao_geografica,cep,criador_republica) values ('" + republicamodel.getNomeRepublica() + "','" + republicamodel.getDataFundacao() + "','"
                    + republicamodel.getDespesaMedia() + "','" + republicamodel.getTotalVagas() + "','" + republicamodel.getVagasDisponiveis()
                    + "','" + republicamodel.getVagasOcupadas() + "','" + republicamodel.getVantagens() + "','" + republicamodel.getCodigoEtica()
                    + "','" + republicamodel.getLogradouro() + "','" + republicamodel.getBairro() + "','" + republicamodel.getReferencia()
                    + "','" + republicamodel.getLocalizacaoGeografica() + "','" + republicamodel.getCEP() + "','" + republicamodel.getId_usuario() + "')");
            sql.executeUpdate();

        } catch (SQLException ex) {
            System.err.println(ex.getClass().getName() + ": " + ex.getMessage());
        } finally {
            ConexaoBanco.closeConnection(conexao);

        }

    }

    public boolean PesquisaUsuario(int id_usuario) throws SQLException {

        boolean retorno;
        int id;
        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("select *from republicas where criador_republica=" + id_usuario + "");

            //System.out.println("teste");
            id = rs.getInt("criador_republica");

            //se existe republica retorna true
            retorno = true;

            rs.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            retorno = false;

        }

        stmt.close();
        c.close();
        //se nao retorna false
        return retorno;
    }

    public RepublicaModel PesquisaDadosRepublica(RepublicaModel republicamodel) throws SQLException {

        float despesa_media_morador;
        int id_usuario, id_republica, vagas_disponiveis, vagas_ocupadas = 0, total_vagas;
        String cep, localizacao_geografica, ponto_referencia, bairro, logradouro, codigo_etica, vantagens, data_criacao, nome_republica = "NENHUM";

        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("select *from republicas where criador_republica=" + republicamodel.getId_usuario() + "");

            id_usuario = rs.getInt("criador_republica");
            despesa_media_morador = rs.getFloat("despesa_media_morador");
            id_republica = rs.getInt("id_republica");
            vagas_disponiveis = rs.getInt("vagas_disponiveis");
            vagas_ocupadas = rs.getInt("vagas_ocupadas");
            total_vagas = rs.getInt("total_vagas");
            cep = rs.getString("cep");
            localizacao_geografica = rs.getString("localizacao_geografica");
            ponto_referencia = rs.getString("ponto_referencia");
            bairro = rs.getString("bairro");
            logradouro = rs.getString("logradouro");
            codigo_etica = rs.getString("codigo_etica");
            vantagens = rs.getString("vantagens");
            data_criacao = rs.getString("data_criacao");
            nome_republica = rs.getString("nome_republica");

            republicamodel.setId_usuario(id_usuario);
            republicamodel.setDespesaMedia(despesa_media_morador);
            republicamodel.setId_republica(id_republica);
            republicamodel.setVagasDisponiveis(vagas_disponiveis);
            republicamodel.setVagasOcupadas(vagas_ocupadas);
            republicamodel.setTotalVagas(total_vagas);
            republicamodel.setCEP(cep);
            republicamodel.setLocalizacaoGeografica(localizacao_geografica);
            republicamodel.setReferencia(ponto_referencia);
            republicamodel.setBairro(bairro);
            republicamodel.setLogradouro(logradouro);
            republicamodel.setCodigoEtica(codigo_etica);
            republicamodel.setVantagens(vantagens);
            republicamodel.setDataFundacao(data_criacao);
            republicamodel.setNomeRepublica(nome_republica);

            rs.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());

        }

        stmt.close();
        c.close();
        return republicamodel;
    }

    public RepublicaModel PesquisaDadosRepublicaPorNome(RepublicaModel republicamodel) throws SQLException {

        float despesa_media_morador;
        int id_usuario, id_republica, vagas_disponiveis, vagas_ocupadas = 0, total_vagas;
        String cep, localizacao_geografica, ponto_referencia, bairro, logradouro, codigo_etica, vantagens, data_criacao, nome_republica = "NENHUM";

        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("select *from republicas where nome_republica='" + republicamodel.getNomeRepublica() + "'");

            id_usuario = rs.getInt("criador_republica");
            despesa_media_morador = rs.getFloat("despesa_media_morador");
            id_republica = rs.getInt("id_republica");
            vagas_disponiveis = rs.getInt("vagas_disponiveis");
            vagas_ocupadas = rs.getInt("vagas_ocupadas");
            total_vagas = rs.getInt("total_vagas");
            cep = rs.getString("cep");
            localizacao_geografica = rs.getString("localizacao_geografica");
            ponto_referencia = rs.getString("ponto_referencia");
            bairro = rs.getString("bairro");
            logradouro = rs.getString("logradouro");
            codigo_etica = rs.getString("codigo_etica");
            vantagens = rs.getString("vantagens");
            data_criacao = rs.getString("data_criacao");
            nome_republica = rs.getString("nome_republica");

            republicamodel.setId_usuario(id_usuario);
            republicamodel.setDespesaMedia(despesa_media_morador);
            republicamodel.setId_republica(id_republica);
            republicamodel.setVagasDisponiveis(vagas_disponiveis);
            republicamodel.setVagasOcupadas(vagas_ocupadas);
            republicamodel.setTotalVagas(total_vagas);
            republicamodel.setCEP(cep);
            republicamodel.setLocalizacaoGeografica(localizacao_geografica);
            republicamodel.setReferencia(ponto_referencia);
            republicamodel.setBairro(bairro);
            republicamodel.setLogradouro(logradouro);
            republicamodel.setCodigoEtica(codigo_etica);
            republicamodel.setVantagens(vantagens);
            republicamodel.setDataFundacao(data_criacao);
            republicamodel.setNomeRepublica(nome_republica);

            rs.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());

        }
        stmt.close();
        c.close();
        //se nao retorna false
        return republicamodel;
    }

    public void AlterarRepublica(RepublicaModel mod) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("Update republicas set nome_republica = '" + mod.getNomeRepublica() + "',data_criacao='" + mod.getDataFundacao() + "',"
                    + "despesa_media_morador =" + mod.getDespesaMedia() + ",total_vagas=" + mod.getTotalVagas() + ",vagas_disponiveis=" + mod.getVagasDisponiveis() + ","
                    + "vagas_ocupadas=" + mod.getVagasOcupadas() + ",vantagens='" + mod.getVantagens() + "',codigo_etica='" + mod.getCodigoEtica() + "',"
                    + "logradouro='" + mod.getLogradouro() + "',bairro='" + mod.getBairro() + "',ponto_referencia='" + mod.getReferencia() + "',"
                    + "localizacao_geografica='" + mod.getLocalizacaoGeografica() + "',cep='" + mod.getCEP() + "'  where id_republica =" + mod.getId_republica() + "");
            sql.executeUpdate();

        } catch (SQLException ex) {
            System.err.println(ex.getClass().getName() + ": " + ex.getMessage());
        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }

    public void DeletarRepublica(int id_republica) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("Delete from republicas where id_republica = '" + id_republica + "'");
            sql.executeUpdate();

        } catch (SQLException ex) {
             System.err.println(ex.getClass().getName() + ": " + ex.getMessage());
        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }

    //aqui pega os dados de republica e nome de morador 
    public RepublicaModel PesquisaRepublicaPosCriacao(RepublicaModel mod) throws SQLException {

        int id_republica = 0;
        String nome_morador;

        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("select *from republicas inner join perfil_morador on "
                    + "republicas.criador_republica = perfil_morador.id_usuario where perfil_morador.id_usuario=" + mod.getId_usuario() + "");

            id_republica = rs.getInt("id_republica");

            nome_morador = rs.getString("nome");
            mod.setId_republica(id_republica);
            mod.setNome_morador(nome_morador);

            rs.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());

        }
        //se nao retorna false
        stmt.close();
        c.close();
        return mod;
    }

    public RepublicaModel PesquisaVagasRepublica(RepublicaModel republicamodel) throws SQLException {

        float despesa_media_morador;
        int vagas_disponiveis, vagas_ocupadas, total_vagas, id_republica;
         
        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("select *from republicas where nome_republica='" + republicamodel.getNomeRepublica() + "'");

            despesa_media_morador = rs.getFloat("despesa_media_morador");

            vagas_disponiveis = rs.getInt("vagas_disponiveis");
            vagas_ocupadas = rs.getInt("vagas_ocupadas");
            total_vagas = rs.getInt("total_vagas");
            id_republica = rs.getInt("id_republica");
            republicamodel.setDespesaMedia(despesa_media_morador);
            republicamodel.setId_republica(id_republica);
            republicamodel.setVagasDisponiveis(vagas_disponiveis);
            republicamodel.setVagasOcupadas(vagas_ocupadas);
            republicamodel.setTotalVagas(total_vagas);

            rs.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());

        }

        stmt.close();
        c.close();
        return republicamodel;
    }

    public void AlterarVagasRepublica(RepublicaModel republicaModel) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("Update republicas set vagas_disponiveis=" + republicaModel.getVagasDisponiveis() + ","
                    + "vagas_ocupadas=" + republicaModel.getVagasOcupadas() + "  where id_republica =" + republicaModel.getId_republica() + "");
            sql.executeUpdate();

        } catch (SQLException ex) {
           System.err.println(ex.getClass().getName() + ": " + ex.getMessage());
        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }
    
    
     public RepublicaModel PesquisaNomeVagasRepublica(RepublicaModel republicamodel) throws SQLException {

        
        int  vagas_ocupadas = 0, id_republica;
        String  nome_republica = "NENHUM";

        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("select *from republicas inner join "
                    + "moradores_republicas on republicas.id_republica = moradores_republicas.id_republica  where moradores_republicas.id_morador="+ republicamodel.getId_usuario()+"");
            
            vagas_ocupadas = rs.getInt("vagas_ocupadas");
           
            nome_republica = rs.getString("nome_republica");
             
            id_republica = rs.getInt("id_republica");
            
            republicamodel.setId_republica(id_republica);
           
            republicamodel.setVagasOcupadas(vagas_ocupadas);
            
            republicamodel.setNomeRepublica(nome_republica);

            rs.close();

        } catch (Exception e) {
           System.err.println(e.getClass().getName() + ": " + e.getMessage());

        }

        stmt.close();
        c.close();
        return republicamodel;
    }
    
    

}
