/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author udson
 */
public class TabelaMoradorRepublica {

    public ArrayList Preencher_Tabela(int id_republica) throws SQLException {

        String sql = "select *from moradores_republicas inner join perfil_morador "
                + "on moradores_republicas.id_morador = perfil_morador.id_usuario where id_republica=" + id_republica + "";

        Connection c = null;
        Statement stmt = null;
        ArrayList dados = new ArrayList();
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {

                int id = rs.getInt("id_morador");
                String nome = rs.getString("nome");

                dados.add(nome);
            }

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            stmt.close();
            c.close();

        }
        return dados;

    }

    public int PesquisaMoradores(String nome_morador) throws SQLException {
        int id = 0;
        String sql = "select *from moradores_republicas inner join perfil_morador "
                + "on moradores_republicas.id_morador = perfil_morador.id_usuario where nome='" + nome_morador + "'";

        Connection c = null;
        Statement stmt = null;
        ArrayList dados = new ArrayList();
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {

                id = rs.getInt("id_morador");

            }

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            stmt.close();
            c.close();

        }
        return id;

    }

}
