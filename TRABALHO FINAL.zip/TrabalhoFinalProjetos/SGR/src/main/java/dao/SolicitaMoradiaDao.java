/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.RepublicaModel;
import model.SolicitaMoradiaModel;
import model.UsuarioModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author udson
 */
public class SolicitaMoradiaDao {

    public void SolicitarMoradia(SolicitaMoradiaModel solicitamoradia) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("insert into solicitacao_moradia(nome_solicitante, republica_atual, status,perfil_rede_social,id_perfil_usuario,republica_solicitada) values "
                    + "('" + solicitamoradia.getNome_solicitante() + "','" + solicitamoradia.getRepublica_atual() + "','" + solicitamoradia.getStatus() + "','" + solicitamoradia.getPerfilredesocial() + "','"
                    + solicitamoradia.getId_perfil_usuario() + "','" + solicitamoradia.getRepublica_solicitada() + "')");
            sql.executeUpdate();

        } catch (SQLException ex) {
             System.err.println(ex.getClass().getName() + ": " + ex.getMessage());
        } finally {
            ConexaoBanco.closeConnection(conexao);

        }

    }

    public void AlterarStatusUsuario(UsuarioModel usuariomodel) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("Update usuarios set status = '" + usuariomodel.getStatus() + "' where nome_usuario ='" + usuariomodel.getNome_usuario() + "'");
            sql.executeUpdate();

        } catch (SQLException ex) {
            System.err.println(ex.getClass().getName() + ": " + ex.getMessage());
        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }

    public void AlterarNumeroMoradoresRepublica(RepublicaModel republicamodel) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("update republicas set total_vagas=" + republicamodel.getTotalVagas() + ",vagas_disponiveis=" + republicamodel.getVagasDisponiveis() + ","
                    + "vagas_ocupadas=" + republicamodel.getVagasOcupadas() + "'  where id_republica =" + republicamodel.getId_republica() + "");
            sql.executeUpdate();

        } catch (SQLException ex) {
            System.err.println(ex.getClass().getName() + ": " + ex.getMessage());
        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }

    public RepublicaModel PesquisaDadosRepublicaPorNome(RepublicaModel republicamodel) throws SQLException {

        int vagas_disponiveis, vagas_ocupadas, total_vagas;

        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("select *from republicas where nome_republica='" + republicamodel.getNomeRepublica() + "'");

            vagas_disponiveis = rs.getInt("vagas_disponiveis");
            vagas_ocupadas = rs.getInt("vagas_ocupadas");
            total_vagas = rs.getInt("total_vagas");

            republicamodel.setVagasDisponiveis(vagas_disponiveis);
            republicamodel.setVagasOcupadas(vagas_ocupadas);
            republicamodel.setTotalVagas(total_vagas);

            rs.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());

        }
        stmt.close();
        c.close();
        return republicamodel;
    }

    public void AlterarStatusSolicitacao(String status, int id_solicitacao, String republica) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("Update solicitacao_moradia set status = '" + status + "', republica_atual = '" + republica + "' where id_solicitacao =" + id_solicitacao + "");
            sql.executeUpdate();

        } catch (SQLException ex) {
            System.err.println(ex.getClass().getName() + ": " + ex.getMessage());
        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }

}
