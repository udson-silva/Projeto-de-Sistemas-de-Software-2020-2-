/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;


/**
 *
 * @author Pessoal
 */
public class TabelaBuscarVagas {

    public ArrayList Preencher_Tabela(String sql) {

        ArrayList dados = new ArrayList();

        Connection c = null;
        Statement stmt = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

           
            while (rs.next()) {

                String nome = rs.getString("nome_republica");
                float despesas_media = rs.getFloat("despesa_media_morador");
                int vagas_disponiveis = rs.getInt("vagas_disponiveis");
                int total_vagas = rs.getInt("total_vagas");

                dados.add(new Object[]{nome, despesas_media, vagas_disponiveis, total_vagas});
            }

            rs.close();
            stmt.close();
             c.close();
          } catch (Exception e) {
             System.err.println(e.getClass().getName() + ": " + e.getMessage());
           
        }
        
        return dados;

    }

}
