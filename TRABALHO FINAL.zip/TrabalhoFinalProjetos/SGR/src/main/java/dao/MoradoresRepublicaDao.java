/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;
import model.MoradorRepublicaModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author udson
 */
public class MoradoresRepublicaDao {
    
    
     public void inserirMoradoresRepublica(MoradorRepublicaModel moradorrepublica) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {
           
            sql = conexao.prepareStatement("insert into moradores_republicas (id_morador, id_republica,data_ingresso,rateio) values ('" + moradorrepublica.getId_morador() + "','" + moradorrepublica.getId_republica() +  "','" + moradorrepublica.getData_ingresso() + "','" + moradorrepublica.getRateio() + "')");

            sql.executeUpdate();

        } catch (SQLException ex) {
           System.err.println(ex.getClass().getName() + ": " + ex.getMessage());
        } finally {
            ConexaoBanco.closeConnection(conexao);

        }

    
     }
     
     
    public void AlterarDadosMoradores(MoradorRepublicaModel mod) {

        Connection conexao = ConexaoBanco.openConnection();
        
        

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("update moradores_republicas set data_ingresso = '" + mod.getData_ingresso() + "', rateio="+mod.getRateio()+" where nome_morador ='"+ mod.getNome_morador() + "'");
            sql.executeUpdate();
           
        } catch (SQLException ex) {
            System.out.println(""+ex);
            //JOptionPane.showMessageDialog(null, "erro ao alterar os dados ! \n ERRO" + ex);
        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }  
     
    
    
   
     
     
    
    
}
