/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.DespesaReceitaModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author udson
 */
public class ReceitasDao {
    
    
    public void inserirReceitasDao(DespesaReceitaModel despesareceitamodel) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("insert into receitas(id_usuario, periodicidade, descricao,data_vencimento,valor,valor_dividido,"
                    + "valor_recebido,status,data_cadastro,id_republica) values ('" + despesareceitamodel.getId_usuario() + "','" + despesareceitamodel.getPeriodicidade() +
                    "','" + despesareceitamodel.getDescricao() + "','" + despesareceitamodel.getData_vencimento() + "','" + despesareceitamodel.getValor() + 
                    "','" + despesareceitamodel.getValor_dividido() + "','" + despesareceitamodel.getValor_pago() + "','" + despesareceitamodel.getStatus() +
                    "','" + despesareceitamodel.getData_cadastro() +  "','" + despesareceitamodel.getId_republica() + "')");
            sql.executeUpdate();

        } catch (SQLException ex) {
            System.out.println(ex);
            // JOptionPane.showMessageDialog(null, "erro ao inserir os dados ! \n ERRO" + ex);
        } finally {
            ConexaoBanco.closeConnection(conexao);

        }

    }
    
    
    public void RealizarRecebimentoReceitas(DespesaReceitaModel despesareceitamodel) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("Update receitas set status = '" +  despesareceitamodel.getStatus() + "',valor_recebido ="+despesareceitamodel.getValor_pago()+" where id_receitas =" + despesareceitamodel.getId_receitas() + "");
            sql.executeUpdate();

        } catch (SQLException ex) {
             System.err.println(ex.getClass().getName() + ": " + ex.getMessage());
            //System.out.println(ex);
                    
            //JOptionPane.showMessageDialog(null, "erro ao alterar os dados ! \n ERRO" + ex);
        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }
    
    
    
    
    
}
