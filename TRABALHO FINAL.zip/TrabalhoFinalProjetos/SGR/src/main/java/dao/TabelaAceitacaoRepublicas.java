/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Pessoal
 */
public class TabelaAceitacaoRepublicas {

    public ArrayList Preencher_TabelaConvite(String sql) throws SQLException {

        ArrayList dados = new ArrayList();
        Connection c = null;
        Statement stmt = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {

                int id_republica = rs.getInt("id_republica");
                String nome_republica = rs.getString("nome_republica");
                String data_criacao = rs.getString("data_criacao");
                String endereco = rs.getString("logradouro");
                int vagas_disponiveis = rs.getInt("vagas_disponiveis");
                float despesas_media = rs.getFloat("despesa_media_morador");

                dados.add(new Object[]{id_republica, nome_republica, data_criacao, endereco, vagas_disponiveis, despesas_media});
            }

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            stmt.close();
            c.close();

        }
        return dados;

    }

}
