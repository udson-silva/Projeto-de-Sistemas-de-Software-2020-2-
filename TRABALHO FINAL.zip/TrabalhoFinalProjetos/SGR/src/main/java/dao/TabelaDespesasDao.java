/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author udson
 */
public class TabelaDespesasDao {
    
    
    
    
     public ArrayList Preencher_TabelaDespesasPessoa(String pesquisa) throws SQLException {

         
       String  sql = "select *from despesas inner join perfil_morador on despesas.id_usuario = perfil_morador.id_usuario where nome='"+pesquisa+"'";
         
        ArrayList dados = new ArrayList();
        Connection c = null;
        Statement stmt = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {


                int id_despesas = rs.getInt("id_despesas");
                String descricao = rs.getString("descricao");
                String data_vencimento = rs.getString("data_vencimento");
                float valor = rs.getFloat("valor");
                String periodicidade = rs.getString("periodicidade");
                String nome = rs.getString("nome");
                float valor_dividido = rs.getFloat("valor_dividido");
                float valor_pago = rs.getFloat("valor_pago");
                String status = rs.getString("status");
              

                dados.add(new Object[]{id_despesas,descricao,data_vencimento,valor,periodicidade,nome,valor_dividido,valor_pago,status});
            }

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
             System.err.println(e.getClass().getName() + ": " + e.getMessage());
            stmt.close();
            c.close();
            
           
        }
        return dados;

    }
     
     
      public ArrayList Preencher_TabelaDespesas(int id_usuario) throws SQLException {

         
       String  sql = "select *from despesas  where id_usuario="+id_usuario+"";
         
        ArrayList dados = new ArrayList();
        Connection c = null;
        Statement stmt = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {


                int id_despesas = rs.getInt("id_despesas");
                String descricao = rs.getString("descricao");
                String data_vencimento = rs.getString("data_vencimento");
               
                float valor_dividido = rs.getFloat("valor_dividido");
                float valor_pago = rs.getFloat("valor_pago");
                
                String status = rs.getString("status");
              

                dados.add(new Object[]{id_despesas,descricao,data_vencimento,valor_dividido,valor_pago,status});
            }

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            stmt.close();
            c.close();
            System.out.println(e);
           
        }
        return dados;

    }
    
     
     
    
    
     public ArrayList Preencher_TabelaDespesasData(String pesquisa) throws SQLException {

         
       String  sql = "select *from despesas inner join perfil_morador on despesas.id_usuario = perfil_morador.id_usuario where data_vencimento='"+pesquisa+"'";
         
        ArrayList dados = new ArrayList();
        Connection c = null;
        Statement stmt = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {


                int id_despesas = rs.getInt("id_despesas");
                String descricao = rs.getString("descricao");
                String data_vencimento = rs.getString("data_vencimento");
                float valor = rs.getFloat("valor");
                String periodicidade = rs.getString("periodicidade");
                String nome = rs.getString("nome");
                float valor_dividido = rs.getFloat("valor_dividido");
                float valor_pago = rs.getFloat("valor_pago");
                String status = rs.getString("status");
              

                dados.add(new Object[]{id_despesas,descricao,data_vencimento,valor,periodicidade,nome,valor_dividido,valor_pago,status});
            }

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            stmt.close();
            c.close();
            System.out.println(e);
           
        }
        return dados;

    }
      
     
     
    
    
}
