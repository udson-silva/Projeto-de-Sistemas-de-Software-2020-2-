/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.ConviteMoradorModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author udson
 */
public class ConviteMoradorDao {
    
    
    public void FazerConviteMorador(ConviteMoradorModel convitemorador) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("insert into convite_morador(id_convidador, id_republica, status,data_convite,id_usuario_convidado) values "
                    + "('" + convitemorador.getId_convidador() + "','" +convitemorador.getId_republica() +  "','" + convitemorador.getStatus() + "','"
                    +convitemorador.getData_convite()+"','"+convitemorador.getId_usuario_convidado()+"')");
            sql.executeUpdate();
           
        } catch (SQLException ex) {
             System.err.println(ex.getClass().getName() + ": " + ex.getMessage());
        } finally {
            ConexaoBanco.closeConnection(conexao);

        }

    }
    
    
    
    
    
}
