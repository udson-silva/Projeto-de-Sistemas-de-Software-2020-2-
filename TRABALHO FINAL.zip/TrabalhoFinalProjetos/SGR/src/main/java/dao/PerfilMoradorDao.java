/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.UsuarioModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author udson
 */
public class PerfilMoradorDao {

    public void inserirUsuario(UsuarioModel usuariomodel) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("insert into perfil_morador (nome,apelido, telefone, link_rede,telefone_resp1,telefone_resp2,tipo_perfil,id_usuario) values"
                    + " ('" + usuariomodel.getNome_usuario() + "','" + usuariomodel.getApelido() + "','" + usuariomodel.getTelefone() + "','" + usuariomodel.getLink_rede() + "','"
                    + usuariomodel.getTelefone_resp1() + "','" + usuariomodel.getTelefone_resp2() + "','" + usuariomodel.getTipo_perfil() + "'," + usuariomodel.getId_usuario() + ")");

            sql.executeUpdate();

        } catch (SQLException ex) {
            System.out.println(ex);
            // JOptionPane.showMessageDialog(null, "erro ao inserir os dados ! \n ERRO" + ex);
        } finally {
            ConexaoBanco.closeConnection(conexao);

        }

    }
    
    public void AlterarPerfil(UsuarioModel usuariomodel) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("Update perfil_morador set nome = '" + usuariomodel.getNome_usuario() + "',apelido='" + usuariomodel.getApelido() + "',"
                    + "telefone ='" + usuariomodel.getTelefone() + "',link_rede='" + usuariomodel.getLink_rede() + "',telefone_resp1='" + usuariomodel.getTelefone_resp1() + "',"
                    + "telefone_resp2='" + usuariomodel.getTelefone_resp2() + "',tipo_perfil='" + usuariomodel.getTipo_perfil() + "'  where id_usuario =" + usuariomodel.getId_usuario() + "");
            sql.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Erro" + ex);
            //JOptionPane.showMessageDialog(null, "erro ao alterar os dados ! \n ERRO" + ex);
        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }
    
    
    public void DeletarPerfil(int  id_perfil) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("Delete from perfil_morador where id_usuario = '" +id_perfil+ "'");
            sql.executeUpdate();
            
        } catch (SQLException ex) {
            //JOptionPane.showMessageDialog(null, "erro ao Excluir dado ! \n ERRO" + ex);
        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }

    
    
    
    
    

    public boolean PesquisaUsuario(int id_usuario) throws SQLException {

        boolean retorno;
        int id;
        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("select *from perfil_morador where id_usuario=" + id_usuario + "");

            //System.out.println("teste");
            id = rs.getInt("id_usuario");

            //se existe republica retorna true
            retorno = true;

           rs.close();
            
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            retorno = false;
           

        }
         
         stmt.close();
            c.close();
        //se nao retorna false
        return retorno;
    }
    
     public UsuarioModel PesquisaPerfilUsuario(UsuarioModel usuariomodel) throws SQLException {

   
        int id_perfil;
        String nome_usuario, perfil_redesocial;
        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("select *from perfil_morador where id_usuario=" +usuariomodel.getId_usuario()+ "");

            //System.out.println("teste");
            id_perfil = rs.getInt("id");
            nome_usuario =  rs.getString("nome");
            perfil_redesocial = rs.getString("link_rede");
            
            usuariomodel.setId_usuario(id_perfil);
            usuariomodel.setNome_usuario(nome_usuario);
            usuariomodel.setLink_rede(perfil_redesocial);
           

            rs.close();
            
        } catch (Exception e) {
            //System.err.println(e.getClass().getName() + ": " + e.getMessage());
           
           

        }
         stmt.close();
            c.close();
        //se nao retorna false
        return usuariomodel;
    }

    
    
    

    public UsuarioModel PesquisaDadosMorador(UsuarioModel mod) throws SQLException {

        String nome_usuario, apelido, telefone, link_rede, telefone_resp1, telefone_resp2, tipo_perfil;

        
        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("select *from perfil_morador where id_usuario=" + mod.getId_usuario() + "");

            nome_usuario = rs.getString("nome");
            apelido = rs.getString("apelido");
            telefone = rs.getString("telefone");
            link_rede = rs.getString("link_rede");
            telefone_resp1 = rs.getString("telefone_resp1");
            telefone_resp2 = rs.getString("telefone_resp2");
            tipo_perfil = rs.getString("tipo_perfil");

            mod.setNome_usuario(nome_usuario);
            mod.setApelido(apelido);
            mod.setTelefone(telefone);
            mod.setLink_rede(link_rede);
            mod.setTelefone_resp1(telefone_resp1);
            mod.setTelefone_resp2(telefone_resp2);
            mod.setTipo_perfil(tipo_perfil);
           

            rs.close();
            
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());

            

        }
            stmt.close();
            c.close();
        return mod;
    }

}
