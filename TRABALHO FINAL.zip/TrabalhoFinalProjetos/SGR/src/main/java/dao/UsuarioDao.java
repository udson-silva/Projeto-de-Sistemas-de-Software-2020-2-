/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.UsuarioModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author udson
 */
public class UsuarioDao {

    public void inserirUsuario(UsuarioModel usuariomodel) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("insert into usuarios(nome_usuario, senha, status) values ('" + usuariomodel.getNome_usuario() + "','" + usuariomodel.getSenha() + "','" + usuariomodel.getStatus() + "')");
            sql.executeUpdate();

        } catch (SQLException ex) {
            System.err.println(ex.getClass().getName() + ": " + ex.getMessage());
        } finally {
            ConexaoBanco.closeConnection(conexao);

        }

    }

    public UsuarioModel PesquisaUsuario(UsuarioModel usuariomodel) throws SQLException {

        String senha = null;
        String status = null;
        int id_usuario = 0;
        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SGRBD.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("select *from usuarios where nome_usuario='" + usuariomodel.getNome_usuario() + "'");

            senha = rs.getString("senha");
            status = rs.getString("status");
            id_usuario = rs.getInt("id_usuario");
            usuariomodel.setSenha(senha);
            usuariomodel.setStatus(status);
            usuariomodel.setId_usuario(id_usuario);

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            stmt.close();
            c.close();

        }

        return usuariomodel;
    }

    public void AlterarStatusUsuario(UsuarioModel usuariomodel) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("Update usuarios set status = '" + usuariomodel.getStatus() + "' where id_usuario =" + usuariomodel.getId_usuario() + "");
            sql.executeUpdate();

        } catch (SQLException ex) {
            System.err.println(ex.getClass().getName() + ": " + ex.getMessage());

        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }

}
