/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.DespesaReceitaModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author udson
 */
public class DespesasDao {

    public void inserirDespesas(DespesaReceitaModel despesareceitamodel) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("insert into despesas(id_usuario, periodicidade, descricao,data_vencimento,valor,valor_dividido,"
                    + "valor_pago,status,data_cadastro,id_republica) values ('" + despesareceitamodel.getId_usuario() + "','" + despesareceitamodel.getPeriodicidade() +
                    "','" + despesareceitamodel.getDescricao() + "','" + despesareceitamodel.getData_vencimento() + "','" + despesareceitamodel.getValor() + 
                    "','" + despesareceitamodel.getValor_dividido() + "','" + despesareceitamodel.getValor_pago() + "','" + despesareceitamodel.getStatus() +
                    "','" + despesareceitamodel.getData_cadastro() + "','" + despesareceitamodel.getId_republica() + "')");
            sql.executeUpdate();

        } catch (SQLException ex) {
             System.out.println(ex);
        } finally {
            ConexaoBanco.closeConnection(conexao);

        }

    }
    
    public void RealizarPagamentoDespesa(DespesaReceitaModel despesareceitamodel) {

        Connection conexao = ConexaoBanco.openConnection();

        PreparedStatement sql;

        try {

            sql = conexao.prepareStatement("Update despesas set status = '" +  despesareceitamodel.getStatus() + "',valor_pago ="+despesareceitamodel.getValor_pago()+" where id_despesas =" + despesareceitamodel.getId_despesas() + "");
            sql.executeUpdate();

        } catch (SQLException ex) {
            System.err.println(ex.getClass().getName() + ": " + ex.getMessage());
        } finally {
            ConexaoBanco.closeConnection(conexao);
        }

    }
    
    
    
}
