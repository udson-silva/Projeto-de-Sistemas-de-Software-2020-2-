/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package state;

/**
 *
 * @author udson
 */
public class UsuarioNovoState implements IUsuarioState{
    
    public UsuarioNovoState(){
        
    }

    @Override
    public String AlterarEstado(String estado) {
        if(estado.equals("SEM TETO")){
            estado = "REPRESENTANTE DA REPÚBLICA";
        }else if(estado.equals("REPRESENTANTE DA REPÚBLICA")){
            estado = "SEM TETO";
        }
        
      
        return estado;
    }
    
}
