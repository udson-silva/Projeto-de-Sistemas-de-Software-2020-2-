/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package state;

/**
 *
 * @author Pessoal
 */
public class UsuarioState implements IUsuarioState{

    @Override
    public String AlterarEstado(String estado) {
      if(estado.equals("SEM TETO")){
            estado = "MORADOR DA REPÚBLICA";
        }else if(estado.equals("MORADOR DA REPÚBLICA")){
            estado = "SEM TETO";
        }
        return estado;
    }
    
}
