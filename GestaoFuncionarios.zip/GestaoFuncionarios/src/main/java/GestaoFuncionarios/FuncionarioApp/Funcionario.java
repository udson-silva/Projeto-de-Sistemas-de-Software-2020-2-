/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestaoFuncionarios.FuncionarioApp;

import GestaoFuncionarios.DiretorFinanceiro;
import GestaoFuncionarios.DiretorGeral;
import GestaoFuncionarios.GerenteGeral;
import GestaoFuncionarios.GerenteImediato;
import GestaoFuncionarios.IAprovaPagamento;
import java.util.Scanner;

/**
 *
 * @author udson
 */
public class Funcionario {

    

    public static void main(String[] args) {
        
        String disponivel;
        Scanner in = new Scanner(System.in);

        //primeiro ele verifica quem está disponivel dos gerentes 
        IAprovaPagamento gerenteimediato = new GerenteImediato();
        disponivel = gerenteimediato.Disponivel();
        String gerenteimediatodisponivel = disponivel;
        System.out.println("O Gerente Imediato Está diponivel?" + gerenteimediatodisponivel);

        IAprovaPagamento gerentegeral = new GerenteGeral();
        disponivel = gerentegeral.Disponivel();
        String gerentegeraldisponivel = disponivel;
        System.out.println("O Gerente Geral Está diponivel?" + gerentegeraldisponivel);

        IAprovaPagamento diretorfinanceiro = new DiretorFinanceiro();
        disponivel = diretorfinanceiro.Disponivel();
        String diretorfinanceirodisponivel = disponivel;
        System.out.println("O Diretor Financeiro Está diponivel?" + diretorfinanceirodisponivel);

        IAprovaPagamento diretorgeral = new DiretorGeral();
        disponivel = diretorgeral.Disponivel();
        String diretorgeraldisponivel = disponivel;
        System.out.println("O Diretor Geral Está diponivel?" + diretorgeraldisponivel);

        System.out.println("Informe o Valor da Compra.");

        String valor = in.nextLine();

        float valor_compra = Float.parseFloat(valor);

        //verifica o valor da compra digitado pelo funcionario
        if (valor_compra <= 500) {

            if (gerenteimediatodisponivel.equals("SIM")) {
                String aprovacao = gerenteimediato.AprovaPagamento(valor_compra);
                System.out.println("Compra Aprovada Por Gerente Imediato? " + aprovacao);
            } else if (gerentegeraldisponivel.equals("SIM")) {
                String aprovacao = gerentegeral.AprovaPagamento(valor_compra);
                System.out.println("Compra Aprovada Por Gerente Geral? " + aprovacao);
            } else if (diretorfinanceirodisponivel.equals("SIM")) {
                String aprovacao = diretorfinanceiro.AprovaPagamento(valor_compra);
                System.out.println("Compra Aprovada Por Diretor Financeiro? " + aprovacao);
            } else if (diretorgeraldisponivel.equals("SIM")) {
                String aprovacao = diretorgeral.AprovaPagamento(valor_compra);
                System.out.println("Compra Aprovada Por Diretor Geral? " + aprovacao);
            } else {
                System.out.println("NINGUÉM DISPONIVEL PARA AUTORIZAR A COMPRA NO MOMENTO.");
            }

        } else if ((valor_compra > 500) && (valor_compra <= 1500)) {
            if (gerentegeraldisponivel.equals("SIM")) {
                String aprovacao = gerentegeral.AprovaPagamento(valor_compra);
                System.out.println("Compra Aprovada Por Gerente Geral? " + aprovacao);
            } else if (diretorfinanceirodisponivel.equals("SIM")) {
                String aprovacao = diretorfinanceiro.AprovaPagamento(valor_compra);
                System.out.println("Compra Aprovada Por Diretor Financeiro? " + aprovacao);
            } else if (diretorgeraldisponivel.equals("SIM")) {
                String aprovacao = diretorgeral.AprovaPagamento(valor_compra);
                System.out.println("Compra Aprovada Por Diretor Geral? " + aprovacao);
            } else {
                System.out.println("NINGUÉM DISPONIVEL PARA AUTORIZAR A COMPRA NO MOMENTO.");
            }
        } else if ((valor_compra > 1500) && (valor_compra <= 5000)) {
            if (diretorfinanceirodisponivel.equals("SIM")) {
                String aprovacao = diretorfinanceiro.AprovaPagamento(valor_compra);
                System.out.println("Compra Aprovada Por Diretor Financeiro? " + aprovacao);
            } else if (diretorgeraldisponivel.equals("SIM")) {
                String aprovacao = diretorgeral.AprovaPagamento(valor_compra);
                System.out.println("Compra Aprovada Por Diretor Geral? " + aprovacao);
            } else {
                System.out.println("NINGUÉM DISPONIVEL PARA AUTORIZAR A COMPRA NO MOMENTO.");
            }
        } else if ((valor_compra > 5000) && (valor_compra <= 15000)) {
            if (diretorgeraldisponivel.equals("SIM")) {
                String aprovacao = diretorgeral.AprovaPagamento(valor_compra);
                System.out.println("Compra Aprovada Por Diretor Geral? " + aprovacao);
            } else {
                System.out.println("NINGUÉM DISPONIVEL PARA AUTORIZAR A COMPRA NO MOMENTO.");
            }
        } else {
            System.out.println("VALOR ULTRAPASSOU O LIMITE DE AUTORIZAÇÃO DE COMPRA.");
        }

    }

}
