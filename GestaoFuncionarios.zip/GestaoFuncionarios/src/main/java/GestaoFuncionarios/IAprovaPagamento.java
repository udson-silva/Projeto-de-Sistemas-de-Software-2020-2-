/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestaoFuncionarios;

/**
 *
 * @author udson
 */
public interface IAprovaPagamento {
    public String AprovaPagamento(Float valor_compra);
    
    public String Disponivel();
    
    
}
