/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestaoFuncionarios;

/**
 *
 * @author udson
 */
public class DiretorFinanceiro implements IAprovaPagamento{

  
    @Override
    public String Disponivel() {
       String disponivel = "NÃO";
        return disponivel;
    }

    @Override
    public String AprovaPagamento(Float valor_compra) {
       String aprovacao;
        
        if (valor_compra<=5000){
           aprovacao = "SIM"; 
        }else{
            aprovacao = "NÃO";
        }
        
        return aprovacao;   
    }

   
    
}
