/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import GestaoFuncionarios.DiretorFinanceiro;
import GestaoFuncionarios.DiretorGeral;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author udson
 */
public class FuncionarioTest {
    
    public FuncionarioTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @Test
    public void CT001() {
        float valor_compra = 2500;
        String resultado_esperado = "NÃO";
        DiretorFinanceiro diretorfinanceiro =  new DiretorFinanceiro();
       
        assertEquals(resultado_esperado,diretorfinanceiro.Disponivel());
        
    }
    
    @Test
    public void CT002() {
        float valor_compra = 2500;
        String resultado_esperado = "SIM";
        DiretorFinanceiro diretorfinanceiro =  new DiretorFinanceiro();
       
        assertEquals(resultado_esperado,diretorfinanceiro.Disponivel());
        
    }
    
     @Test
    public void CT003() {
        float valor_compra = 5001;
        String resultado_esperado = "SIM";
        DiretorFinanceiro diretorfinanceiro =  new DiretorFinanceiro();
        String resultado_obtido = diretorfinanceiro.AprovaPagamento(valor_compra);
       
        assertEquals(resultado_esperado,resultado_obtido);
        
    }
    
     @Test
    public void CT004() {
        float valor_compra = 4999;
        String resultado_esperado = "NÃO";
        DiretorFinanceiro diretorfinanceiro =  new DiretorFinanceiro();
        String resultado_obtido = diretorfinanceiro.AprovaPagamento(valor_compra);
       
        assertEquals(resultado_esperado,resultado_obtido);
        
    }
    
      @Test
    public void CT005() {
        float valor_compra = 15001;
        String resultado_esperado = "NÃO";
        DiretorGeral diretorgeral = new DiretorGeral();
        String resultado_obtido = diretorgeral.AprovaPagamento(valor_compra);
       
        assertEquals(resultado_esperado,resultado_obtido);
        
    }
    
     @Test
    public void CT006() {
        float valor_compra = 15001;
        String resultado_esperado = "SIM";
        DiretorGeral diretorgeral = new DiretorGeral();
        String resultado_obtido = diretorgeral.AprovaPagamento(valor_compra);
       
        assertEquals(resultado_esperado,resultado_obtido);
        
    }

    
     @Test
    public void CT007() {
        float valor_compra = 0001;
        String resultado_esperado = "SIM";
        DiretorGeral diretorgeral = new DiretorGeral();
        String resultado_obtido = diretorgeral.AprovaPagamento(valor_compra);
       
        assertEquals(resultado_esperado,resultado_obtido);
        
    }
  
    
     @Test
    public void CT008() {
        float valor_compra = -0001;
        String resultado_esperado = "NÃO";
        DiretorGeral diretorgeral = new DiretorGeral();
        String resultado_obtido = diretorgeral.AprovaPagamento(valor_compra);
       
        assertEquals(resultado_esperado,resultado_obtido);
        
    }
    
    
}
